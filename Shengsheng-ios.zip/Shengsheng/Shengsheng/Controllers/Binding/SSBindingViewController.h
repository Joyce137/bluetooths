//
//  SSBindingViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSBindingViewController : NNBaseViewController

@end
