//
//  SSBindingViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSBindingViewController.h"
#import "MMExampleDrawerVisualStateManager.h"
#import "AppDelegate.h"
#import "UIButton+NN.h"
#import "NNConstants.h"
#import "SSAlerView.h"

#import "PeripheralViewContriller.h"

#import <CoreBluetooth/CoreBluetooth.h>

#define AlerViewH 140
#define AlerViewW 280

#import "BabyBluetooth.h"

@interface SSBindingViewController ()<CBPeripheralManagerDelegate,SSAlerViewDelegate,UITableViewDelegate,UITableViewDataSource>{
    UIControl * _blackControl;
    SSAlerView *_ssAlerView;
    
    
    NSInteger timerInt;

    BabyBluetooth *baby;
}
@property (weak, nonatomic) IBOutlet UIButton *dismissButton;
@property (weak, nonatomic) IBOutlet UIButton *btButton;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;

@property (strong,nonatomic)NSTimer *timer;

@property (nonatomic,strong)CBPeripheralManager *peripheralManager;
@property (nonatomic,strong)CBCentralManager *cbCentralMgr;

@property (nonatomic,strong)NSMutableArray *peripheralArray;

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@end

@implementation SSBindingViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    [_dismissButton changeImageAndTitle];
    [_btButton centerImageAndTitle];
    
    self.titleLabel.text = @"";
    self.infoLabel.text = @"";

    
    _blackControl = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH ,MAIN_SCREEN_HEIGHT)];
    _blackControl.backgroundColor = [UIColor blackColor];
    _blackControl.alpha = 0.4;
    _blackControl.hidden = YES;
    [_blackControl addTarget:self action:@selector(endEditingAction) forControlEvents:UIControlEventTouchUpInside];
    
    _ssAlerView = [[SSAlerView alloc]init];
    _ssAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
    _ssAlerView.delegate = self;
    [_ssAlerView layoutIfNeeded];
    
    self.peripheralManager = [[CBPeripheralManager alloc] initWithDelegate:self queue:nil options:nil];
    
    _peripheralArray = [NSMutableArray array];
    baby = [BabyBluetooth shareBabyBluetooth];
    //设置蓝牙委托
    [self babyDelegate];
}


- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    
    UIWindow* currentWindow = [UIApplication sharedApplication].keyWindow;
    [currentWindow addSubview:_blackControl];
    [currentWindow addSubview:_ssAlerView];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
  }

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_blackControl removeFromSuperview];
    [_ssAlerView removeFromSuperview];
    
    [_timer invalidate];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)dismissButtonAction:(id)sender {
    [self getAppDelegate].window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [[self getAppDelegate].window makeKeyAndVisible];
    [self getAppDelegate].window.rootViewController = [self getAppDelegate].drawerController;
}
- (IBAction)btButtonAction:(id)sender {
    UIButton *button = (UIButton *)sender;
    
    if ([button.titleLabel.text isEqualToString:@"点击链接设备"]) {
        self.titleLabel.text = @"正在搜索手环";
        self.infoLabel.text = @"请将手环贴近手机";
        
        
        
        [baby cancelAllPeripheralsConnection];
         baby.scanForPeripherals().begin();
    }else{
        [self blackAction:NO];
    }
    
}

- (void)infoLabelAction{
    switch (timerInt) {
        case 0:
            self.titleLabel.text = @"正在搜索手环";
            timerInt ++;
            break;
        case 1:
            self.titleLabel.text = @"正在搜索手环.";
            timerInt ++;
            break;
        case 2:
            self.titleLabel.text = @"正在搜索手环..";
            timerInt ++;
            break;
        case 3:
            self.titleLabel.text = @"正在搜索手环...";
            timerInt ++;
            break;
            
        default:
            timerInt = 0;
            break;
    }
}

- (void)endEditingAction{
    [self blackAction:NO];
}

#pragma mark- SSAlerViewDelegate
- (void)blackAction:(BOOL)Key;{
    
    
    [UIView animateWithDuration:0.5 animations:^{
        if (_blackControl.hidden) {
            _ssAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
            _blackControl.hidden = NO;
        }else{
            
            _ssAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
            _blackControl.hidden = YES;
            
            if(Key){
                NSURL *url = [NSURL URLWithString:@"prefs:root=Bluetooth"];
                if ([[UIApplication sharedApplication] canOpenURL:url]) {
                    [[UIApplication sharedApplication] openURL:url];
                }

            }
            
        }
    }];
    
    
}


#pragma mark - UITableViewDelegate,UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return _peripheralArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    UITableViewCell *cell = [[UITableViewCell alloc]init];
    CBPeripheral *p = _peripheralArray[indexPath.row];
    cell.textLabel.text = p.identifier.UUIDString;
    return cell;
}


-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];

    PeripheralViewContriller *vc = [[PeripheralViewContriller alloc]init];
    
    vc.currPeripheral = [_peripheralArray objectAtIndex:indexPath.row];
    vc->baby = self->baby;
    
    UINavigationController *nvc = [[UINavigationController alloc]initWithRootViewController:vc];
    [self presentViewController:nvc animated:YES completion:^{
        
    }];
}

#pragma mark - CBPeripheralManagerDelegate
- (void)peripheralManagerDidUpdateState:(CBPeripheralManager *)peripheral{
    switch (peripheral.state) {
            //蓝牙开启且可用
        case CBPeripheralManagerStatePoweredOn:
        {
            self.titleLabel.text = @"绑定设备";
            [self.btButton setImage:[UIImage imageNamed:@"equipment"] forState:UIControlStateNormal];
            [self.btButton setTitle:@"点击链接设备" forState:UIControlStateNormal];
            [_btButton centerImageAndTitle];
        }
            break;
        default:
            self.titleLabel.text = @"蓝牙未开启";
                self.infoLabel.text = @"";
            [self.btButton setImage:[UIImage imageNamed:@"bluetooth"] forState:UIControlStateNormal];
            [self.btButton setTitle:@"在弹出的对话框中点击允许" forState:UIControlStateNormal];
            [_btButton centerImageAndTitle];
            break;
    }
}


#pragma mark- babybt
//蓝牙网关初始化和委托方法设置
-(void)babyDelegate{
    
    __weak typeof(self) weakSelf = self;
    [baby setBlockOnCentralManagerDidUpdateState:^(CBCentralManager *central) {
        if (central.state == CBCentralManagerStatePoweredOn) {
             NSLog(@"设备打开成功，开始扫描设备");
//            [SVProgressHUD showInfoWithStatus:@"设备打开成功，开始扫描设备"];
            [weakSelf.timer invalidate];
            timerInt = 0;
            weakSelf.timer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:weakSelf selector:@selector(infoLabelAction) userInfo:nil repeats:YES];
        }
    }];
    
    //设置扫描到设备的委托
    [baby setBlockOnDiscoverToPeripherals:^(CBCentralManager *central, CBPeripheral *peripheral, NSDictionary *advertisementData, NSNumber *RSSI) {
        
//        [weakSelf insertTableView:peripheral advertisementData:advertisementData];
        
        if (advertisementData[@"kCBAdvDataServiceData"]) {
            NSLog(@"搜索到了设备:%@-%@",peripheral.name,advertisementData);
            [weakSelf.peripheralArray addObject:peripheral];
            [weakSelf.tableView reloadData];
        }
        
        
    }];
    
    //设置发现设备的Services的委托
    [baby setBlockOnDiscoverServices:^(CBPeripheral *peripheral, NSError *error) {
        for (CBService *service in peripheral.services) {
            NSLog(@"搜索到服务:%@",service.UUID.UUIDString);
        }
//        //找到cell并修改detaisText
//        for (int i=0;i<peripherals.count;i++) {
//            UITableViewCell *cell = [weakSelf.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
//            if ([cell.textLabel.text isEqualToString:peripheral.name]) {
//                cell.detailTextLabel.text = [NSString stringWithFormat:@"%lu个service",(unsigned long)peripheral.services.count];
//            }
//        }
    }];
    //设置发现设service的Characteristics的委托
    [baby setBlockOnDiscoverCharacteristics:^(CBPeripheral *peripheral, CBService *service, NSError *error) {
        NSLog(@"===service name:%@",service.UUID);
        for (CBCharacteristic *c in service.characteristics) {
            NSLog(@"charateristic name is :%@",c.UUID);
        }
    }];
    //设置读取characteristics的委托
    [baby setBlockOnReadValueForCharacteristic:^(CBPeripheral *peripheral, CBCharacteristic *characteristics, NSError *error) {
        NSLog(@"characteristic name:%@ value is:%@",characteristics.UUID,characteristics.value);
    }];
    //设置发现characteristics的descriptors的委托
    [baby setBlockOnDiscoverDescriptorsForCharacteristic:^(CBPeripheral *peripheral, CBCharacteristic *characteristic, NSError *error) {
        NSLog(@"===characteristic name:%@",characteristic.service.UUID);
        for (CBDescriptor *d in characteristic.descriptors) {
            NSLog(@"CBDescriptor name is :%@",d.UUID);
        }
    }];
    //设置读取Descriptor的委托
    [baby setBlockOnReadValueForDescriptors:^(CBPeripheral *peripheral, CBDescriptor *descriptor, NSError *error) {
        NSLog(@"Descriptor name:%@ value is:%@",descriptor.characteristic.UUID, descriptor.value);
    }];
    
    
    //设置查找设备的过滤器
    [baby setFilterOnDiscoverPeripherals:^BOOL(NSString *peripheralName, NSDictionary *advertisementData, NSNumber *RSSI) {
        
        //最常用的场景是查找某一个前缀开头的设备
        //        if ([peripheralName hasPrefix:@"Pxxxx"] ) {
        //            return YES;
        //        }
        //        return NO;
        
        //设置查找规则是名称大于0 ， the search rule is peripheral.name length > 0
        if (peripheralName.length >0) {
            return YES;
        }
        return NO;
    }];
    
    
    [baby setBlockOnCancelAllPeripheralsConnectionBlock:^(CBCentralManager *centralManager) {
        NSLog(@"setBlockOnCancelAllPeripheralsConnectionBlock");
    }];
    
    [baby setBlockOnCancelScanBlock:^(CBCentralManager *centralManager) {
        NSLog(@"setBlockOnCancelScanBlock");
    }];
    
    
    /*设置babyOptions
     
     参数分别使用在下面这几个地方，若不使用参数则传nil
     - [centralManager scanForPeripheralsWithServices:scanForPeripheralsWithServices options:scanForPeripheralsWithOptions];
     - [centralManager connectPeripheral:peripheral options:connectPeripheralWithOptions];
     - [peripheral discoverServices:discoverWithServices];
     - [peripheral discoverCharacteristics:discoverWithCharacteristics forService:service];
     
     该方法支持channel版本:
     [baby setBabyOptionsAtChannel:<#(NSString *)#> scanForPeripheralsWithOptions:<#(NSDictionary *)#> connectPeripheralWithOptions:<#(NSDictionary *)#> scanForPeripheralsWithServices:<#(NSArray *)#> discoverWithServices:<#(NSArray *)#> discoverWithCharacteristics:<#(NSArray *)#>]
     */
    
    //示例:
    //扫描选项->CBCentralManagerScanOptionAllowDuplicatesKey:忽略同一个Peripheral端的多个发现事件被聚合成一个发现事件
    NSDictionary *scanForPeripheralsWithOptions = @{CBCentralManagerScanOptionAllowDuplicatesKey:@YES};
    //连接设备->
    [baby setBabyOptionsWithScanForPeripheralsWithOptions:scanForPeripheralsWithOptions connectPeripheralWithOptions:nil scanForPeripheralsWithServices:nil discoverWithServices:nil discoverWithCharacteristics:nil];
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
