//
//  SSRealTimeViewController.h
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/26.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSRealTimeViewController : NNBaseViewController




@end
