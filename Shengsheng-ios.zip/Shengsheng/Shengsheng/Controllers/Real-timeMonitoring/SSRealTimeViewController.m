//
//  SSRealTimeViewController.m
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/26.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSRealTimeViewController.h"
#import "NNConstants.h"
#import "UIColor+NN.h"

#import "Taget.h"
#import <MagicalRecord/MagicalRecord.h>

#import "UUChart.h"
#import "FSLineChart.h"
#import "YAScrollSegmentControl.h"

@interface SSRealTimeViewController ()<YAScrollSegmentControlDelegate,UUChartDataSource>{
    
    UUChart *chartView01;
    UUChart *chartView02;
    UUChart *chartView03;
    
    BOOL isAction;
    
    CGPoint _originalPoint;
}
@property (weak, nonatomic) IBOutlet UISegmentedControl *segmentedControl;

@property (weak, nonatomic) IBOutlet YAScrollSegmentControl *topScrollSegmentControl;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *mainW;

@property (weak, nonatomic) IBOutlet UIPageControl *pageControl;
@property (weak, nonatomic) IBOutlet UIScrollView *rootSV;

@property (weak, nonatomic) IBOutlet UIView *s1dayInfoBgView;
@property (weak, nonatomic) IBOutlet UIView *s1otherInfoBgView;

@property (weak, nonatomic) IBOutlet UILabel *s2InfoLabel;
@property (weak, nonatomic) IBOutlet UILabel *s2normalLabel;
@property (weak, nonatomic) IBOutlet UILabel *s2TimeLabel;

@property (weak, nonatomic) IBOutlet UIView *s1ChartBgView;
@property (weak, nonatomic) IBOutlet UIView *s2ChartBgView;
@property (weak, nonatomic) IBOutlet UIView *s3ChartBgView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bigW;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *bigH;

@property (weak, nonatomic) IBOutlet UIScrollView *s1rootSV;
@property (weak, nonatomic) IBOutlet UIScrollView *s2rootSV;
@property (weak, nonatomic) IBOutlet UIScrollView *s3rootSV;

@property (weak, nonatomic) IBOutlet FSLineChart *chart;
@end


@implementation SSRealTimeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _topScrollSegmentControl.tintColor = [UIColor clearColor];
    [_topScrollSegmentControl setTitleColor:[UIColor colorWithHexString:MAIN_TINT_COLOR] forState:UIControlStateSelected];
    [_topScrollSegmentControl setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    [_topScrollSegmentControl setBackgroundImage:[UIImage imageNamed:@"backgroundSelected"] forState:UIControlStateSelected];
    [_topScrollSegmentControl setBackgroundImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
    _topScrollSegmentControl.buttons = @[@"心率",@"睡眠",@"步数"];
     _topScrollSegmentControl.selectedIndex = 0;

    [_topScrollSegmentControl setFont:[UIFont fontWithName:@"Helvetica" size:14.0]];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    _mainW.constant = MAIN_SCREEN_WIDTH;
    
    _bigW.constant = MAIN_SCREEN_WIDTH * 3;
    _bigH.constant = MAIN_SCREEN_HEIGHT - 64 - 50 - 73;
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)segmentedControlAction:(id)sender {
    isAction = NO;
    [self didSelectItemAtIndex:_topScrollSegmentControl.selectedIndex];
}

#pragma mark- YAScrollSegmentControlDelegate
- (void)didSelectItemAtIndex:(NSInteger)index;{

    if (!isAction) {
        _rootSV.contentOffset = CGPointMake(index * MAIN_SCREEN_WIDTH, 0);
        isAction = NO;
    }else{
        isAction = NO;
    }
    _pageControl.currentPage = index;
    
    _s1rootSV.contentOffset = CGPointMake(0, 0);
    _s2rootSV.contentOffset = CGPointMake(0, 0);
    _s2rootSV.contentOffset = CGPointMake(0, 0);
    
    switch (index) {
        case 0:{
            [chartView01 removeFromSuperview];
            
            switch (_segmentedControl.selectedSegmentIndex) {
                case 0://心率日
                    _s1dayInfoBgView.hidden = NO;
                    _s1otherInfoBgView.hidden = YES;
                    break;
                case 1://心率周
                    _s1dayInfoBgView.hidden = YES;
                    _s1otherInfoBgView.hidden = NO;
                    break;
                default://心率月
                    _s1dayInfoBgView.hidden = YES;
                    _s1otherInfoBgView.hidden = NO;
                    break;
            }
            
            chartView01 = [[UUChart alloc]initWithFrame:CGRectMake(-20,0, MAIN_SCREEN_WIDTH , 150)
                                             dataSource:self
                                                  style:UUChartStyleLine];
            [chartView01 showInView:_s1ChartBgView];
        }
            break;
        case 1:{
            NSString *timeStr = @"";
            
            [chartView02 removeFromSuperview];
            
            switch (_segmentedControl.selectedSegmentIndex) {
                case 0://睡眠日
                    _s2InfoLabel.text = @"今日深度睡眠趋势图";
                    _s2normalLabel.text = @"健康深睡眠时长4小时";
                    timeStr = @"03小时20分钟";
                    
                    chartView02 = [[UUChart alloc]initWithFrame:CGRectMake(-20,0, MAIN_SCREEN_WIDTH , 150)
                                                     dataSource:self
                                                          style:UUChartStyleBar];
                    chartView02.noInterval = YES;
                    [chartView02 showInView:_s2ChartBgView];
                    break;
                case 1://睡眠周
                    _s2InfoLabel.text = @"本周深度睡眠趋势图";
                    _s2normalLabel.text = @"健康深睡眠时长28小时";
                    timeStr = @"21小时20分钟";
                    
                    chartView02 = [[UUChart alloc]initWithFrame:CGRectMake(-20,0, MAIN_SCREEN_WIDTH , 150)
                                                     dataSource:self
                                                          style:UUChartStyleBar];
                    chartView02.noInterval = NO;
                    [chartView02 showInView:_s2ChartBgView];
                    break;
                default://睡眠月
                    _s2InfoLabel.text = @"本月深度睡眠趋势图";
                    _s2normalLabel.text = @"健康深睡眠时长112小时";
                    timeStr = @"84小时20分钟";
                    [self loadSimpleChart];
                    break;
            }
             NSMutableAttributedString *noteStr = [[NSMutableAttributedString alloc] initWithString:timeStr];
            
            NSRange redRange = NSMakeRange([[noteStr string] rangeOfString:@"小时"].location, [[noteStr string] rangeOfString:@"小时"].length);
            [noteStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#727272"] range:redRange];
            [noteStr addAttribute:NSFontAttributeName
                         value:[UIFont fontWithName:@"Helvetica" size:12.0]
                         range:redRange];
            
            NSRange redRangeTwo = NSMakeRange([[noteStr string] rangeOfString:@"分钟"].location, [[noteStr string] rangeOfString:@"分钟"].length);
            [noteStr addAttribute:NSForegroundColorAttributeName value:[UIColor colorWithHexString:@"#727272"] range:redRangeTwo];
            [noteStr addAttribute:NSFontAttributeName
                            value:[UIFont fontWithName:@"Helvetica" size:12.0]
                            range:redRangeTwo];
            
            _s2TimeLabel.attributedText = noteStr;
        }
            break;
            
        default:{
            
            [chartView03 removeFromSuperview];
            
            switch (_segmentedControl.selectedSegmentIndex) {
                case 0://步数日
                    chartView03 = [[UUChart alloc]initWithFrame:CGRectMake(-20, 30, MAIN_SCREEN_WIDTH , _s3ChartBgView.bounds.size.height - 30)
                                                   dataSource:self
                                                        style:UUChartStyleBar];
                    [chartView03 showInView:_s3ChartBgView];
                    break;
                case 1://步数周
                    chartView03 = [[UUChart alloc]initWithFrame:CGRectMake(-20, 30, MAIN_SCREEN_WIDTH , _s3ChartBgView.bounds.size.height - 30)
                                                     dataSource:self
                                                          style:UUChartStyleBar];
                    [chartView03 showInView:_s3ChartBgView];
                    break;
                default://步数月
                    chartView03 = [[UUChart alloc]initWithFrame:CGRectMake(-20, 30, MAIN_SCREEN_WIDTH , _s3ChartBgView.bounds.size.height - 30)
                                                     dataSource:self
                                                          style:UUChartStyleLine];
                    [chartView03 showInView:_s3ChartBgView];
                    break;
            }
        }

            break;
    }
    
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView;{

    if (scrollView == _rootSV) {
        NSInteger i = scrollView.contentOffset.x/scrollView.frame.size.width;
        
        _topScrollSegmentControl.selectedIndex = i;
        
        
    }

}

#pragma mark - Setting up the charts

- (void)loadSimpleChart {
    NSMutableArray* chartData = [NSMutableArray arrayWithCapacity:10];
    NSArray *dataArray = @[@"3.5",@"2.5",@"3.1",@"3",@"4",@"4",@"4.5"];

    
    for(int i=0;i<7;i++) {
        
        chartData[i] = [NSNumber numberWithFloat:[dataArray[i] floatValue]];
    }
    
    // Setting up the line chart
    self.chart.verticalGridStep = 5;
    self.chart.horizontalGridStep = 7;
    self.chart.drawInnerGrid = NO;//网格
    
    NSArray* months = @[@"0", @"5", @"10", @"15", @"20", @"25",@"30"];
    
    self.chart.labelForIndex = ^(NSUInteger item) {
        return [NSString stringWithFormat:@"%@",months[item]];
    };
    
    self.chart.labelForValue = ^(CGFloat value) {
        return [NSString stringWithFormat:@"%.f", value];
    };
    
    [self.chart setChartData:chartData];
}

#pragma mark - @required
//横坐标标题数组
- (NSArray *)chartConfigAxisXLabel:(UUChart *)chart
{
    if (chart == chartView03) {
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[@"0",@"6",@"12",@"18",@"24"];
            }
                break;
            case 1:
                return @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"];
                break;
                
            default:
                return @[@"5",@"10",@"15",@"20",@"25",@"30"];
                break;
        }

    }else if (chart == chartView01) {
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[@"0:00",@"6:00",@"12:00",@"18:00",@"24:00",];
            }
                break;
            case 1:
                return @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"];
                break;
                
            default:
                return @[@"5",@"10",@"15",@"20",@"25",@"30"];
                break;
        }
        
    }else if (chart == chartView02) {
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[@"20:00",@"",@"22:00",@"",@"24:00",@"",@"2:00",@"",@"4:00",@"",@"6:00",@"",@"8:00"];
            }
                break;
            case 1:
                return @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"];
                break;
                
            default:
                return @[@"5",@"10",@"15",@"20",@"25",@"30"];
                break;
        }
        
    }


    
    return @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"];
}
//数值多重数组
- (NSArray *)chartConfigAxisYValue:(UUChart *)chart
{
    NSArray *ary = @[@"22",@"44",@"15",@"40",@"42",@"15"];
    NSArray *ary1 = @[@"22",@"54",@"15",@"30",@"42",@"77",@"43"];
    NSArray *ary2 = @[@"76",@"34",@"54",@"23",@"16",@"32",@"17"];
    NSArray *ary3 = @[@"3",@"12",@"25",@"55",@"52",@"45"];
    NSArray *ary4 = @[@"43",@"52",@"65",@"95",@"92"];
    
    NSArray *ary5 = @[@"42",@"64",@"45",@"70",@"52",@"97",@"73"];
    NSMutableArray *avarr = [NSMutableArray array];
    for (NSInteger i = 0; i < ary1.count; i ++ ) {
        [avarr addObject:[NSString stringWithFormat:@"%ld",([ary1[i] integerValue] + [ary5[i] integerValue])/2]];
    }
    
    if (chart == chartView03) {
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[ary1,ary2];
            }
                break;
            case 1:
                return @[ary1,ary2];
                break;
                
            default:
                return @[ary,ary3];
                break;
        }
        
    }else if (chart == chartView01){
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[ary4];
            }
                break;
            case 1:
                return @[avarr,ary1,ary5];
                break;
                
            default:
                return @[avarr,ary1,ary5];
                break;
        }

    }else if (chart == chartView02){
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:{
                return @[@[@"1",@"1",@"0",@"1",@"0",@"1",@"1",@"1",@"0",@"1",@"0",@"1",@"1"]];
            }
                break;
            case 1:
                return @[@[@"3.5",@"2.5",@"3.1",@"3",@"4",@"4",@"4.5"]];
                break;
                
            default:
                return @[avarr,ary1,ary5];
                break;
        }

        
    }

    
    switch (_topScrollSegmentControl.selectedIndex) {
        case 0:
            return @[ary];
            break;
        case 1:
            return @[ary1,ary2];
            break;
        default:
            return @[ary1,ary2,ary3];
            break;
    }
    
}

#pragma mark - @optional
//颜色数组
- (NSArray *)chartConfigColors:(UUChart *)chart
{
    if (chart == chartView03) {
        return @[[UIColor colorWithHexString:@"#48C8FD"],[UIColor colorWithHexString:@"#F7CC4F"]];
    }else if (chart == chartView01){
        return @[[UIColor colorWithHexString:@"#72B228"],[UIColor colorWithHexString:@"#AA326F"],[UIColor colorWithHexString:@"#49B5B3"]];
    }else if (chart == chartView02){
        return @[[UIColor colorWithHexString:@"#E49200"]];
    }
    
    return @[[UUColor green],[UUColor red],[UUColor brown]];
}
//显示数值范围
- (NSArray *)chartRange:(UUChart *)chart
{
    if (chart == chartView03) {
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:
                return @[@"100/0",@"100/0"];
                break;
            case 1:
                return @[@"100/0",@"100/0"];
                break;
                
            default:
                return @[@"80/0",@"800/0"];
                break;
        }
    }else if (chart == chartView01){
            return @[@"120/0"];
    }else if (chart == chartView02){
        switch (_segmentedControl.selectedSegmentIndex) {
            case 0:
                return @[@"1/0"];
                break;
            case 1:
                return @[@"5/0"];
                break;
                
            default:
                return @[@"5/0"];
                break;
        }

        
    }
    
    return @[@"100/0",@"80/0"];
    
}

#pragma mark 折线图专享功能

//标记数值区域
- (CGRange)chartHighlightRangeInLine:(UUChart *)chart
{
    
    return CGRangeZero;
    
}

//判断显示横线条
- (BOOL)chart:(UUChart *)chart showHorizonLineAtIndex:(NSInteger)index
{
    return NO;
}

//判断显示最大最小值
- (BOOL)chart:(UUChart *)chart showMaxMinAtIndex:(NSInteger)index
{
    return NO;
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
