//
//  NNBaseViewController.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"
#import "AppDelegate.h"

#import "SSDrawerViewController.h"
#import "SSMyDeviceViewController.h"
#import "SSDeviceSettingViewController.h"
#import "SSGoalSettingViewController.h"
#import "SSAboutUSViewController.h"
#import "SSPersonInfoViewController.h"
#import "SSFollowViewController.h"
#import "SSBindingViewController.h"
#import "SSExerciseViewController.h"
#import "SSPrescriptionViewController.h"

#import "NNConstants.h"
#import "UIColor+NN.h"
#import "UIViewController+MMDrawerController.h"

#import "ShareAlanHand.h"

@interface NNBaseViewController (){
        UILabel * _lableTitle;
}

@end

@implementation NNBaseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor colorWithHexString:@"#F6F5EF"];
    
    self.edgesForExtendedLayout = UIRectEdgeNone;
    
    _hud = [[MBProgressHUD alloc]initWithView:self.view];
    [self.view addSubview:_hud];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@""  style:UIBarButtonItemStylePlain target:nil action:nil];
    [self.navigationItem setBackBarButtonItem:item];
    
}

- (void)viewWillAppear:(BOOL)animated{
    
    [super viewWillAppear:animated];
    
    if ((self.navigationController.childViewControllers.count == 1 || [self isKindOfClass:[SSDrawerViewController class]] )&& ![self isKindOfClass:[SSBindingViewController class]]) {
        [self navigationUI];
        [self.mm_drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
        
        [self.mm_drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
        
        
    }else{
        [self.mm_drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeNone];
        
        [self.mm_drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeNone];
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (AppDelegate *)getAppDelegate {
    return (AppDelegate *)[UIApplication sharedApplication].delegate;
}


-(void)navigationUI{
    
    _lableTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 44)];
    _lableTitle.text = @"邓小可";
    [_lableTitle setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17]];
    _lableTitle.textAlignment = NSTextAlignmentCenter;
    _lableTitle.textColor = self.navigationController.navigationBar.tintColor;
    
    self.navigationItem.titleView = _lableTitle;

    
    UIBarButtonItem *button1= [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"more"] style:UIBarButtonItemStylePlain target:self action:@selector(gzAction)];
    UIBarButtonItem *button2 = [[UIBarButtonItem alloc]initWithTitle:@"关注   " style:UIBarButtonItemStylePlain target:self action:@selector(followAction)];
    
    UIBarButtonItem *button3 = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"ration_prescription"] style:UIBarButtonItemStylePlain target:self action:@selector(rpAction)];
    
    
    if ([self isKindOfClass:[SSExerciseViewController class]] ) {
        self.navigationItem.leftBarButtonItems = @[button1,button3];
    }else{
        self.navigationItem.leftBarButtonItem = button1;
    }
    
    self.navigationItem.rightBarButtonItem = button2;
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(pushAction:) name:@"PUSHNSNOTIFI" object:nil];
    
}

- (void)pushAction:(NSNotification *)obj{
    switch ([obj.object integerValue]) {
        case 0:
        {
//            NSLog(@"我的设备");
            SSMyDeviceViewController *vc = [[SSMyDeviceViewController alloc]init];
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 1:
        {
//            NSLog(@"设备设置");
            SSDeviceSettingViewController *vc = [[SSDeviceSettingViewController alloc]init];
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 2:
        {
//            NSLog(@"目标设置");
            SSGoalSettingViewController *vc = [[SSGoalSettingViewController alloc]init];
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 3:
        {
//            NSLog(@"关于我们");
            SSAboutUSViewController *vc = [[SSAboutUSViewController alloc]init];
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
        case 4:
        {
//            NSLog(@"头像");
            
            SSPersonInfoViewController *vc = [[SSPersonInfoViewController alloc]init];
            self.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:vc animated:YES];
            self.hidesBottomBarWhenPushed = NO;
        }
            break;
            
        default:
        {
//            NSLog(@"退出");
            LoginViewController *login = [ShareAlanHand shareSingleton].loginVC;
            [UIApplication sharedApplication].keyWindow.rootViewController = login;
        }
            break;
    }
}

- (void)rpAction{
    SSPrescriptionViewController *vc = [[SSPrescriptionViewController alloc]init];
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}

- (void)gzAction{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
}

- (void)followAction{
    SSFollowViewController *vc = [[SSFollowViewController alloc]init];
    self.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    self.hidesBottomBarWhenPushed = NO;
}

@end
