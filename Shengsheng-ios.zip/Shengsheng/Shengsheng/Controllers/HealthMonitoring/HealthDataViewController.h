//
//  HealthDataViewController.h
//  NnBaseProduct
//
//  Created by Ningning on 16/5/23.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface HealthDataViewController : NNBaseViewController

@end
