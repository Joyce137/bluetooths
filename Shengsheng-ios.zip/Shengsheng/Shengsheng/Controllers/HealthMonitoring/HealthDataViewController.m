//
//  HealthDataViewController.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/23.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "HealthDataViewController.h"

#import "XZHeader.h"
#import "XZTableViewCell.h"
#import "HealthDataTableViewCell.h"

#import "NNConstants.h"
#import "UIColor+NN.h"

#import "UUChart.h"

#import "Input.h"
#import <MagicalRecord/MagicalRecord.h>

#define HEADER_IDENTIFIER @"XZHeader"
#define LINECHART_HIGHT 216

@interface HealthDataViewController ()<UITableViewDelegate,UITableViewDelegate,UUChartDataSource>{
    NSMutableArray *_healthDataArray;
    
    UUChart *chartView;
    
    UIColor *_dataMainColor;
    
    NSMutableArray *_xArray;//横坐标数组
    NSMutableArray *_yVarray;//y值数组
    NSNumber * _yAverage;//纵轴平均值
}

@property (weak, nonatomic) IBOutlet UIView *lineChartBgView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) IBOutlet UIView *xyView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIView *colorView;
@property (weak, nonatomic) IBOutlet UILabel *xUntiLabel;
@property (weak, nonatomic) IBOutlet UILabel *yUntiLabel;
@property (weak, nonatomic) IBOutlet UIView *xueyaTitleBgView;

@property (weak, nonatomic) IBOutlet UIView *xzTitleBgView;
@property (weak, nonatomic) IBOutlet UIScrollView *xzRootSV;
@property (weak, nonatomic) IBOutlet UITableView *xzTbv;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *xzW;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *xzH;

@end

@implementation HealthDataViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initUI];
//    [self initdata];
}

- (void)initUI{
    _tableView.contentInset = UIEdgeInsetsMake(LINECHART_HIGHT, 0, 0, 0);
    
    [_xzTbv registerNib:[UINib nibWithNibName:@"XZHeader" bundle:nil] forHeaderFooterViewReuseIdentifier:HEADER_IDENTIFIER];
    _xzTbv.tableFooterView = [[UIView alloc]init];
    
    if ([self.title isEqualToString:@"血脂"]) {//血脂的显示类型不一样，不能用这个显示
        _tableView.hidden = YES;
        _xzRootSV.hidden = NO;
        _titleLabel.hidden = YES;
        _colorView.hidden = YES;
        _xzTitleBgView.hidden = NO;
    }else{
        _tableView.hidden = NO;
        _xzRootSV.hidden = YES;
        _xzTitleBgView.hidden = YES;
        
        if ([self.title isEqualToString:@"身高"]) {
            _dataMainColor = [UIColor colorWithHexString:@"#18BDD0"];
        }else if ([self.title isEqualToString:@"体重"]){
            _dataMainColor = [UIColor colorWithHexString:@"#ED9408"];
        }else if ([self.title isEqualToString:@"BMI"]){
            _dataMainColor = [UIColor colorWithHexString:@"#ED085E"];
        }else if ([self.title isEqualToString:@"血糖"]){
            _dataMainColor = [UIColor colorWithHexString:@"#FF0303"];
        }else if ([self.title isEqualToString:@"聚糖血红蛋白"]){
            _dataMainColor = [UIColor colorWithHexString:@"#70B22B"];
        }else{
            _dataMainColor = [UIColor colorWithHexString:MAIN_TINT_COLOR];
        }
        
    }
    

}

//-(void)initdata{
//    _healthDataArray = [NSMutableArray array];
//    [_healthDataArray addObjectsFromArray:@[@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },@{
//                                                @"time":[NSDate date],
//                                                @"info":@"数据",
//                                                @"result":@"结果"
//                                                },]];
//}

- (void)getDataFromSql{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    
    NSPredicate *sampleFilter = [NSPredicate predicateWithFormat:@"userid = %@ and name = %@", userId,self.title];
    NSArray *samples = [Input MR_findAllWithPredicate:sampleFilter];
    
    _healthDataArray = [NSMutableArray array];

    
    for (Input * input in samples) {
        [_healthDataArray addObject:@{
                                      @"time":input.time,
                                      @"info":[input.info substringFromIndex:1],
                                      @"result":@"结果"
                                      }];
        _yUntiLabel.text = input.unit;
    }
    
    if ([self.title isEqualToString:@"血脂"]) {
        [_xzTbv reloadData];
    }else{
        [_tableView reloadData];
    }
    
    
    //绑图表数据源数组
    _xArray = [NSMutableArray array];
    _yVarray = [NSMutableArray array];
    
    NSMutableArray * averageArray = [NSMutableArray array];
    
    NSDateFormatter *df01 = [[NSDateFormatter alloc]init];
    [df01 setDateFormat:@"yyyy-MM-dd HH:mm"];
    NSDateFormatter *df02 = [[NSDateFormatter alloc]init];
    [df02 setDateFormat:@"MM/dd"];
    
    for (NSDictionary *dic in _healthDataArray) {
        [_xArray addObject:[df02 stringFromDate:[df01 dateFromString:dic[@"time"]]]];
        
        if ([dic[@"info"] pathComponents].count > 1) {
            
            for (NSInteger i = 0; i < [dic[@"info"] pathComponents].count; i ++ ) {
                if (_yVarray.count > i) {
                    NSMutableArray *temArry = [[NSMutableArray alloc]initWithArray:_yVarray[i]];
                    [temArry addObject:[dic[@"info"] pathComponents][i]];
                    [_yVarray replaceObjectAtIndex:i withObject:temArry];
                }else{
                    NSMutableArray *temArray = [NSMutableArray array];
                    [temArray addObject:[dic[@"info"] pathComponents][i]];
                    [_yVarray addObject:temArray];
                }
                
                [averageArray addObject:[dic[@"info"] pathComponents][i]];
            }
            
        }else{
            
            if (_yVarray.count > 0) {
                NSMutableArray *temArry = [[NSMutableArray alloc]initWithArray:_yVarray[0]];
                [temArry addObject:dic[@"info"]];
                [_yVarray replaceObjectAtIndex:0 withObject:temArry];
            }else{
                [_yVarray addObject:@[dic[@"info"]]];
            }
            
            [averageArray addObject:dic[@"info"]];
        }
    }
    
    
    //用最大最小来计算平均值，比直接取平均值更使得页面美观
//    _yAverage = [averageArray valueForKeyPath:@"@avg.floatValue"];
    
    NSNumber *max = [averageArray valueForKeyPath:@"@max.floatValue"];
    NSNumber *min = [averageArray valueForKeyPath:@"@min.floatValue"];
    
    _yAverage = [NSNumber numberWithFloat:(max.floatValue+min.floatValue)/2];
    
    [_xyView removeFromSuperview];
    
    chartView = [[UUChart alloc]initWithFrame:CGRectMake(12, 30, MAIN_SCREEN_WIDTH - 45, 216 - 60)
                                   dataSource:self
                                        style:[self.title isEqualToString:@"血压"] ? UUChartStyleBar : UUChartStyleLine];
    [chartView showInView:_lineChartBgView];
    
    _xyView.frame = CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 216);
    _colorView.backgroundColor = _dataMainColor;
    _titleLabel.text = [NSString stringWithFormat:@"%@变化趋势图",self.title];
    
    if ([self.title isEqualToString:@"血压"]) {
        _xueyaTitleBgView.hidden = NO;
    }
    
    [_lineChartBgView addSubview:_xyView];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    _xzH.constant = MAIN_SCREEN_HEIGHT - 64 - LINECHART_HIGHT - 12 - 40;
    
    [self getDataFromSql];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


//标题换行文字
-(NSMutableAttributedString *)str:(NSString *)str value:(NSString *)value{
    NSMutableAttributedString *mStr = [[NSMutableAttributedString alloc]initWithString:[NSString stringWithFormat:@"%@\n%@",str,value]];
    NSRange range = [[NSString stringWithFormat:@"%@\n%@",str,value] rangeOfString:value];
//    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc]init];
//    [paragraphStyle setLineSpacing:5];
//    
    
    [mStr addAttribute:NSFontAttributeName
                value:[UIFont fontWithName:@"Helvetica" size:12.0]
                range:range];
    
//    [mStr addAttribute:NSParagraphStyleAttributeName
//                 value:paragraphStyle
//                 range:NSMakeRange(0, mStr.length)];
    
    return mStr;
}


#pragma mark - tableViewDataSource and tableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (tableView == _xzTbv) {
        return 55;
    }
    return 80;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (tableView == _xzTbv) {
        XZHeader *headerView = [[XZHeader alloc]initWithReuseIdentifier:HEADER_IDENTIFIER];
        headerView.label02.attributedText = [self str:@"总胆固醇" value:@"≤5.18"];
        headerView.label03.attributedText = [self str:@"甘油三酯" value:@"＜1.70"];
        headerView.label04.attributedText = [self str:@"高密度脂蛋白" value:@"≥1.04"];
        headerView.label05.attributedText = [self str:@"低密度脂蛋白" value:@"＜3.37"];
        headerView.label06.text = @"结果";
        return headerView;
    }
    
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 40)];
    view.backgroundColor = [UIColor whiteColor];
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 40)];
    label.text = @"   记录详情";
    label.backgroundColor = [UIColor colorWithHexString:@"#F6F5EF"];
    
    UILabel * label01 = [[UILabel alloc]initWithFrame:CGRectMake(0, 40, (MAIN_SCREEN_WIDTH)*2/5, 40)];
    label01.font = [UIFont fontWithName:@"Helvetica" size:14.0];
    label01.textAlignment = NSTextAlignmentCenter;
    label01.textColor = [UIColor colorWithHexString:@"#666666"];
    label01.text = @"监测时间";
    
    UILabel * label02 = [[UILabel alloc]initWithFrame:CGRectMake( (MAIN_SCREEN_WIDTH)*2/5, 40, (MAIN_SCREEN_WIDTH - 12)*2/5, 40)];
    label02.font = [UIFont fontWithName:@"Helvetica" size:14.0];
    label02.textAlignment = NSTextAlignmentCenter;
    label02.textColor = [UIColor colorWithHexString:@"#666666"];
    label02.text = self.title;
    
    UILabel * label03 = [[UILabel alloc]initWithFrame:CGRectMake((MAIN_SCREEN_WIDTH)*4/5, 40, (MAIN_SCREEN_WIDTH - 12)*1/5, 40)];
    label03.font = [UIFont fontWithName:@"Helvetica" size:14.0];
    label03.textAlignment = NSTextAlignmentCenter;
    label03.textColor = [UIColor colorWithHexString:@"#666666"];
    label03.text = @"结果";
    
    [view addSubview:label];
    [view addSubview:label01];
    [view addSubview:label02];
    
    if(![self.title isEqualToString:@"身高"]){
        [view addSubview:label03];
    }
    
    
    return view;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    return _healthDataArray.count;
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView == _xzTbv && !_xzRootSV.hidden) {
        static NSString *CellIdentifier = @"XZTableViewCell" ;
        XZTableViewCell *cell = (XZTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            NSArray *array = [[NSBundle mainBundle]loadNibNamed: CellIdentifier owner:self options:nil];
            cell = [array objectAtIndex:0];
        }
        
        cell.timeLabel.text = _healthDataArray[indexPath.row][@"time"];
        
        cell.label02.text = _yVarray[0][indexPath.row];
        cell.label03.text = _yVarray[1][indexPath.row];
        cell.label04.text = _yVarray[2][indexPath.row];
        cell.label05.text = _yVarray[3][indexPath.row];
        
        return cell;
    }
    
    static NSString *CellIdentifier = @"HealthDataTableViewCell" ;
    HealthDataTableViewCell *cell = (HealthDataTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *array = [[NSBundle mainBundle]loadNibNamed: CellIdentifier owner:self options:nil];
        cell = [array objectAtIndex:0];
    }
    

    
    cell.label01.text = _healthDataArray[indexPath.row][@"time"];
    cell.label02.text = _healthDataArray[indexPath.row][@"info"];
    cell.label03.text = _healthDataArray[indexPath.row][@"result"];
    
    if([self.title isEqualToString:@"身高"]){
        cell.label03.hidden = YES;
    }
    
    return cell;
    
    
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}


#pragma mark - @required
//横坐标标题数组
- (NSArray *)chartConfigAxisXLabel:(UUChart *)chart
{
    return _xArray;
}
//数值多重数组
- (NSArray *)chartConfigAxisYValue:(UUChart *)chart
{

    return _yVarray;
    
}

#pragma mark - @optional
//颜色数组
- (NSArray *)chartConfigColors:(UUChart *)chart
{
    if ([self.title isEqualToString:@"血压"]) {
        return @[[UIColor colorWithHexString:@"70B22B"],[UIColor colorWithHexString:@"E2DA01"]];
    }else if ([self.title isEqualToString:@"血脂"]){
        return @[
                 [UIColor colorWithHexString:@"940591"],
                 [UIColor colorWithHexString:@"36D5ED"],
                 [UIColor colorWithHexString:@"EDAA36"],
                 [UIColor colorWithHexString:@"99C22C"],];
    }
    return @[_dataMainColor];
}
//显示数值范围
- (NSArray *)chartRange:(UUChart *)chart
{
    NSString *rangeStr = [NSString stringWithFormat:@"%.2f/%.2f",_yAverage.floatValue/3*5,_yAverage.floatValue/3];
    
    return @[rangeStr];
    
}

#pragma mark 折线图专享功能

//标记数值区域
- (CGRange)chartHighlightRangeInLine:(UUChart *)chart
{
    
    return CGRangeZero;
    
}

//判断显示横线条
- (BOOL)chart:(UUChart *)chart showHorizonLineAtIndex:(NSInteger)index
{
    return NO;
}

//判断显示最大最小值
- (BOOL)chart:(UUChart *)chart showMaxMinAtIndex:(NSInteger)index
{
    return NO;
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
