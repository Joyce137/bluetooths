//
//  SSInfoSeleteViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSInfoSeleteViewController.h"
#import "PersonInfoSelTableViewCell.h"
#import "PersonInfoOtherTableViewCell.h"

#import "NNConstants.h"

#define CELL_IDENTIFIER01 @"PersonInfoSelTableViewCell"
#define CELL_IDENTIFIER02 @"PersonInfoOtherTableViewCell"

@interface SSInfoSeleteViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate>{
    
    UITableView *_tableView;

    NSArray *_selArray;
    
    NSMutableDictionary * _headSelDic;
    
    NSString *_otherStr;

    BOOL _keyboardIsVisible;
}
@property (weak, nonatomic) IBOutlet UIView *baseFameView;

@end

@implementation SSInfoSeleteViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    UITableViewController *tvc = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    tvc.tableView.frame = _baseFameView.frame;
    _tableView = [[UITableView alloc]init];
    _tableView = tvc.tableView;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
    [_tableView registerNib:[UINib nibWithNibName:@"PersonInfoSelTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView registerNib:[UINib nibWithNibName:@"PersonInfoOtherTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER02];
    _tableView.tableFooterView = [[UIView alloc]init];
    
    [self.view addSubview:_tableView];
    [self addChildViewController:tvc];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center  addObserver:self selector:@selector(keyboardDidShow)  name:UIKeyboardDidShowNotification  object:nil];
    [center addObserver:self selector:@selector(keyboardDidHide)  name:UIKeyboardWillHideNotification object:nil];
    _keyboardIsVisible = NO;
    
    NSString *typeStr = self.title;
    
    if([typeStr isEqualToString:@"血型"]){
        _selArray = @[@"A",@"B",@"O",@"AB",@"不详"];
    }else if ([typeStr isEqualToString:@"RH阴性"]){
        _selArray = @[@"是",@"否",@"不详"];
    }else if ([typeStr isEqualToString:@"文化层度"]){
        _selArray = @[@"文盲及半文盲",@"小学",@"初中",@"高中/技校/中专",@"大学专科以上",@"不详"];
    }else if ([typeStr isEqualToString:@"职业"]){
        _selArray = @[@"国家机关、党群组织、企业、事业单位负责人",@"专业技术人员",@"办事人员和有关人员",@"商业、服务人员",@"农、林、牧、渔水利生产人员",@"生产、运输设备操作人员及有关人员",@"军人",@"不便分类的其他从业人员"];
    }else if ([typeStr isEqualToString:@"婚姻状况"]){
        _selArray = @[@"未婚",@"已婚",@"丧偶",@"离婚",@"未说明的婚姻状况"];
    }else if ([typeStr isEqualToString:@"医疗费用支付方式"]){
        _selArray = @[@"城镇职工基本医疗保险",@"城镇居民基本医疗保险",@"新型农村合作医疗",@"贫困救助",@"商业医疗保险",@"全公费",@"全自费",@"其他："];
    }else if ([typeStr isEqualToString:@"药物过敏史"]){
        _selArray = @[@"无",@"青霉素",@"磺胺",@"链霉素",@"其他："];
    }else if ([typeStr isEqualToString:@"家族史父亲"] || [typeStr isEqualToString:@"家族史母亲"] || [typeStr isEqualToString:@"家族史兄弟姐妹"] || [typeStr isEqualToString:@"家族史子女"]){
        _selArray = @[@"无",@"高血压",@"糖尿病",@"冠心病",@"恶性肿瘤",@"慢性阻塞性肺疾病",@"脑卒中",@"重性精神疾病",@"结核病",@"肝炎",@"先天畸形",@"其他："];
    }else if ([typeStr isEqualToString:@"遗传病史"]){
        _selArray = @[@"无",@"有："];
    }
    _headSelDic = [NSMutableDictionary dictionary];
    
    if (_infoStr) {
        
        for (NSString * str in [_infoStr componentsSeparatedByString:@"|"]) {
            
            [_headSelDic setObject:@"" forKey:str];
            
            if ([_selArray indexOfObject:str]==NSNotFound) {
                _otherStr = str;
            }
        }
        
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    if (_delegate) {
        
        NSMutableString *infoSrt = [NSMutableString string];
        
        if (_otherStr && ![_otherStr isEqualToString:@""]) {
            [infoSrt appendFormat:@"|%@",_otherStr];
        }
        
        for (NSString * str in [_headSelDic allKeys]) {
            
            if (![str isEqualToString:_otherStr]) {
                [infoSrt appendFormat:@"|%@",str];
            }

        }
        if (infoSrt.length > 1 ) {
            [_delegate blackAction:[infoSrt substringFromIndex:1] AndKey:self.title];
        }

        
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)keyboardDidShow
{
    _keyboardIsVisible = YES;
}

- (void)keyboardDidHide
{
    _keyboardIsVisible = NO;
}

#pragma mark - tableViewDataSource and tableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return _selArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    
    if ([_selArray[indexPath.row] isEqualToString:@"其他："] || [_selArray[indexPath.row] isEqualToString:@"有："]) {
        static NSString *cellIdentifier = CELL_IDENTIFIER02;
        
        PersonInfoOtherTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[PersonInfoOtherTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        cell.titleLabel.text = _selArray[indexPath.row];
        
        if (_otherStr && ![_otherStr isEqualToString:@""]) {
            cell.selImageView.image = SEL_IMAGE;
            cell.inputTextField.text = _otherStr;
        }else{
            cell.selImageView.image = NO_SEL_IMAGE;
        }
        
        cell.inputTextField.delegate = self;
        
        return cell;
    }
    
    
    
    static NSString *cellIdentifier = CELL_IDENTIFIER01;
    
    PersonInfoSelTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[PersonInfoSelTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    
    cell.titleLabel.text = _selArray[indexPath.row];
    
    cell.selImageView.image = ([[_headSelDic allKeys] indexOfObject:_selArray[indexPath.row]] != NSNotFound) ?SEL_IMAGE : NO_SEL_IMAGE;
    
    return cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (_keyboardIsVisible) {
        [_tableView reloadData];
        
        [self.view endEditing:YES];
        return;
    }
    
    if ([[_headSelDic allKeys] indexOfObject:_selArray[indexPath.row]] != NSNotFound) {
        [_headSelDic removeObjectForKey:_selArray[indexPath.row]];
        _otherStr = nil;
    }else{
        if([_selArray[indexPath.row] isEqualToString:@"无"]){
            
            _headSelDic = [NSMutableDictionary dictionary];
            [_headSelDic setObject:@"" forKey:_selArray[indexPath.row]];
            
            _otherStr = nil;
        }else if ([_selArray[indexPath.row] isEqualToString:@"其他："] || [_selArray[indexPath.row] isEqualToString:@"有："]){
            PersonInfoOtherTableViewCell *cell = (PersonInfoOtherTableViewCell *)[_tableView cellForRowAtIndexPath:indexPath];
            _otherStr = cell.inputTextField.text;
            
            if ([[_headSelDic allKeys] indexOfObject:@"无"] != NSNotFound) {
                [_headSelDic removeObjectForKey:@"无"];
            }
            
        }else{
            NSString *typeStr = self.title;
            if([typeStr isEqualToString:@"血型"] || [typeStr isEqualToString:@"RH阴性"] || [typeStr isEqualToString:@"文化层度"] || [typeStr isEqualToString:@"职业"] || [typeStr isEqualToString:@"婚姻状况"] || [typeStr isEqualToString:@"医疗费用支付方式"] || [typeStr isEqualToString:@"遗传病史"]){
                
                _headSelDic = [NSMutableDictionary dictionary];
                [_headSelDic setObject:@"" forKey:_selArray[indexPath.row]];
                
                _otherStr = nil;
            }else{
                
                [_headSelDic setObject:@"" forKey:_selArray[indexPath.row]];
                
            }
            
            if ([[_headSelDic allKeys] indexOfObject:@"无"] != NSNotFound) {
                [_headSelDic removeObjectForKey:@"无"];
            }
        }

    }
        [_tableView reloadData];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField;  {
    
    _otherStr = textField.text;
    if (_otherStr && ![_otherStr isEqualToString:@""]) {
        
        if ([[_headSelDic allKeys] indexOfObject:@"无"] != NSNotFound) {
            [_headSelDic removeObjectForKey:@"无"];
        }
        [_tableView reloadData];
    }else{
        _otherStr = nil;
        [_tableView reloadData];
    }
    
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField;{
    [_tableView reloadData];
    [self.view endEditing:YES];
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
