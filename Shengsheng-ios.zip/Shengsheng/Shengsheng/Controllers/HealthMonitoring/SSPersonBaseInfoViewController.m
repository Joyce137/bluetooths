//
//  SSPersonBaseInfoViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSPersonBaseInfoViewController.h"
#import "SSInfoSeleteViewController.h"
#import "PersonInput01TableViewCell.h"
#import "NextTableViewCell.h"
#import "NNConstants.h"
#import "NNUtility.h"

#import "Person.h"
#import <MagicalRecord/MagicalRecord.h>

#define CELL_IDENTIFIER01 @"PersonInput01TableViewCell"
#define CELL_NEXT_IDENTIFIER @"NextTableViewCell"

@interface SSPersonBaseInfoViewController ()<UITableViewDelegate,UITableViewDataSource,UITextFieldDelegate,SELDelegate>{
    UITableView *_tableView;
    
    NSArray *_titleArray;
    
    NSMutableDictionary *_infoDic;
    
    BOOL _keyboardIsVisible;
    
    Person *_per;
}

@property (weak, nonatomic) IBOutlet UIView *baseFameView;

@end

@implementation SSPersonBaseInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    [self initUI];
    [self initData];

    

}

- (void)initUI{
    self.title = @"个人基本信息";
    
    UITableViewController *tvc = [[UITableViewController alloc] initWithStyle:UITableViewStylePlain];
    tvc.tableView.frame = _baseFameView.frame;
    _tableView = [[UITableView alloc]init];
    _tableView = tvc.tableView;
    _tableView.delegate = self;
    _tableView.dataSource = self;
    _tableView.backgroundColor = [UIColor clearColor];
    _tableView.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    
    [_tableView registerNib:[UINib nibWithNibName:@"PersonInput01TableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView registerNib:[UINib nibWithNibName:@"NextTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_NEXT_IDENTIFIER];
    _tableView.tableFooterView = [[UIView alloc]init];
    
    [self.view insertSubview:_tableView belowSubview:_hud];
    [self addChildViewController:tvc];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center  addObserver:self selector:@selector(keyboardDidShow)  name:UIKeyboardDidShowNotification  object:nil];
    [center addObserver:self selector:@selector(keyboardDidHide)  name:UIKeyboardWillHideNotification object:nil];
    _keyboardIsVisible = NO;
}

- (void)initData{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    
    NSArray *userInfoArr = [Person MR_findByAttribute:@"userid" withValue:userId];
    
    if (userInfoArr.count != 0) {
        _per = userInfoArr.firstObject;
        NSLog(@"%@",_per);
    }else{
        //看是否有获取的数据，有的话将数据存到数据库
        _per = [Person MR_createEntity];
        _per.userid = userId;
    }
    _titleArray = @[@"姓名",
                    @"性别",
                    @"民族",
                    @"身份证号",
                    @"本人电话",
                    @"联系人姓名",
                    @"联系电话",
                    
                    @"血型",
                    @"RH阴性",
                    @"文化层度",
                    @"职业",
                    @"婚姻状况",
                    @"医疗费用支付方式",
                    @"药物过敏史",
                    @"家族史父亲",
                    @"家族史母亲",
                    @"家族史兄弟姐妹",
                    @"家族史子女",
                    @"遗传病史",
                    ];
    
    _infoDic = [NSMutableDictionary dictionary];
    
    for (NSString *str in _titleArray) {
        [_infoDic setObject:[self getSqlInfo:str] forKey:str];
    }
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)keyboardDidShow
{
    _keyboardIsVisible = YES;
}

- (void)keyboardDidHide
{
    _keyboardIsVisible = NO;
}

//将汉字键值来取出数据库里面保存的相应数据
- (NSString *)getSqlInfo:(NSString *)key{
    NSString *str = @"";

    if ([key isEqualToString:@"姓名"]) {
        str = _per.name;
    }else if ([key isEqualToString:@"性别"]){
        str = _per.sex;
    }else if ([key isEqualToString:@"民族"]){
        str = _per.nation;
    }else if ([key isEqualToString:@"身份证号"]){
        str = _per.idcard;
    }else if ([key isEqualToString:@"本人电话"]){
        str = _per.phone;
    }else if ([key isEqualToString:@"联系人姓名"]){
        str = _per.othername;
    }else if ([key isEqualToString:@"联系电话"]){
        str = _per.otherphone;
    }else if ([key isEqualToString:@"血型"]){
        str = _per.blood;
    }else if ([key isEqualToString:@"RH阴性"]){
        str = _per.rh;
    }else if ([key isEqualToString:@"文化层度"]){
        str = _per.wenhua;
    }else if ([key isEqualToString:@"职业"]){
        str = _per.zhiye;
    }else if ([key isEqualToString:@"婚姻状况"]){
        str = _per.hunyin;
    }else if ([key isEqualToString:@"医疗费用支付方式"]){
        str = _per.zhifu;
    }else if ([key isEqualToString:@"药物过敏史"]){
        str = _per.guomin;
    }else if ([key isEqualToString:@"家族史父亲"]){
        str = _per.fu;
    }else if ([key isEqualToString:@"家族史母亲"]){
        str = _per.mu;
    }else if ([key isEqualToString:@"家族史兄弟姐妹"]){
        str = _per.xiong;
    }else if ([key isEqualToString:@"家族史子女"]){
        str = _per.zi;
    }else if ([key isEqualToString:@"遗传病史"]){
        str = _per.yichuan;
    }
    
    if(str){
        return str;
    }
    return @"";
}

//存入相应的数据
- (void)saveToSql:(NSString *)dataStr AndKey:(NSString *)key;{
    
    if ([key isEqualToString:@"姓名"]) {
         _per.name = dataStr;
    }else if ([key isEqualToString:@"性别"]){
        _per.sex = dataStr;
    }else if ([key isEqualToString:@"民族"]){
         _per.nation = dataStr;
    }else if ([key isEqualToString:@"身份证号"]){
         _per.idcard = dataStr;
    }else if ([key isEqualToString:@"本人电话"]){
         _per.phone = dataStr;
    }else if ([key isEqualToString:@"联系人姓名"]){
         _per.othername = dataStr;
    }else if ([key isEqualToString:@"联系电话"]){
        _per.otherphone = dataStr;
    }else if ([key isEqualToString:@"血型"]){
         _per.blood = dataStr;
    }else if ([key isEqualToString:@"RH阴性"]){
         _per.rh = dataStr;
    }else if ([key isEqualToString:@"文化层度"]){
        _per.wenhua = dataStr;
    }else if ([key isEqualToString:@"职业"]){
         _per.zhiye = dataStr;
    }else if ([key isEqualToString:@"婚姻状况"]){
         _per.hunyin = dataStr;
    }else if ([key isEqualToString:@"医疗费用支付方式"]){
         _per.zhifu = dataStr;
    }else if ([key isEqualToString:@"药物过敏史"]){
        _per.guomin = dataStr;
    }else if ([key isEqualToString:@"家族史父亲"]){
         _per.fu = dataStr;
    }else if ([key isEqualToString:@"家族史母亲"]){
         _per.mu = dataStr;
    }else if ([key isEqualToString:@"家族史兄弟姐妹"]){
         _per.xiong = dataStr;
    }else if ([key isEqualToString:@"家族史子女"]){
         _per.zi = dataStr;
    }else if ([key isEqualToString:@"遗传病史"]){
         _per.yichuan = dataStr;
    }
    _per.edit = [NSNumber numberWithBool:YES];
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
        NSLog(@"本地数据修改成功");
    }];

}


#pragma mark - SELDelegate
- (void)blackAction:(NSString *)dataStr AndKey:(NSString *)key;{
    
    [_infoDic setObject:dataStr forKey:key];
    [self saveToSql:dataStr AndKey:key];
    
    [_tableView reloadData];
}

#pragma mark - tableViewDataSource and tableViewDelegate
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40.0;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return _titleArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    if (indexPath.row < 7) {
        
                    static NSString *cellIdentifier = CELL_IDENTIFIER01;
            
            PersonInput01TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
            
            if (!cell) {
                cell = [[PersonInput01TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
                
            }
            cell.titleLabel.text = _titleArray[indexPath.row];
            
            NSString * temp = [_infoDic[_titleArray[indexPath.row]] stringByReplacingOccurrencesOfString:@"|" withString:@","];//将特殊的分隔修改成","显示
            
            cell.inputTextField.text = temp;
            cell.inputTextField.placeholder = [NSString stringWithFormat:@"填写%@",_titleArray[indexPath.row]];
            
            if (!cell.inputTextField.delegate) {
                cell.inputTextField.delegate = self;
            }
            
            if ([_titleArray[indexPath.row] isEqualToString:@"身份证号码"] || [_titleArray[indexPath.row] isEqualToString:@"本人电话"] || [_titleArray[indexPath.row] isEqualToString:@"联系电话"] ) {
                cell.inputTextField.keyboardType = UIKeyboardTypePhonePad;
            }
            
            return cell;
        
    }else{
        
        static NSString *cellIdentifier = CELL_NEXT_IDENTIFIER;
        
        NextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[NextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        
        cell.titleLabel.text = _titleArray[indexPath.row];
        cell.mainInfoLabel.hidden = NO;
        NSString * temp = [_infoDic[_titleArray[indexPath.row]] stringByReplacingOccurrencesOfString:@"|" withString:@","];//将特殊的分隔修改成","显示
        cell.mainInfoLabel.text = temp;
        
        return cell;

    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_keyboardIsVisible) {
        [_tableView reloadData];
        [self.view endEditing:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
        return;
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if(indexPath.row >= 7){
        SSInfoSeleteViewController * vc = [[SSInfoSeleteViewController alloc]init];
        vc.delegate = self;
        vc.title = _titleArray [indexPath.row];
        
        if (_infoDic[_titleArray [indexPath.row]] && ![_infoDic[_titleArray [indexPath.row]] isEqualToString:@""]) {
            vc.infoStr = _infoDic[_titleArray [indexPath.row]];
        }
        
        [self.navigationController pushViewController:vc animated:YES];
    }

}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self.view endEditing:YES];
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldEndEditing:(UITextField *)textField;  {
    
    NSString *saveKey = [textField.placeholder substringFromIndex:2];
    
    NSString *error = nil;
    
    if([saveKey isEqualToString:@"身份证号"] && ![NNUtility validateIDCard:textField.text]){
    error = @"身份证号格式不正确";
    }else if ([saveKey isEqualToString:@"本人电话"] && ![NNUtility validateMobile:textField.text]){
    error = @"本人电话格式不正确";
    }else if ([saveKey isEqualToString:@"联系电话"] && ![NNUtility validateMobile:textField.text]){
    error = @"身本人电话格式不正确";
    }
    
    
    if (error) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = error;
        [_hud hide:YES afterDelay:2];
        return NO;
    }else{
        [_infoDic setObject:textField.text forKey:saveKey];
        [self saveToSql:textField.text AndKey:saveKey];
        
        return YES;
    }
    

}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
