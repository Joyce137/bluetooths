//
//  HealthHomeViewController.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/23.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "HealthHomeViewController.h"
#import "HealthDataViewController.h"
#import "SSPersonBaseInfoViewController.h"

#import "NNConstants.h"
#import "UIColor+NN.h"
#import "Health.h"
#import "Input.h"
#import <MagicalRecord/MagicalRecord.h>

#import "HealthAlerView.h"

#import "HealthTableViewCell.h"
#import "NextTableViewCell.h"

#define CELL_IDENTIFIER @"HealthTableViewCell"
#define CELL_NEXT_IDENTIFIER @"NextTableViewCell"

#define AlerViewH 372
#define AlerViewW 280

@interface HealthHomeViewController ()<UITableViewDelegate,UITableViewDataSource,HealthDelegate>{
    NSMutableArray *_healthArray;
    
    
    UIControl * _blackControl;
    HealthAlerView *_healthAlerView;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation HealthHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
     
    [_tableView registerNib:[UINib nibWithNibName:@"HealthTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    [_tableView registerNib:[UINib nibWithNibName:@"NextTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_NEXT_IDENTIFIER];
    _tableView.tableFooterView = [[UIView alloc]init];
    
    
    [self updateDateData];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    _blackControl = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH ,MAIN_SCREEN_HEIGHT)];
    _blackControl.backgroundColor = [UIColor blackColor];
    _blackControl.alpha = 0.4;
    _blackControl.hidden = YES;
    [_blackControl addTarget:self action:@selector(endEditingAction) forControlEvents:UIControlEventTouchUpInside];
    
    _healthAlerView = [[HealthAlerView alloc]init];
    _healthAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
    _healthAlerView.delegate = self;
    
    UIWindow* currentWindow = [UIApplication sharedApplication].keyWindow;
    [currentWindow addSubview:_blackControl];
    [currentWindow addSubview:_healthAlerView];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_blackControl removeFromSuperview];
    [_healthAlerView removeFromSuperview];
}

- (void)updateDateData{
    _healthArray = [NSMutableArray array];
    [_healthArray addObjectsFromArray: [MTLJSONAdapter modelsOfClass:[Health class] fromJSONArray:@[@{
                                                                                                        @"title":@"身高",
                                                                                                        @"info":[self getInputForSqlBykey:@"身高"],
                                                                                            
                                                                                                        },@{
                                                                                                        @"title":@"体重",
                                                                                                        @"info":[self getInputForSqlBykey:@"体重"],
                                                                                                    
                                                                                                        },@{
                                                                                                        @"title":@"BMI",
                                                                                                        @"info":[self getInputForSqlBykey:@"BMI"],
                                                                                                    
                                                                                                        },@{
                                                                                                        @"title":@"血糖",
                                                                                                        @"info":[self getInputForSqlBykey:@"血糖"],
                                                                                                    
                                                                                                        },@{
                                                                                                        @"title":@"血压",
                                                                                                        @"info":[self getInputForSqlBykey:@"血压"],
                                                                                                    
                                                                                                        },@{
                                                                                                        @"title":@"血脂",
                                                                                                        @"info":[self getInputForSqlBykey:@"血脂"],
                                                                                                    
                                                                                                        },@{
                                                                                                        @"title":@"糖化血红蛋白",
                                                                                                        @"info":[self getInputForSqlBykey:@"糖化血红蛋白"],
                                                                                                    
                                                                                                        }] error:nil]];
    
    [_tableView reloadData];
}

- (Input *)getInputForSqlBykey:(NSString *)key{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    
    NSPredicate *sampleFilter = [NSPredicate predicateWithFormat:@"userid = %@ and name = %@", userId,key];
    NSArray *samples = [Input MR_findAllWithPredicate:sampleFilter];
    
    Input * input = samples.lastObject;
    
    if (!input) {
        input = [Input MR_createEntity];
    }
    
    return input;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)endEditingAction{
    [_healthAlerView endEditing:YES];
}

- (void)addButtonAction:(id)sender{
    UIButton *button = (UIButton *)sender;
    

    NSString *titleStr = @"";
    switch (button.tag) {
        case 0:
        {
        titleStr = @"录入身高";
        [self showAction:_healthAlerView.inputBgView01];
            _healthAlerView.itf01.placeholder = @"点击输入测量身高值";
            _healthAlerView.until01.text = @"cm";
        }
            break;
        case 1:
        {
           titleStr = @"录入体重";
            [self showAction:_healthAlerView.inputBgView01];
            _healthAlerView.itf01.placeholder = @"点击输入测量体重值";
            _healthAlerView.until01.text = @"kg";
        }
            break;
        case 2:
        {
            titleStr = @"录入BMI";
            [self showAction:_healthAlerView.inputBgView02];
            
            _healthAlerView.itf11.placeholder = @"点击输入BMI值";
            _healthAlerView.until11.hidden = YES;
            
            _healthAlerView.itf12.placeholder = @"点击输入腰围";
            _healthAlerView.until12.hidden = NO;
            _healthAlerView.until12.text = @"cm";
            
        }
            break;
        case 3:
        {
            titleStr = @"录入血糖";
            [self showAction:_healthAlerView.inputBgView01];
            _healthAlerView.itf01.placeholder = @"点击输入空腹血糖值";
            _healthAlerView.until01.text = @"mmol/L";
            
        }
            break;
        case 4:
        {
            titleStr = @"录入血压";
            
            [self showAction:_healthAlerView.inputBgView02];
            
            _healthAlerView.itf11.placeholder = @"点击输入收缩压值";
            _healthAlerView.until11.hidden = NO;
            _healthAlerView.until11.text = @"mmHg";
            
            _healthAlerView.itf12.placeholder = @"点击输入舒张压值";
            _healthAlerView.until12.hidden = NO;
            _healthAlerView.until12.text = @"mmHg";
        }
            break;
        case 5:
        {
            titleStr = @"录入血脂";
            [self showAction:_healthAlerView.inputBgView03];
        }
            break;
        default:
        {
        titleStr = @"录入糖化血红蛋白";
            [self showAction:_healthAlerView.inputBgView01];
            _healthAlerView.itf01.placeholder = @"点击输入糖化血红蛋白值";
            _healthAlerView.until01.text = @"%";
        }
            break;
    }
    _healthAlerView.titleLabel.text = titleStr;
    
    NSDateFormatter *df01 = [[NSDateFormatter alloc]init];
    NSDateFormatter *df02 = [[NSDateFormatter alloc]init];
    
    [df01 setDateFormat:@"yyyy-MM-dd"];
    [df02 setDateFormat:@"HH:mm"];
    
    _healthAlerView.dateLabel.text = [df01 stringFromDate:[NSDate date]];
    _healthAlerView.timeLabel.text = [df02 stringFromDate:[NSDate date]];
    
    [self blackAction:nil];
}

-(void)showAction:(UIView *)view;{
    _healthAlerView.inputBgView01.hidden = ![_healthAlerView.inputBgView01 isEqual:view];
    _healthAlerView.inputBgView02.hidden = ![_healthAlerView.inputBgView02 isEqual:view];
    _healthAlerView.inputBgView03.hidden = ![_healthAlerView.inputBgView03 isEqual:view];
}


#pragma mark- HealthDelegate
- (void)blackAction:(NSString *)dataStr;
{

    [UIView animateWithDuration:0.5 animations:^{
        if (_blackControl.hidden) {
            _healthAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
            _blackControl.hidden = NO;
        }else{
            
            if (dataStr) {
                NSLog(@"%@",dataStr);
                
                if ([[_healthAlerView.titleLabel.text substringFromIndex:2] isEqualToString:@"BMI"]) {//这里有个腰围的问题的计算，先直接保存记录，腰围之后算
                    
                    [self saveToSql:[NSString stringWithFormat:@"/%@",[dataStr pathComponents][1]] AndKey:[_healthAlerView.titleLabel.text substringFromIndex:2]];
                }else{
                    [self saveToSql:dataStr AndKey:[_healthAlerView.titleLabel.text substringFromIndex:2]];
                }
                
                
            }
            [_healthAlerView endEditing:YES];
            
            _healthAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
            _blackControl.hidden = YES;
            
            for (UIView * view in _healthAlerView.subviews) {
                if (view.tag >= 100) {
                    for (id tf in view.subviews) {
                        if ([tf isKindOfClass:[UITextField class]]) {
                            ((UITextField *)tf).text = @"";
                        }
                    }
                }
            }

        }
    }];
    
    
}

//保存录入的数据
- (void)saveToSql:(NSString *)dataStr AndKey:(NSString *)key;{
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString * userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    
    Input *input = [Input MR_createEntity];
    
    input.userid = userId;
    
    NSDateFormatter *df = [[NSDateFormatter alloc]init];
    [df setDateFormat:@"yyyy-MM-dd HH:mm"];
    input.time = [df stringFromDate:[NSDate date]];
    
    input.name = key;
    
    input.info = dataStr;
    
    if ([key isEqualToString:@"身高"]) {
        input.unit = @"cm";
    }else if ([key isEqualToString:@"体重"]){
        input.unit = @"kg";
    }else if ([key isEqualToString:@"BMI"]){
        input.unit = @"kg/㎡";
    }else if ([key isEqualToString:@"血糖"]){
        input.unit = @"mmol/L";
    }else if ([key isEqualToString:@"血压"]){
        input.unit = @"mmHg";
    }else if ([key isEqualToString:@"血脂"]){
        input.unit = @"mmol/L";
    }else if ([key isEqualToString:@"糖化血红蛋白"]){
        input.unit = @"%";
    }
    
    [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
        NSLog(@"本地录入数据成功");
    }];
    
    [self updateDateData];
}

#pragma mark - tableViewDataSource and tableViewDelegate
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 40;
    }
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section == 0) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 40)];
        view.backgroundColor = [UIColor colorWithHexString:@"#F6F5EF"];
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(12, 0, MAIN_SCREEN_WIDTH - 24, 40)];
        label.text = @"健康监测";
        
        [view addSubview:label];
        
        return view;

    }
    return [[UIView alloc]init];
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return _healthArray.count;
    }
    return 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        static NSString *cellIdentifier = CELL_IDENTIFIER;
        HealthTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[HealthTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        Health * healt = _healthArray[indexPath.row];
        
        cell.titleLabel.text = healt.title;
        
        Input *input = healt.info;
        cell.timeLabel.text = [input.time substringToIndex:10];
        
        if (input.info) {
            cell.infoLabel.text = [NSString stringWithFormat:@"%@%@",[input.info substringFromIndex:1],input.unit];
        }
        
        
        cell.addButton.tag = indexPath.row;
        [cell.addButton addTarget:self action:@selector(addButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;

    }
    
    static NSString *cellIdentifier = CELL_NEXT_IDENTIFIER;
    
    NextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[NextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }

    
    return cell;

}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    if (indexPath.section == 0) {
        HealthDataViewController *vc = [[HealthDataViewController alloc]init];
        Health * healt = _healthArray[indexPath.row];
        vc.title = healt.title;
        self.hidesBottomBarWhenPushed = YES;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }else{
        SSPersonBaseInfoViewController *vc = [[SSPersonBaseInfoViewController alloc]init];
        self.hidesBottomBarWhenPushed = YES;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        self.hidesBottomBarWhenPushed = NO;
    }
    
    
    
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
