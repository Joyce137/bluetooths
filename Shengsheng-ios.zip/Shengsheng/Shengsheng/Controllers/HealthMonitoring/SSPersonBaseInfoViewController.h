//
//  SSPersonBaseInfoViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSPersonBaseInfoViewController : NNBaseViewController

@end
