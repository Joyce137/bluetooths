//
//  SSInfoSeleteViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@protocol SELDelegate <NSObject>
- (void)blackAction:(NSString *)dataStr AndKey:(NSString *)key;
@end

@interface SSInfoSeleteViewController : NNBaseViewController

@property (assign,nonatomic,readwrite)id <SELDelegate>delegate;

@property (nonatomic)NSString *infoStr;

@end
