//
//  SSDrawerViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSDrawerViewController.h"
#import "NNConstants.h"
#import "UIColor+NN.h"
#import "NextTableViewCell.h"

#import "UIViewController+MMDrawerController.h"

#import <SDWebImage/UIImageView+WebCache.h>

#define CELL_NEXT_IDENTIFIER @"NextTableViewCell"

@interface SSDrawerViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSArray *_drawerArray;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIImageView *headeImageView;
@property (weak, nonatomic) IBOutlet UILabel *userNameLabel;

@end

@implementation SSDrawerViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor colorWithHexString:@"#EEF1DE"];
    
    [_tableView registerNib:[UINib nibWithNibName:@"NextTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_NEXT_IDENTIFIER];
    _tableView.tableFooterView = [[UIView alloc]init];
    
    _drawerArray = @[@"我的设备",@"设备设置",@"目标设置",@"关于我们"];
    
    _headeImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(headerImageViewAction:)];
    [_headeImageView addGestureRecognizer:tap];
}


- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    
    _headeImageView.layer.masksToBounds = YES;
    _headeImageView.layer.borderWidth = 2.0;
    _headeImageView.layer.cornerRadius = _headeImageView.bounds.size.width/2;
    _headeImageView.layer.borderColor = [UIColor colorWithHexString:@"#86AA22"].CGColor;
    
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    NSDictionary *infoDic = [userDefaults objectForKey:kUSERDEFAULT_UINFODIC];
    
    if (infoDic[@"avatar"] && ![infoDic[@"avatar"] isEqualToString:@""]) {
        [_headeImageView sd_setImageWithURL:[NSURL URLWithString:infoDic[@"avatar"]] placeholderImage:USER_PLACEHOLDER_IMAGE];
    }
    _userNameLabel.text = infoDic[@"nick"];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)headerImageViewAction:(UITapGestureRecognizer *)tap{
    [self drawerActionWithType:_drawerArray.count];
}

- (IBAction)signoutButtonAction:(id)sender {
    [self drawerActionWithType:_drawerArray.count + 1];
}


#pragma mark - tableViewDataSource and tableViewDelegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return _drawerArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    static NSString *cellIdentifier = CELL_NEXT_IDENTIFIER;
    
    NextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[NextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    
    if (indexPath.row == 0) {
        cell.nextImageView.hidden = YES;
        cell.infoLabel.hidden = NO;
    }else{
        cell.nextImageView.hidden = NO;
        cell.infoLabel.hidden = YES;
    }
    cell.backgroundColor = [UIColor clearColor];
    cell.titleLabel.text = _drawerArray[indexPath.row];
    
    return cell;
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 35.0;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self drawerActionWithType:indexPath.row];
}

- (void)drawerActionWithType:(NSInteger)type{
    [self.mm_drawerController toggleDrawerSide:MMDrawerSideLeft animated:YES completion:nil];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"PUSHNSNOTIFI" object:[NSString stringWithFormat:@"%ld",type]];
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
