//
//  SSEditPasswordViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/5/27.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSEditPasswordViewController : NNBaseViewController

@end
