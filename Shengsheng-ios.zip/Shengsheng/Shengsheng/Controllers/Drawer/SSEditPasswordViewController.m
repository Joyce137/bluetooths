//
//  SSEditPasswordViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/27.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSEditPasswordViewController.h"
#import "NNServiceClient.h"
#import "NNConstants.h"
#import "NNConstants.h"
#import "NNServiceClient.h"

@interface SSEditPasswordViewController ()
@property (weak, nonatomic) IBOutlet UITextField *oTextField;
@property (weak, nonatomic) IBOutlet UITextField *nTextField;
@property (weak, nonatomic) IBOutlet UITextField *rTextField;

@property (weak, nonatomic) IBOutlet UIButton *sureButton;
@end

@implementation SSEditPasswordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"修改密码";
    
    _sureButton.layer.cornerRadius = 4.0;
    
    //隐藏键盘
    UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(keyboardHide:)];
    //设置成NO表示当前控件响应后会传播到其他控件上，默认为YES。
    tapGestureRecognizer.cancelsTouchesInView = NO;
    //将触摸事件添加到当前view
    [self.view addGestureRecognizer:tapGestureRecognizer];
}

-(void)keyboardHide:(UITapGestureRecognizer*)tap{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)saveButttonAction:(id)sender {
    
    NSString *errorStr = nil;
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults objectForKey:kUSERDEFAULT_ACCCESSTOKEN];
    if ([_oTextField.text isEqualToString:@""]) {
        errorStr = @"请输入旧密码";
    }else if ([_nTextField.text isEqualToString:@""]){
        errorStr = @"请输入新密码";
    }else if (_nTextField.text.length < 8){
        errorStr = @"新密码至少8位";
    }else if ([_rTextField.text isEqualToString:@""]){
        errorStr = @"请确认密码";
    }else if (![_nTextField.text isEqualToString:_rTextField.text]){
        errorStr = @"确认密码与新密码不一致";
    }else{
        errorStr = nil;
       
        [[NNServiceClient sharedClient]GET:@"user/updatePwd" parameters:@{
        @"token":token,@"opwd":self.oTextField.text, @"pwd":self.nTextField.text,@"rpwd":self.rTextField.text} progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSLog(@"responseObject = %@ -- message = %@",responseObject,responseObject[@"message"]);
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"error = %@",error);
        }];
    }
    
    if(errorStr){
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = errorStr;
        [_hud hide:YES afterDelay:2];
    }else{
        
        [[NNServiceClient sharedClient]POST:@"user/updatePwd" parameters:@{
                                                             @"token":token,
                                                             @"opwd":_oTextField.text,
                                                             @"pwd":_nTextField.text,
                                                             @"rpwd":_rTextField.text,
                                                             } progress:^(NSProgress * _Nonnull uploadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSDictionary *dic = (NSDictionary *)responseObject;
            if ([dic[@"success"] integerValue] == 1) {
                [_hud show:YES];
                _hud.mode = MBProgressHUDModeText;
                _hud.labelText = @"修改成功";
                [_hud hide:YES afterDelay:2];
                
                [self performSelector:@selector(popAction) withObject:nil afterDelay:2.0f];
            }else{
                [_hud show:YES];
                _hud.mode = MBProgressHUDModeText;
                _hud.labelText = dic[@"message"];
                [_hud hide:YES afterDelay:2];
            }

        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = @"请求失败";
            [_hud hide:YES afterDelay:2];
        }];
        
        
        
    }
    
}

- (void)popAction{
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
