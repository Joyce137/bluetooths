//
//  SSDeviceSettingViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSDeviceSettingViewController.h"
#import "SSNewCodeViewController.h"

#import "SettingTableViewCell.h"

#define CELL_IDENTIFIER @"SettingTableViewCell"

@interface SSDeviceSettingViewController ()<UITableViewDelegate,UITableViewDataSource>{
    
    NSArray *_titleArray;
    NSMutableDictionary *_infoDic;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation SSDeviceSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"设备设置";
    
    [_tableView registerNib:[UINib nibWithNibName:@"SettingTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    
    _titleArray = @[@"设备电量",@"时间同步",@"测心率周期",@"连续测心率",@"睡眠状态"];
    _infoDic = [[NSMutableDictionary alloc]initWithDictionary:@{
                                                                @"设备电量":@"73%",
                                                                @"时间同步":[NSNumber numberWithBool:YES],
                                                                @"测心率周期":@"2次/小时",
                                                                @"连续测心率":[NSNumber numberWithBool:YES],
                                                                @"睡眠状态":[NSNumber numberWithBool:NO]                                                                }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)sButtonAction:(id)sender{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    [_infoDic setObject:[NSNumber numberWithBool:button.selected] forKey:_titleArray[button.tag]];
    [_tableView reloadData];
}

#pragma mark - tableViewDataSource and tableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    return _titleArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = CELL_IDENTIFIER;
    
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    
    if (indexPath.section == 1) {
        cell.titleLabel.text = _titleArray [indexPath .row];
        
        if([_infoDic[_titleArray[indexPath.row]] isKindOfClass:[NSNumber class]]){
            cell.sButton.hidden = NO;
            cell.infoLabel.hidden = YES;
            cell.sButton.selected = [_infoDic[_titleArray[indexPath.row]] isEqual:[NSNumber numberWithBool:YES]];
            cell.sButton.tag = indexPath.row;
            [cell.sButton addTarget:self action:@selector(sButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        }else{
            cell.sButton.hidden = YES;
            cell.infoLabel.hidden = NO;
            cell.infoLabel.text = [NSString stringWithFormat:@"%@",_infoDic[_titleArray[indexPath.row]]];
        }
    }else{
        cell.sButton.hidden = YES;
        cell.infoLabel.hidden = YES;
    }

    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.row == 0) {
        SSNewCodeViewController *vc = [[SSNewCodeViewController alloc]init];
        self.hidesBottomBarWhenPushed  = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 20;
    }
    return 10;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
