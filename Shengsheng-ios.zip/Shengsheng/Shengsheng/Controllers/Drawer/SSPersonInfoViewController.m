//
//  SSPersonInfoViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSPersonInfoViewController.h"

#import "PersonHeaderTableViewCell.h"
#import "PersonInfoTableViewCell.h"
#import "NextTableViewCell.h"

#import "NNConstants.h"
#import "NNUtility.h"
#import "NNServiceClient.h"
#import "SSEditPasswordViewController.h"
#import <SDWebImage/UIImageView+WebCache.h>

#import "UIImage+NN.h"

#define CELL_IDENTIFIER01 @"PersonHeaderTableViewCell"
#define CELL_IDENTIFIER02 @"PersonInfoTableViewCell"
#define CELL_NEXT_IDENTIFIER @"NextTableViewCell"

@interface SSPersonInfoViewController ()<UITableViewDelegate,UITableViewDataSource,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UITextFieldDelegate,UIPickerViewDelegate,UIPickerViewDataSource>{
    
    NSArray * _titleArray;
    NSMutableArray *_infoArray;
    
    UIAlertController *alertController;
    
    UIImage *_headerImage;
    
    NSMutableDictionary *_infoDic;
    
    
    BOOL _edit;
    
    BOOL _keyboardIsVisible;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *pickerBgView;
@property (weak, nonatomic) IBOutlet UIDatePicker *dP;
@property (weak, nonatomic) IBOutlet UIPickerView *sP;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *pickerTitle;

@end

@implementation SSPersonInfoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    self.title = @"个人信息";
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    _infoDic = [[NSMutableDictionary alloc]initWithDictionary:[userDefaults objectForKey:kUSERDEFAULT_UINFODIC]];
    
    _titleArray = @[@"性别",@"年龄",@"真实姓名",@"联系电话",@"修改密码"];
    
    _dP.maximumDate = [NSDate date];
    
    [_tableView registerNib:[UINib nibWithNibName:@"PersonHeaderTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView registerNib:[UINib nibWithNibName:@"PersonInfoTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER02];
    [_tableView registerNib:[UINib nibWithNibName:@"NextTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_NEXT_IDENTIFIER];
    _tableView.tableFooterView = [[UIView alloc]init];
    
     [self showAlert];
    
    _edit = NO;
    UIBarButtonItem *button = [[UIBarButtonItem alloc]initWithTitle:@"编辑" style:UIBarButtonItemStylePlain target:self action:@selector(editAction:)];
    self.navigationItem.rightBarButtonItem = button;
    
    [self reloadDataAction];
    
    NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
    [center  addObserver:self selector:@selector(keyboardDidShow)  name:UIKeyboardDidShowNotification  object:nil];
    [center addObserver:self selector:@selector(keyboardDidHide)  name:UIKeyboardWillHideNotification object:nil];
    _keyboardIsVisible = NO;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)reloadDataAction{
    _infoArray = [NSMutableArray array];
    [_infoArray addObjectsFromArray:@[
                                      [_infoDic[@"sex"] integerValue] == 1? @"男":@"女",
                                      _infoDic[@"age"],
                                      _infoDic[@"real_name"],
                                      _infoDic[@"contact"]
                                      ]];
    [_tableView reloadData];
}

- (void)editAction:(id)sender{
    UIBarButtonItem *button = (UIBarButtonItem *)sender;
    
    if ([button.title isEqualToString:@"编辑"]) {
        [button setTitle:@"完成"];
        _edit = YES;
        [self reloadDataAction];
    }else{
        
        [self.view endEditing:YES];
        
        if (!_keyboardIsVisible) {
            [button setTitle:@"编辑"];
            
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString *token = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
            
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeIndeterminate;
            _hud.labelText = @"";
            
            [[NNServiceClient sharedClient]POST:@"user/updateInfo" parameters:@{
                                                                                @"token":token,
                                                                                @"real_name":_infoDic[@"real_name"],
                                                                                @"age":_infoDic[@"age"],
                                                                                @"sex":_infoDic[@"sex"],
                                                                                @"contact":_infoDic[@"contact"],
                                                                                @"nick":_infoDic[@"nick"],
                                                                                } progress:^(NSProgress * _Nonnull uploadProgress) {
                                                                                    
                                                                                } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                                                                    NSDictionary *dic = (NSDictionary *)responseObject;
                                                                                    if ([dic[@"success"] integerValue] == 1) {
                                                                                        
                                                                                        [_hud show:YES];
                                                                                        _hud.mode = MBProgressHUDModeText;
                                                                                        _hud.labelText = @"修改成功";
                                                                                        [ _hud hide:YES afterDelay:2];
                                                                                        
                                                                                        _edit = NO;
                                                                                        [userDefaults setObject:_infoDic forKey:kUSERDEFAULT_UINFODIC];
                                                                                        [self reloadDataAction];
                                                                                    }else{
                                                                                        [_hud show:YES];
                                                                                        _hud.mode = MBProgressHUDModeText;
                                                                                        _hud.labelText = dic[@"message"];
                                                                                        [ _hud hide:YES afterDelay:2];
                                                                                    }
                                                                                } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                                                                    [_hud show:YES];
                                                                                    _hud.mode = MBProgressHUDModeText;
                                                                                    _hud.labelText = @"请求失败";
                                                                                    [ _hud hide:YES afterDelay:2];
                                                                                }];

        }
        
        
        
        
    }
}
- (void)showAlert {
    
    NSString *cancelButtonTitle = @"取消";
    NSString *otherButtonTitle01 = @"拍照";
    NSString *otherButtonTitle02 = @"从手机相册选择";
    
    alertController = [UIAlertController alertControllerWithTitle:nil message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    
    __weak __typeof(&*self)weakSelf =self;
    
    // Create the actions.
    UIAlertAction *cancelAction = [UIAlertAction actionWithTitle:cancelButtonTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction *action) {
        
        
    }];
    
    UIAlertAction *otherAction01 = [UIAlertAction actionWithTitle:otherButtonTitle01 style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        if ([weakSelf isCameraAvailable]) {
            [weakSelf showImagePickerView:UIImagePickerControllerSourceTypeCamera];
        }else{
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = @"该设备不支持相机拍照";
            [_hud hide:YES afterDelay:2];
        }
        
    }];
    
    UIAlertAction *otherAction02 = [UIAlertAction actionWithTitle:otherButtonTitle02 style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
        [weakSelf showImagePickerView:UIImagePickerControllerSourceTypePhotoLibrary];
        
    }];
    
    // Add the actions.
    [alertController addAction:cancelAction];
    [alertController addAction:otherAction01];
    [alertController addAction:otherAction02];
    
}

-(void)showImagePickerView:(UIImagePickerControllerSourceType)sourceType {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc]init];
    imagePicker.delegate = self;
    imagePicker.allowsEditing = YES;
    imagePicker.sourceType = sourceType;
    [self presentViewController:imagePicker animated:YES completion:nil];
}


- (BOOL) isCameraAvailable
{
    return [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera];
}

- (void)keyboardDidShow
{
    _keyboardIsVisible = YES;
}

- (void)keyboardDidHide
{
    _keyboardIsVisible = NO;
}


- (IBAction)canceButtonAction:(id)sender {
    _pickerBgView.hidden = YES;
    _sP.hidden = YES;
    _dP.hidden = YES;
    [self.view endEditing:YES];
}

- (IBAction)sureButtonAction:(id)sender {
    
    
    if (_sP.hidden) {
        [_infoDic setObject:[NSString stringWithFormat:@"%ld",[NNUtility ageFromBirthStr:_dP.date]] forKey:@"age"];
    }else{
        [_infoDic setObject:[_sP selectedRowInComponent:0]==0 ? @"1":@"2" forKey:@"sex"];
    }
    
    _pickerBgView.hidden = YES;
    _sP.hidden = YES;
    _dP.hidden = YES;
    [self.view endEditing:YES];
    
    [self reloadDataAction];
}

#pragma mark - tableViewDataSource and tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {

    return _titleArray.count + 1;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        
        NSDictionary *infoDic = [userDefaults objectForKey:kUSERDEFAULT_UINFODIC];
        
        static NSString *cellIdentifier = CELL_IDENTIFIER01;
        PersonHeaderTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[PersonHeaderTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        cell.titleTextField.enabled = _edit;
        cell.titleTextField.text = _infoDic[@"nick"];
        cell.titleTextField.delegate = self;
        cell.titleTextField.tag = indexPath.row;
        if (_headerImage) {
            cell.headerImageView.image = _headerImage;
        }else{
           
            if (infoDic[@"avatar"] && ![infoDic[@"avatar"] isEqualToString:@""]) {
                [cell.headerImageView sd_setImageWithURL:[NSURL URLWithString:infoDic[@"avatar"]] placeholderImage:USER_PLACEHOLDER_IMAGE];
            }

        }
        
        return cell;
        
    }else if (indexPath.row == _titleArray.count){
        static NSString *cellIdentifier = CELL_NEXT_IDENTIFIER;
        
        NextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[NextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        cell.titleLabel.text = _titleArray[indexPath.row - 1];
        
        return cell;
    }
    static NSString *cellIdentifier = CELL_IDENTIFIER02;
    
    PersonInfoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[PersonInfoTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    
    
    cell.titleLabel.text = _titleArray[indexPath.row - 1];
    cell.infoTextField.text = _infoArray[indexPath.row - 1];
    cell.infoTextField.delegate = self;
    cell.infoTextField.tag = indexPath.row;
    if (indexPath.row > 2) {
        cell.infoTextField.enabled = _edit;
    }else{
        cell.infoTextField.enabled = NO;
    }
    
    return cell;
    
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == 0) {
        return 80;
    }return 40;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (_keyboardIsVisible) {
        [_tableView reloadData];
        [self.view endEditing:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:NO];
        return;
    }
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    _pickerBgView.hidden = YES;
    _sP.hidden = YES;
    _dP.hidden = YES;
    [self.view endEditing:YES];
    
    if (indexPath.row == _titleArray.count) {
        SSEditPasswordViewController *vc = [[SSEditPasswordViewController alloc]init];
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(indexPath.row == 0){
        [self presentViewController:alertController animated:YES completion:nil];
    }else{
        if (_edit && indexPath.row == 1) {//显示选择性别的选择器
            _pickerBgView.hidden = NO;
            _sP.hidden = NO;
            _dP.hidden = YES;
            _pickerTitle.title = @"性别";
        }else if (_edit && indexPath.row == 2){//显示选择年龄的选择器
            _pickerBgView.hidden = NO;
            _sP.hidden = YES;
            _dP.hidden = NO;
            _pickerTitle.title = @"生日";
        }
    }
}



#pragma mark - UIImagePickerControllerDelegate


-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
    NSData *imageData = UIImageJPEGRepresentation([info[UIImagePickerControllerEditedImage] scaleToSize:CGSizeMake(56.0f, 56.0f)], 1);
    
//    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
//    
//    NSString *token = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
    
    [[NNServiceClient sharedClient]POST:@"user/updateAvatar" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
        [formData appendPartWithFileData:imageData name:@"avatar" fileName:[[NNUtility GUID] stringByAppendingPathExtension:@"jpg"] mimeType:@"image/jpeg"];
    } progress:^(NSProgress * _Nonnull uploadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
        if ([dic[@"success"] integerValue] == 1) {
                _headerImage = info[@"UIImagePickerControllerOriginalImage"];
                [self reloadDataAction];
            
            /*
             需要对返回的信息进行处理
             */
            
        }else{
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = dic[@"message"];
            [_hud hide:YES afterDelay:2];
        }
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请求失败";
        [_hud hide:YES afterDelay:2];
    }];
    
}

-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark-   UITextFieldDelegate
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField;{
    switch (textField.tag) {
        case 0:
            [_infoDic setObject:textField.text forKey:@"nick"];
            break;
        case 3:
            [_infoDic setObject:textField.text forKey:@"real_name"];
            break;
        case 4:{
            if(![NNUtility validateMobile:textField.text]){
                [_hud show:YES];
                _hud.mode = MBProgressHUDModeText;
                _hud.labelText = @"请填正确的联系电话";
                [ _hud hide:YES afterDelay:2];
                
                return NO;
            }else{
                [_infoDic setObject:textField.text forKey:@"contact"];
            }
        }
            
            break;
        default:
            break;
    }
    
    return YES;
}

#pragma mark- UIPickerViewDelegate,UIPickerViewDataSource
// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView;{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component;{
    return 2;
}

- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component{
    if (row == 0) {
        return @"男";
    }else{
        return @"女";
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
