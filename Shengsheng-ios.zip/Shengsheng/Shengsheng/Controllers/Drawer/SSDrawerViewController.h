//
//  SSDrawerViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSDrawerViewController : NNBaseViewController

@end
