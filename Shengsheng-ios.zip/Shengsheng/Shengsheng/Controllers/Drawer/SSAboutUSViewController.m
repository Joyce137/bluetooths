//
//  SSAboutUSViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSAboutUSViewController.h"

@interface SSAboutUSViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *logoImageView;
@property (weak, nonatomic) IBOutlet UILabel *verLabel;

@end

@implementation SSAboutUSViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"关于我们";
    _logoImageView.layer.masksToBounds = YES;
    _logoImageView.layer.borderWidth = 1.0;
    _logoImageView.layer.cornerRadius = 15.0;
    _logoImageView.layer.borderColor = [UIColor clearColor].CGColor;
    
    NSDictionary *infoDictionary = [[NSBundle mainBundle] infoDictionary];
    _verLabel.text = [NSString stringWithFormat:@"当前版本号：%@",infoDictionary[@"CFBundleVersion"]];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
