//
//  SSNewCodeViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/27.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSNewCodeViewController.h"

@interface SSNewCodeViewController ()
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;

@end

@implementation SSNewCodeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"修改设备验证码";
    
    _sureButton.layer.cornerRadius = 4.0;
    
    [_inputTextField becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)sureButtonAction:(id)sender {
    
    if([_inputTextField.text isEqualToString:@""]){
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请输入新的验证码";
        [_hud hide:YES afterDelay:2];
    }else{
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = [NSString stringWithFormat:@"验证码修改成功"];
        [_hud hide:YES afterDelay:2];
        
        [self performSelector:@selector(popAction) withObject:nil afterDelay:2.0f];
    }
    

}

- (void)popAction{
    [self.navigationController popViewControllerAnimated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
