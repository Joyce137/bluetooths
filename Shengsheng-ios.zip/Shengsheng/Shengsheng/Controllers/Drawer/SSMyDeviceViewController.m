//
//  SSMyDeviceViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSMyDeviceViewController.h"

#import "SettingTableViewCell.h"

#import "NNConstants.h"
#import "UIColor+NN.h"

#import "FollowAlerView.h"

#define AlerViewH 140
#define AlerViewW 280

#define CELL_IDENTIFIER @"SettingTableViewCell"

@interface SSMyDeviceViewController ()<UITableViewDelegate,UITableViewDataSource,FollowDelegate>{
    NSMutableArray *_comnetArray;
    NSMutableArray *_otherArray;
    
    UIControl * _blackControl;
    FollowAlerView *_followAlerView;
    
    BOOL _open;
}

@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation SSMyDeviceViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"我的设备";
    
    [_tableView registerNib:[UINib nibWithNibName:@"SettingTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER];
    
    _comnetArray = [NSMutableArray array];
    [_comnetArray addObject:@"ifmcn"];
    
    _otherArray = [NSMutableArray array];
    [_otherArray addObjectsFromArray:@[@"附近设备2",@"附近设备3",@"附近设备4",@"附近设备5"]];
    
    _blackControl = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH ,MAIN_SCREEN_HEIGHT)];
    _blackControl.backgroundColor = [UIColor blackColor];
    _blackControl.alpha = 0.4;
    _blackControl.hidden = YES;
    [_blackControl addTarget:self action:@selector(endEditingAction) forControlEvents:UIControlEventTouchUpInside];
    
    _followAlerView = [[FollowAlerView alloc]init];
    _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
    _followAlerView.inputTextField.placeholder = @"请输入验证码";
    _followAlerView.delegate = self;
    
    UIWindow* currentWindow = [UIApplication sharedApplication].keyWindow;
    [currentWindow addSubview:_blackControl];
    [currentWindow addSubview:_followAlerView];
    
    _open = YES;
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_blackControl removeFromSuperview];
    [_followAlerView removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)endEditingAction{
    [_followAlerView.inputTextField resignFirstResponder];
}

- (void)sButtonAction:(id)sender{
    UIButton *button = (UIButton *)sender;
    button.selected = !button.selected;
    _open = button.selected;
    [_tableView reloadData];
}

#pragma mark - tableViewDataSource and tableViewDelegate

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if(_open){
        return 2;
    }else{
        return 1;
    }
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        if (_open) {
            return _comnetArray.count + 1;
        }
        return  1;
        
    }else{
        if (_open) {
            return _otherArray.count;
        }
        return  0;
    }
    
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    static NSString *cellIdentifier = CELL_IDENTIFIER;
    
    SettingTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[SettingTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    cell.infoLabel.hidden = YES;
    if (indexPath.section == 0 && indexPath.row == 0) {
        cell.sButton.hidden = NO;
        cell.lockImageView.hidden = YES;
        cell.titleLabel.text = @"设备链接";
        cell.sButton.selected = _open;
        [cell.sButton addTarget:self action:@selector(sButtonAction:) forControlEvents:UIControlEventTouchUpInside];
        
    }else{
        
        if (indexPath.section == 0 && indexPath.row == 1) {
            cell.titleLabel.textColor = [UIColor colorWithHexString:MAIN_TINT_COLOR];
        }
        
        cell.sButton.hidden = YES;
        cell.lockImageView.hidden = NO;
        if (indexPath.section == 0) {
            cell.titleLabel.text = _comnetArray[indexPath.row - 1];
        }else{
            cell.titleLabel.text = _otherArray[indexPath.row];
        }
    }
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    
    if (indexPath.row ==0 && indexPath.section == 0) {
        return;
    }else{
        NSString *str = @"";
        if (indexPath.section == 0) {
            str = _comnetArray[indexPath.row - 1];
        }else{
            str = _otherArray[indexPath.row];
        }
        _followAlerView.titleLabel.text = str;
        [self blackAction:nil];
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 20;
    }
    return 40;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    
    if (section == 1) {
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 40)];
        view.backgroundColor = [UIColor colorWithHexString:@"#F6F5EF"];
        UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(12, 0, MAIN_SCREEN_WIDTH - 24, 40)];
        label.text = @"附近设备";
        
        [view addSubview:label];
        
        return view;
        
    }

    
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}
#pragma mark- FollowDelegate
- (void)blackAction:(NSString *)inputKey;{
    
    
    if (inputKey != nil && [inputKey isEqualToString:@""]) {
        
        [ _followAlerView.hud show:YES];
        _followAlerView.hud.mode = MBProgressHUDModeText;
        _followAlerView.hud.labelText = @"请输入验证码";
        [ _followAlerView.hud hide:YES afterDelay:2];
        
        return;
    }
    
    [UIView animateWithDuration:0.5 animations:^{
        if (_blackControl.hidden) {
            _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
            _blackControl.hidden = NO;
        }else{
            
            if (![inputKey isEqualToString:@""] && inputKey != nil) {
                NSLog(@"%@",inputKey);
            }
            
            
            [_followAlerView.inputTextField resignFirstResponder];
            
            _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
            _blackControl.hidden = YES;
            
            _followAlerView.inputTextField.text = @"";
            
        }
    }];
    
    
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
