//
//  SSGoalSettingViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSGoalSettingViewController.h"

#import "GoalAlertView.h"
#import "NextTableViewCell.h"
#import "NNConstants.h"

#import "Taget.h"
#import <MagicalRecord/MagicalRecord.h>

#define CELL_NEXT_IDENTIFIER @"NextTableViewCell"

#define AlerViewH 372
#define AlerViewW 280

@interface SSGoalSettingViewController ()<UITableViewDelegate,UITableViewDataSource,GoalDelegate>{
    NSArray * _titleArray;
    NSMutableArray * _infoArray;
    
    UIControl * _blackControl;
    GoalAlertView *_goalAlertView;
    
    NSIndexPath *_selIndexPath;
    
    NSArray * _dateArray01;
    NSArray * _dateArray02;
    NSArray * _dateArray03;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation SSGoalSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"目标设置";
    
    [_tableView registerNib:[UINib nibWithNibName:@"NextTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_NEXT_IDENTIFIER];
    _titleArray = @[@"日运动目标",@"周运动目标",@"月运动目标"];
    _infoArray = [NSMutableArray array];
    [_infoArray addObjectsFromArray:@[@"",@"",@""]];
    
    _blackControl = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH ,MAIN_SCREEN_HEIGHT)];
    _blackControl.backgroundColor = [UIColor blackColor];
    _blackControl.alpha = 0.4;
    _blackControl.hidden = YES;
    [_blackControl addTarget:self action:@selector(endEditingAction) forControlEvents:UIControlEventTouchUpInside];
    
    _goalAlertView = [[GoalAlertView alloc]init];
    _goalAlertView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
    _goalAlertView.delegate = self;
    
    UIWindow* currentWindow = [UIApplication sharedApplication].keyWindow;
    [currentWindow addSubview:_blackControl];
    [currentWindow addSubview:_goalAlertView];
    
    
    _dateArray01 = @[@"6,000",@"7,000",@"8,000",@"9,000",@"10,0000"];
    _dateArray02 = @[@"42,000",@"43,000",@"44,000",@"45,000",@"46,0000"];
    _dateArray03 = @[@"166,000",@"167,000",@"168,000",@"169,000",@"170,0000"];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_blackControl removeFromSuperview];
    [_goalAlertView removeFromSuperview];
}

- (void)endEditingAction{
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableViewDataSource and tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _titleArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = CELL_NEXT_IDENTIFIER;
    
    NextTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[NextTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    cell.titleLabel.text = _titleArray[indexPath.row];
    cell.mainInfoLabel.hidden = NO;
    if (![_infoArray[indexPath.row] isEqualToString:@""]) {
         cell.mainInfoLabel.text = [NSString stringWithFormat:@"%@步",_infoArray[indexPath.row]];
    }
   
    
    return cell;

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    _selIndexPath = indexPath;
    
    _goalAlertView.titleLabel.text = _titleArray[indexPath.row];
    
    switch (indexPath.row) {
        case 0:
        {
            _goalAlertView.dataArray = _dateArray01;
        }
            break;
        case 1:
        {
            _goalAlertView.dataArray = _dateArray02;
        }
            break;
            
        default:
        {
            _goalAlertView.dataArray = _dateArray03;
        }
            break;
    }
    
    [_goalAlertView.pickerView reloadComponent:0];
    [_goalAlertView.pickerView selectRow:0 inComponent:0 animated:YES];
    
    [self blackAction];
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 10;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

#pragma mark- GoalDelegate
- (void)blackAction;{
    [UIView animateWithDuration:0.5 animations:^{
        if (_blackControl.hidden) {
            _goalAlertView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
            _blackControl.hidden = NO;
        }else{
            _goalAlertView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
            _blackControl.hidden = YES;
            
            NSString *tempStr = @"";
            
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            NSString * userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
            
            NSArray * tagetArray = [Taget MR_findByAttribute:@"userid" withValue:userId];
            
            Taget *tager = tagetArray.firstObject;
            
            if (!tager) {
                tager = [Taget MR_createEntity];
                tager.userid = userId;
            }

            switch (_selIndexPath.row) {
                case 0:
                    tempStr = _dateArray01[[_goalAlertView.pickerView selectedRowInComponent:0]];
                    tager.day = tempStr;
                    break;
                case 1:
                    tempStr = _dateArray02[[_goalAlertView.pickerView selectedRowInComponent:0]];
                    tager.week = tempStr;
                    break;
                default:
                    tempStr = _dateArray03[[_goalAlertView.pickerView selectedRowInComponent:0]];
                    tager.month = tempStr;
                    break;
            }
            [_infoArray replaceObjectAtIndex:_selIndexPath.row withObject:tempStr];
            
            [_tableView reloadData];
            
            [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
                NSLog(@"Taget save ok");
            }];
        }
    }];
    
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
