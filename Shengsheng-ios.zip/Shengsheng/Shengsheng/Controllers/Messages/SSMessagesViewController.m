//
//  SSMessagesViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSMessagesViewController.h"

#import "NNConstants.h"
#import "UIColor+NN.h"

#import "SportEncourageCell.h"
#import "WarningMessageCell.h"

#define CELL_IDENTIFIER01 @"SportEncourageCell"
#define CELL_IDENTIFIER02 @"WarningMessageCell"

@interface SSMessagesViewController ()<UITableViewDataSource,UITableViewDelegate>{
    NSMutableArray *_dataArray01;
    NSMutableArray *_dataArray02;
    NSMutableArray *_dataArray03;
}

@property (weak, nonatomic) IBOutlet UIScrollView *rootSV;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tW;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tH;

@property (weak, nonatomic) IBOutlet UITableView *tableView01;
@property (weak, nonatomic) IBOutlet UITableView *tableView02;
@property (weak, nonatomic) IBOutlet UITableView *tableView03;

@property (weak, nonatomic) IBOutlet UIButton *button01;
@property (weak, nonatomic) IBOutlet UIButton *button02;
@property (weak, nonatomic) IBOutlet UIButton *button03;

@property (weak, nonatomic) IBOutlet UIView *buttonBgView;
@end

@implementation SSMessagesViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initUI];
    [self initData];
}

- (void)initUI{
    
    self.navigationController.tabBarItem.badgeValue = @"10";
    
    _tableView01.tableFooterView = [[UIView alloc]init];
    _tableView02.tableFooterView = [[UIView alloc]init];
    _tableView03.tableFooterView = [[UIView alloc]init];
    
    _tableView03.estimatedRowHeight = 44.0;
    _tableView03.rowHeight = UITableViewAutomaticDimension;
    
    [_tableView01 registerNib:[UINib nibWithNibName:@"SportEncourageCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView02 registerNib:[UINib nibWithNibName:@"SportEncourageCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView03 registerNib:[UINib nibWithNibName:@"WarningMessageCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER02];
    
    for (UIButton *tempbutton in _buttonBgView.subviews) {
        [tempbutton setTitleColor:[UIColor colorWithHexString:@"#333333"] forState:UIControlStateNormal];
//        [tempbutton setBackgroundImage:[UIImage imageNamed:@"TM"] forState:UIControlStateNormal];
        
        [tempbutton setTitleColor:[UIColor colorWithHexString:@"#A3C841"] forState:UIControlStateSelected];
        [tempbutton setBackgroundImage:[UIImage imageNamed:@"backgroundSelected"] forState:UIControlStateSelected];
        
    }
    
    [self buttonAction:_button01];
}

- (void)initData{
    _dataArray01 = [NSMutableArray array];
    _dataArray02 = [NSMutableArray array];
    _dataArray03 = [NSMutableArray array];
    
    [_dataArray01 addObjectsFromArray:@[@"",@"",@""]];
    [_dataArray02 addObjectsFromArray:@[@"",@"",@"",@"",@"",@""]];
    [_dataArray03 addObjectsFromArray:@[@"",@"",@"",@""]];
    
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    _tH.constant = MAIN_SCREEN_HEIGHT - 64 - 50 - 50 ;
    _tW.constant = MAIN_SCREEN_WIDTH;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)buttonAction:(id)sender {
    
    UIButton *button = (UIButton *)sender;
    
    if (button.selected) {
        return;
    }
    
    for (UIButton *tempbutton in _buttonBgView.subviews) {
        if (tempbutton.tag == button.tag) {
            tempbutton.selected = YES;
            tempbutton.titleLabel.font = [UIFont fontWithName:tempbutton.titleLabel.font.fontName size:15.0];
        }else{
            tempbutton.selected = NO;
            tempbutton.titleLabel.font = [UIFont fontWithName:tempbutton.titleLabel.font.fontName size:14.0];
        }
    }
    
    _rootSV.contentOffset = CGPointMake((button.tag - 1) * MAIN_SCREEN_WIDTH, 0);
}

#pragma mark - UIScrollViewDelegate

-(void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (scrollView == _rootSV) {
        NSInteger i = scrollView.contentOffset.x/scrollView.frame.size.width + 1;
  
        for (UIButton *tempbutton in _buttonBgView.subviews) {
            if (tempbutton.tag == i) {
                tempbutton.selected = YES;
            }else{
                tempbutton.selected = NO;
            }
        }

    }
    
}

#pragma mark - UITableViewDataSource,UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    if (tableView == _tableView01) {
        return _dataArray01.count;
    }else if (tableView == _tableView02){
        return _dataArray02.count;
    }else{
        return _dataArray03.count;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    if (tableView == _tableView03) {
        static NSString *cellIdentifier = CELL_IDENTIFIER02;
        
        WarningMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[WarningMessageCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        return cell;

    }else{
        static NSString *cellIdentifier = CELL_IDENTIFIER01;
        
        SportEncourageCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[SportEncourageCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        
        return cell;
    }

}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
