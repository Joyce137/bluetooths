//
//  SSSearchViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSSearchViewController.h"
#import "SSSearchListViewController.h"

@interface SSSearchViewController ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *inputTextField;

@end

@implementation SSSearchViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"搜索";
    
    [_inputTextField becomeFirstResponder];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField;{
    if (textField == _inputTextField) {
        
        NSLog(@"%@",textField.text);
        
        if ([textField.text isEqualToString:@""]) {
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = @"请输入姓名/电话/身份证号";
            [_hud hide:YES afterDelay:2];
        }else{
            SSSearchListViewController *vc = [[SSSearchListViewController alloc]init];
            vc.searchKey = textField.text;
            [self.navigationController pushViewController:vc animated:YES];
        }
        
    }
    return YES;
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
