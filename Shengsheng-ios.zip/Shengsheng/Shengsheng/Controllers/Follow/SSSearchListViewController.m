//
//  SSSearchListViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSSearchListViewController.h"
#import "SearchListTableViewCell.h"
#import "NNConstants.h"
#import "FollowAlerView.h"

#define CELL_IDENTIFIER01 @"SearchListTableViewCell"

#define AlerViewH 140
#define AlerViewW 280


@interface SSSearchListViewController ()<UITableViewDelegate,UITableViewDataSource,FollowDelegate>{
    NSMutableArray *_listArray;
    
    UIControl * _blackControl;
    FollowAlerView *_followAlerView;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation SSSearchListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"搜索结果";
    
    _listArray = [NSMutableArray array];
    [_listArray addObjectsFromArray:@[
                                      @"李玲玲"
                                      ]];
    
    [_tableView registerNib:[UINib nibWithNibName:@"SearchListTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    
    _blackControl = [[UIControl alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH ,MAIN_SCREEN_HEIGHT)];
    _blackControl.backgroundColor = [UIColor blackColor];
    _blackControl.alpha = 0.4;
    _blackControl.hidden = YES;
    [_blackControl addTarget:self action:@selector(endEditingAction) forControlEvents:UIControlEventTouchUpInside];
    
    _followAlerView = [[FollowAlerView alloc]init];
    _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
    _followAlerView.delegate = self;
    
    UIWindow* currentWindow = [UIApplication sharedApplication].keyWindow;
    [currentWindow addSubview:_blackControl];
    [currentWindow addSubview:_followAlerView];
    
}

- (void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    [_blackControl removeFromSuperview];
    [_followAlerView removeFromSuperview];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)endEditingAction{
    [_followAlerView.inputTextField resignFirstResponder];
}

- (void)followButtonAction:(id)sender{
    UIButton *button  = (UIButton *)sender;
    NSLog(@"第%ld行",button.tag);
    
    [self blackAction:nil];
}


#pragma mark- FollowDelegate
- (void)blackAction:(NSString *)inputKey;{
    
    
    if (inputKey != nil && [inputKey isEqualToString:@""]) {
        
        [ _followAlerView.hud show:YES];
         _followAlerView.hud.mode = MBProgressHUDModeText;
         _followAlerView.hud.labelText = @"请输入好友授权码";
        [ _followAlerView.hud hide:YES afterDelay:2];
        
        return;
    }
    
    [UIView animateWithDuration:0.5 animations:^{
        if (_blackControl.hidden) {
            _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
            _blackControl.hidden = NO;
        }else{
            
            if (![inputKey isEqualToString:@""] && inputKey != nil) {
                NSLog(@"%@",inputKey);
            }
            
            
            [_followAlerView.inputTextField resignFirstResponder];
            
            _followAlerView.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT, AlerViewW, AlerViewH);
            _blackControl.hidden = YES;
            
            _followAlerView.inputTextField.text = @"";
            
        }
    }];

    
}


#pragma mark - tableViewDataSource and tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{

    return _listArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    

        static NSString *cellIdentifier = CELL_IDENTIFIER01;
        
        SearchListTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[SearchListTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
    
        cell.titleLabel.text = _listArray[indexPath.row];
    
    cell.followButton.tag = indexPath.row;
    [cell.followButton addTarget:self action:@selector(followButtonAction:) forControlEvents:UIControlEventTouchUpInside];
    
        return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}


/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
