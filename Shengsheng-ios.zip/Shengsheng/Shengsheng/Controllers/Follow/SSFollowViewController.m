//
//  SSFollowViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSFollowViewController.h"
#import "FollowAddTableViewCell.h"
#import "FollowPersonTableViewCell.h"

#import "SSSearchViewController.h"

#define CELL_IDENTIFIER01 @"FollowAddTableViewCell"
#define CELL_IDENTIFIER02 @"FollowPersonTableViewCell"

@interface SSFollowViewController ()<UITableViewDelegate,UITableViewDataSource>{
    NSMutableArray *_followArray;
}
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation SSFollowViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"关注";
    
    _followArray = [NSMutableArray array];
    [_followArray addObjectsFromArray:@[@"李玲玲",@"谢迪新",@"杨霞"]];
    
    [_tableView registerNib:[UINib nibWithNibName:@"FollowAddTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER01];
    [_tableView registerNib:[UINib nibWithNibName:@"FollowPersonTableViewCell" bundle:nil] forCellReuseIdentifier:CELL_IDENTIFIER02];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - tableViewDataSource and tableViewDelegate

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 1;
    }
    return _followArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (indexPath.section == 0) {
        static NSString *cellIdentifier = CELL_IDENTIFIER01;
        
        FollowAddTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
        
        if (!cell) {
            cell = [[FollowAddTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
            
        }
        return cell;
    }
    
    
    
    
    static NSString *cellIdentifier = CELL_IDENTIFIER02;
    
    FollowPersonTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (!cell) {
        cell = [[FollowPersonTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        
    }
    cell.titleLabel.text = _followArray[indexPath.row];
    
    
    return cell;
    
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 10;
}

-(UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *view = [[UIView alloc]init];
    view.backgroundColor = [UIColor clearColor];
    return view;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0) {
        SSSearchViewController *vc = [[SSSearchViewController alloc]init];
        self.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}


/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
