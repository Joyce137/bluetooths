//
//  SSPrescriptionViewController.h
//  Shengsheng
//
//  Created by Ningning on 16/6/5.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNBaseViewController.h"

@interface SSPrescriptionViewController : NNBaseViewController

@end
