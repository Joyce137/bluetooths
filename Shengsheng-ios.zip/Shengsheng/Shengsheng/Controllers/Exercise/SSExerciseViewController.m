//
//  SSExerciseViewController.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

/*
 页面功能逻辑
 显示
 1，显示本周有效运动次数，根据今天是星期几来决定电量进度的数量
 2，显示有效进度，根据数据库中是否有有效的运动来决定精度条是否点亮（或者修改1中的星期几，来点亮几个进度）
    [self updateImageBgWithTag:6];
 3，时间段第一个按钮显示星期几可以选，选了后更新当前的时间段，并以第一个时间段来更新当前时间段的心率图表

 4，点击每个时间段更新心率图表
 5，心率图表X需要根据数据库保存的开始时间和结束时间修改成xx:xx格式来显示，的根据时间差来平均分成多份，显示格式也要是xx:xx
 6，显示本周心率图
 7，周心率图中是双Y轴，其中卡鲁里数据在数据库中拿到数据的时候 应该*（有效平均心率最大值/卡路里最大值） 得到结果再显示到图表上
 8，预警线可以与记录数量相等的定值，来画出直线
 
 运动
 1，运动开始，设置计时器，记录下开始时间和结束时间
 2，若时间过短或者没有运动达标则不保存，保存的运动标识用用户的id作标识
 3，表保存用户id 当天日期xxxx-xx-xx 运动时间段xx:xx-xx:xx(或者以开始时间和结束是时间的nsdate)来储存 运动期间手环传来的心率 还有卡路里
 4，运动期间是否要把星期选择按钮修改成当天
 */



#import "SSExerciseViewController.h"
#import "NNConstants.h"
#import "NNUtility.h"
#import "UIColor+NN.h"
#import "TLTagsControl.h"
#import "UUChart.h"
#import "WeekButtonTableViewCell.h"
#import "UITableView+Wave.h"

#define CELL_HIGHT 40

#define WEEK_DAY_ARRAY @[@"周一",@"周二",@"周三",@"周四",@"周五",@"周六",@"周日"]

@interface SSExerciseViewController ()<TLTagsControlDelegate,UUChartDataSource,UITableViewDelegate,UITableViewDataSource>{
    
    NSMutableArray * _timeArray;
    
    UUChart *chartView01;
    UUChart *chartView02;
    
    NSMutableArray *_weekArray;
}
@property (weak, nonatomic) IBOutlet UIButton *finishButton;
@property (weak, nonatomic) IBOutlet UIButton *openButton;
@property (weak, nonatomic) IBOutlet UIButton *pauseButton;
@property (weak, nonatomic) IBOutlet UIButton *continueButton;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *rootW;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *timeH;
@property (weak, nonatomic) IBOutlet TLTagsControl *tagcontrol;

@property (weak, nonatomic) IBOutlet UIView *chartBg01;
@property (weak, nonatomic) IBOutlet UIView *chartBg02;

@property (weak, nonatomic) IBOutlet UIView *imageBgView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tbH;

@property (weak, nonatomic) IBOutlet UIButton *weekButton;
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@end

@implementation SSExerciseViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.view.backgroundColor = [UIColor whiteColor];
    
    self.finishButton.layer.cornerRadius = 35;
    self.finishButton.layer.masksToBounds = YES;
    self.openButton.layer.cornerRadius = 35;
    self.openButton.layer.masksToBounds = YES;
    self.pauseButton.layer.cornerRadius = 35;
    self.pauseButton.layer.masksToBounds = YES;
    self.continueButton.layer.cornerRadius = 35;
    self.continueButton.layer.masksToBounds = YES;
    self.continueButton.hidden = YES;
    self.finishButton.hidden = YES;
    self.pauseButton.hidden = YES;
    
    _weekButton.layer.borderWidth = 1.0;
    _weekButton.layer.borderColor = _weekButton.backgroundColor.CGColor;
    _weekButton.layer.cornerRadius = 4.0;
    
    _weekArray = [NSMutableArray array];
    [_weekArray addObjectsFromArray:WEEK_DAY_ARRAY];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    NSLog(@"今天是星期%ld",[NNUtility weekDay]);
    
    UILabel * lableTitle = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, MAIN_SCREEN_WIDTH, 44)];
    lableTitle.text = @"定量运动";
    [lableTitle setFont:[UIFont fontWithName:@"Helvetica-Bold" size:17]];
    lableTitle.textAlignment = NSTextAlignmentCenter;
    lableTitle.textColor = self.navigationController.navigationBar.tintColor;
    
    self.navigationItem.titleView = lableTitle;
    
    _rootW.constant = MAIN_SCREEN_WIDTH;
    
    _timeArray  = [[NSMutableArray alloc]initWithArray:@[@"18:00-18:40",@"18:40-19:20",@"19:20-21:00",@"21:00-21:40"]];
    _tagcontrol.tags = _timeArray.mutableCopy;
    _tagcontrol.mode = TLTagsControlModeList;
    _tagcontrol.tagsBackgroundColor = [UIColor whiteColor];
    _tagcontrol.tagsTextColor = [UIColor colorWithHexString:@"#6EB029"];
    if (_tagcontrol.tags.count > 0) {
        _tagcontrol.sel = 0;
    }
    [_tagcontrol reloadTagSubviews];
    [_tagcontrol setTapDelegate:self];
    
    [self updateImageBgWithTag:6];
    [self updateChartView];
    
    
    _tbH.constant = _weekArray.count * CELL_HIGHT;
}

- (IBAction)weekbuttonAction:(id)sender {
    if (_tableView.hidden) {
        _tableView.hidden = NO;
        [_tableView reloadDataAnimateWithWave:LeftToRightWaveAnimation];
    }else{
        _tableView.hidden = YES;
    }
    
}

- (IBAction)openAction:(UIButton *)sender {
    
    self.openButton.hidden = YES;
    self.pauseButton.hidden = NO;
    NSLog(@"开始运动");
    
}


- (IBAction)finishAction:(UIButton *)sender {
    NSLog(@"完成");
    [UIView animateWithDuration:0.25 animations:^{
        
        self.finishButton.frame = CGRectMake(self.view.frame.size.width / 2 - 35, 4, 70, 70);
        self.continueButton.frame = CGRectMake(self.view.frame.size.width / 2 - 35, 4, 70, 70);
        
    } completion:^(BOOL finished) {
        self.finishButton.hidden = YES;
        self.continueButton.hidden = YES;
        self.openButton.hidden = NO;
        
    }];

    
}
- (IBAction)pauseAction:(UIButton *)sender {
    NSLog(@"暂停");
    [UIView animateWithDuration:0.25 animations:^{
        self.pauseButton.hidden = YES;
        self.finishButton.hidden = NO;
        self.continueButton.hidden = NO;
        self.finishButton.frame = CGRectMake(self.view.frame.size.width / 2 + 40, 4, 70, 70);
        self.continueButton.frame = CGRectMake(self.view.frame.size.width / 2 - 105, 4, 70, 70);
    } completion:^(BOOL finished) {
        
    }];

}

- (IBAction)continueAction:(UIButton *)sender {
    NSLog(@"继续");
    [UIView animateWithDuration:0.25 animations:^{
        
        self.finishButton.frame = CGRectMake(self.view.frame.size.width / 2 - 35, 4, 70, 70);
        self.continueButton.frame = CGRectMake(self.view.frame.size.width / 2 - 35, 4, 70, 70);
        
    } completion:^(BOOL finished) {
        self.finishButton.hidden = YES;
        self.continueButton.hidden = YES;
        self.pauseButton.hidden = NO;
        
    }];
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)updateImageBgWithTag:(NSInteger)tag{
    for (UIImageView *view in _imageBgView.subviews) {
        if(view.tag <= tag){
            view.image = [UIImage imageNamed:[NSString stringWithFormat:@"schedule%ld",view.tag]];
        }else{
            view.image = [UIImage imageNamed:[NSString stringWithFormat:@"schedule0%ld",view.tag]];
        }
    }
}

#pragma mark - 更新图表
- (void)updateChartView{
    
    [chartView01 removeFromSuperview];
    [chartView02 removeFromSuperview];
    
    chartView01 = [[UUChart alloc]initWithFrame:CGRectMake(-10,0, MAIN_SCREEN_WIDTH , 150)
                                     dataSource:self
                                          style:UUChartStyleLine];
    [chartView01 showInView:_chartBg01];
    chartView02 = [[UUChart alloc]initWithFrame:CGRectMake(-10,30, MAIN_SCREEN_WIDTH , 150)
                                     dataSource:self
                                          style:UUChartStyleLine];
    chartView02.noInterval = NO;
    [chartView02 showInView:_chartBg02];
    if (_tagcontrol.tags) {
        _infoLabel.text = [NSString stringWithFormat:@"%@%@心率趋势图",[_weekButton.titleLabel.text substringWithRange:NSMakeRange(1, 2)] ,_tagcontrol.tags[_tagcontrol.sel ? _tagcontrol.sel : 0]];
    }else{
        _infoLabel.text = @"心率趋势图";
    }
    
}
#pragma mark - UITableViewDelegate,UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{
    return _weekArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;{
    static NSString *CellIdentifier = @"WeekButtonTableViewCell" ;
    WeekButtonTableViewCell *cell = (WeekButtonTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        NSArray *array = [[NSBundle mainBundle]loadNibNamed: CellIdentifier owner:self options:nil];
        cell = [array objectAtIndex:0];
    }

    
    cell.weekLabel.text = _weekArray[indexPath.row];
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return CELL_HIGHT;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [_weekButton setTitle:[NSString stringWithFormat:@"<%@>",_weekArray[indexPath.row]] forState:UIControlStateNormal];
    _tableView.hidden = YES;
    
    /*
     这里还需要执行两部刷新，
     第一步更新时间段的数组_tagcontrol来更新时间段，得根据选择的天从数据库拿
     第二部需要根据第一个时间段去刷新列表
     */
    if (_tagcontrol.tags.count > 0) {
        _tagcontrol.sel = 0;
    }
    [_tagcontrol reloadTagSubviews];
    [self updateChartView];
}

#pragma mark - TLTagsControlDelegate
- (void)tagsControl:(TLTagsControl *)tagsControl tappedAtIndex:(NSInteger)index {
    NSLog(@"Tag \"%@\" was tapped", tagsControl.tags[index]);
    
    tagsControl.sel = index;
    [_tagcontrol reloadTagSubviews];
    
    [self updateChartView];
}

#pragma mark - @required
//横坐标标题数组
- (NSArray *)chartConfigAxisXLabel:(UUChart *)chart
{
   if (chart == chartView01) {

        return @[@"18:00",@"18:10",@"18:20",@"18:30",@"18:40",];

        
    }else {

        return WEEK_DAY_ARRAY;

    }
}

//数值多重数组
- (NSArray *)chartConfigAxisYValue:(UUChart *)chart
{

    
    if (chart == chartView01){
        return @[@[@"120",@"110",@"130",@"125",@"60"]];
    }else{
        return @[@[@"120",@"110",@"130",@"125",@"60"],@[@"100",@"70",@"150",@"130",@"80"]];
    }
    
    
}

#pragma mark - @optional
//颜色数组
- (NSArray *)chartConfigColors:(UUChart *)chart
{
    if (chart == chartView01){
        return @[[UIColor colorWithHexString:@"#72B228"]];
    }else{
        return @[[UIColor colorWithHexString:@"#72B228"],[UIColor colorWithHexString:@"#FF6C00"]];
    }

}
//显示数值范围
- (NSArray *)chartRange:(UUChart *)chart
{
     if (chart == chartView01){
        return @[@"160/60"];
    }else{
        return @[@"160/60",@"500/200"];
    }

}

#pragma mark 折线图专享功能

//标记数值区域
- (CGRange)chartHighlightRangeInLine:(UUChart *)chart
{
    
    return CGRangeZero;
    
}

//判断显示横线条
- (BOOL)chart:(UUChart *)chart showHorizonLineAtIndex:(NSInteger)index
{
    return NO;
}

//判断显示最大最小值
- (BOOL)chart:(UUChart *)chart showMaxMinAtIndex:(NSInteger)index
{
    return NO;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
