//
//  NNBaseViewController.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@class AppDelegate;

#import "NNNavigationController.h"

@interface NNBaseViewController : UIViewController {
    MBProgressHUD *_hud;
}

- (AppDelegate *)getAppDelegate;

@property (nonatomic) UIAlertController *alertController;


@end
