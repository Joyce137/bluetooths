//
//  AppDelegate.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "AppDelegate.h"

#import "SSRealTimeViewController.h"
#import "HealthHomeViewController.h"
#import "SSExerciseViewController.h"
#import "SSMessagesViewController.h"
#import "SSDrawerViewController.h"
#import "NNConstants.h"
#import "UIColor+NN.h"
#import "MMExampleDrawerVisualStateManager.h"
#import <MMDrawerController.h>

#import <MagicalRecord/MagicalRecord.h>

@interface AppDelegate ()<UITabBarControllerDelegate>



@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
//    self.window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
//    [self.window makeKeyAndVisible];
    
    [MagicalRecord setupCoreDataStackWithStoreNamed:@"SSModel.sqlite"];
    [MagicalRecord setLoggingLevel:MagicalRecordLoggingLevelOff];
    
    
    [self buildTabBarController];
    SSDrawerViewController *left = [[SSDrawerViewController alloc]init];
    self.drawerController = [[MMDrawerController alloc]initWithCenterViewController:_tabBarController leftDrawerViewController:left];
    [self.drawerController setShowsShadow:YES];
    [self.drawerController setRestorationIdentifier:@"MMDrawer"];
    [self.drawerController setMaximumRightDrawerWidth:MAIN_SCREEN_WIDTH * (320-76)/320];//根据比例显示最大值
    [self.drawerController setOpenDrawerGestureModeMask:MMOpenDrawerGestureModeAll];
    [self.drawerController setCloseDrawerGestureModeMask:MMCloseDrawerGestureModeAll];
    
    [self.drawerController
     setDrawerVisualStateBlock:^(MMDrawerController *drawerController, MMDrawerSide drawerSide, CGFloat percentVisible) {
         MMDrawerControllerDrawerVisualStateBlock block;
         block = [[MMExampleDrawerVisualStateManager sharedManager]
                  drawerVisualStateBlockForDrawerSide:drawerSide];
         if(block){
             block(drawerController, drawerSide, percentVisible);
         }
     }];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (UIInterfaceOrientationMask)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)window
{
    return UIInterfaceOrientationMaskPortrait;
}

#pragma mark- 初始化TabBar

- (UITabBarController*)buildTabBarController
{
    SSRealTimeViewController *vc1 = [[SSRealTimeViewController alloc]init];
    vc1.title = @"实时监测";
    NNNavigationController *nvc1 = [[NNNavigationController alloc]initWithRootViewController:vc1];
    nvc1.tabBarItem.image = [[UIImage imageNamed:@"function_real-time-monitor1"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc1.tabBarItem.selectedImage = [[UIImage imageNamed:@"function_real-time-monitor"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc1.tabBarItem.title = @"实时监测";
    
    SSExerciseViewController *vc2 = [[SSExerciseViewController alloc]init];
    vc2.title = @"定量运动";
    NNNavigationController *nvc2 = [[NNNavigationController alloc]initWithRootViewController:vc2];
    nvc2.tabBarItem.image = [[UIImage imageNamed:@"function_sport1"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc2.tabBarItem.selectedImage = [[UIImage imageNamed:@"function_sport"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc2.tabBarItem.title = @"定量运动";
    
    HealthHomeViewController *vc3 = [[HealthHomeViewController alloc]init];
    vc3.title = @"健康监测";
    NNNavigationController *nvc3 = [[NNNavigationController alloc]initWithRootViewController:vc3];
    nvc3.tabBarItem.image = [[UIImage imageNamed:@"function_healthy-monitor1"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc3.tabBarItem.selectedImage = [[UIImage imageNamed:@"function_healthy-monitor"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc3.tabBarItem.title = @"健康监测";
    
    SSMessagesViewController *vc4 = [[SSMessagesViewController alloc]init];
    vc4.title = @"消息";
    NNNavigationController *nvc4 = [[NNNavigationController alloc]initWithRootViewController:vc4];
    nvc4.tabBarItem.image = [[UIImage imageNamed:@"function_massage1"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc4.tabBarItem.selectedImage = [[UIImage imageNamed:@"function_massage"]  imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
    nvc4.tabBarItem.title = @"消息";
    
    
    
    _tabBarController = [[UITabBarController alloc]init];
    [_tabBarController setViewControllers:@[nvc1,nvc2, nvc3, nvc4]];
    
    UIViewController *requiredViewController = [_tabBarController.viewControllers objectAtIndex:3];
    UITabBarItem *item = requiredViewController.tabBarItem;
    [item setBadgeValue:@"1"];
    
    
    self.tabBarController.delegate = self;
    self.tabBarController.tabBar.tintColor = [UIColor colorWithHexString:MAIN_TINT_COLOR];
    UIView *bgView = [[UIView alloc] initWithFrame:self.tabBarController.tabBar.bounds];
    bgView.backgroundColor = [UIColor whiteColor];
    [self.tabBarController.tabBar insertSubview:bgView atIndex:0];
    self.tabBarController.tabBar.opaque = YES;
    return self.tabBarController;
}

@end
