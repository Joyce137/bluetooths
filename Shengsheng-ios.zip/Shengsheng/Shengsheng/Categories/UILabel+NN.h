//
//  UILabel+NN.h
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (NN)

-(void)alignTop;

-(void)alignBottom;


@end
