//
//  UIButton+NN.h
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (NN)

- (void)centerImageAndTitleWithSpace:(float)space;
- (void)centerImageAndTitle;
- (void)changeImageAndTitle;

@end
