//
//  UIButton+NN.m
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "UIButton+NN.h"
#import "UIColor+NN.h"
#import "NNConstants.h"

@implementation UIButton (NN)

//居中
- (void)centerImageAndTitleWithSpace:(float)space {
    CGSize imageSize = self.imageView.frame.size;
    CGSize titleSize = self.titleLabel.frame.size;
    
    CGFloat totalHeight = imageSize.height + titleSize.height + space;
    
    self.imageEdgeInsets = UIEdgeInsetsMake(- (totalHeight - imageSize.height), 0, 0, - titleSize.width);
    self.titleEdgeInsets = UIEdgeInsetsMake(0, - imageSize.width, - (totalHeight - titleSize.height), 0);
}

//左右调换
- (void)changeImageAndTitle {
    CGSize imageSize = self.imageView.frame.size;
    CGSize titleSize = self.titleLabel.frame.size;
    
    self.imageEdgeInsets = UIEdgeInsetsMake(0, titleSize.width, 0, -titleSize.width);
    self.titleEdgeInsets = UIEdgeInsetsMake(0 , -imageSize.width , 0 ,imageSize.width);
}


- (void)centerImageAndTitle {
    const int DEFAULT_SPACE = 0.0f;
    [self centerImageAndTitleWithSpace:DEFAULT_SPACE];
}

@end
