//
//  UIView+NN.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "UIView+NN.h"

@implementation UIView (NN)

-(void)showBadgeValue:(NSString *)value {
    
    [self removeBadgeValue];
    
    UITabBar *tabBar = [[UITabBar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    UITabBarItem *item = [[UITabBarItem alloc]initWithTitle:@"" image:nil tag:0];
    
    item.badgeValue = value;
    tabBar.items = @[item];
    
    for (UIView *viewTab in tabBar.subviews) {
        for (UIView *subview in viewTab.subviews) {
            NSString *className = [NSString stringWithUTF8String:object_getClassName(subview)];
            
            if ([className isEqualToString:@"UITabBarButtonBadge"] || [className isEqualToString:@"_UIBadgeView"]) {
                [subview removeFromSuperview];
                [self addSubview:subview];
                subview.frame = CGRectMake(self.frame.size.width - subview.frame.size.width / 2, - subview.frame.size.height / 2, subview.frame.size.width, subview.frame.size.height);
            }
        }
    }
}

-(void)removeBadgeValue {
    for (UIView *subview in self.subviews) {
        NSString *className = [NSString stringWithUTF8String:object_getClassName(subview)];
        
        if ([className isEqualToString:@"UITabBarButtonBadge"] || [className isEqualToString:@"_UIBadgeView"]) {
            [subview removeFromSuperview];
            //            break;
        }
    }
}


@end
