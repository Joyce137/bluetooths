//
//  ShareAlanHand.h
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <Foundation/Foundation.h>
@class LoginViewController;
@interface ShareAlanHand : NSObject


+ (ShareAlanHand *)shareSingleton;
@property (nonatomic, strong) LoginViewController *loginVC;

@end
