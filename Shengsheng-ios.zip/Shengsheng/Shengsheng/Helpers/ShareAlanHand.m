//
//  ShareAlanHand.m
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "ShareAlanHand.h"
static ShareAlanHand *shareHand = nil;
@implementation ShareAlanHand


+ (ShareAlanHand *)shareSingleton {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        shareHand = [[ShareAlanHand alloc]init];
    });
    return shareHand;
}

@end
