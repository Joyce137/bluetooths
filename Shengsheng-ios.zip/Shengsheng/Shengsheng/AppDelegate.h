//
//  AppDelegate.h
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MMDrawerController;

@interface AppDelegate : UIResponder //<UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (nonatomic,strong) MMDrawerController * drawerController;
@property (strong, nonatomic) UITabBarController *tabBarController;

@end

