//
//  CoownClass.m
//  SmartBand
//
//  Created by Juyuan123 on 16/5/24.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import "CoownClass.h"

@implementation CoownClass


+ (void)configurationTextFieldWithTextField:(UITextField *)textField withID:(id)view {
    
    textField.delegate = view;
    NSMutableAttributedString *placeholder = [[NSMutableAttributedString alloc]initWithString:textField.placeholder];
    
    [placeholder addAttribute:NSForegroundColorAttributeName
                        value:[UIColor brownColor]
                        range:NSMakeRange(0, textField.placeholder.length)];
    [placeholder addAttribute:NSFontAttributeName
                        value:[UIFont systemFontOfSize:14]
                        range:NSMakeRange(0, textField.placeholder.length)];
    textField.attributedPlaceholder = placeholder;

}

@end
