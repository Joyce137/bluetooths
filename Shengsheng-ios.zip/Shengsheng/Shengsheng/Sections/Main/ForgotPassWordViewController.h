//
//  ForgotPassWordViewController.h
//  SmartBand
//
//  Created by Juyuan123 on 16/5/23.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPassWordViewController : UIViewController

@end
