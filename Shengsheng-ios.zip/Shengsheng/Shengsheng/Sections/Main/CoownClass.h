//
//  CoownClass.h
//  SmartBand
//
//  Created by Juyuan123 on 16/5/24.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface CoownClass : NSObject

+ (void)configurationTextFieldWithTextField:(UITextField *)textField withID:(id)view;

@end
