//
//  LoginViewController.m
//  SmartBand
//
//  Created by Juyuan123 on 16/5/23.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import "LoginViewController.h"
#import "AppDelegate.h"
#import "CoownClass.h"
#import "SSRealTimeViewController.h"
#import "HealthHomeViewController.h"
#import "SSExerciseViewController.h"
#import "SSMessagesViewController.h"
#import "SSDrawerViewController.h"
#import "NNConstants.h"
#import "UIColor+NN.h"
#import "MMExampleDrawerVisualStateManager.h"
#import <MMDrawerController.h>
#import "ShareAlanHand.h"

#import "SSBindingViewController.h"
#import "Person.h"
#import <MagicalRecord/MagicalRecord.h>

#import "NNServiceClient.h"

@interface LoginViewController ()<UITextFieldDelegate,UITabBarControllerDelegate>{
    MBProgressHUD *_hud;
}
@property (weak, nonatomic) IBOutlet UIImageView *logoImage;
@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTF;
@property (weak, nonatomic) IBOutlet UITextField *passWordTF;

@end

@implementation LoginViewController
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [CoownClass configurationTextFieldWithTextField:self.phoneNumberTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.passWordTF withID:self];
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    //由storyboard根据myView的storyBoardID来获取我们要切换的视图
    [ShareAlanHand shareSingleton].loginVC = [story instantiateViewControllerWithIdentifier:@"loginID"];
    
    [_hud removeFromSuperview];
    [self.view addSubview:_hud];
    
    
    self.phoneNumberTF.text = @"13218102399";
    self.passWordTF.text = @"11111111";
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.logoImage.layer.cornerRadius = 53;
    self.logoImage.layer.masksToBounds = YES;
    // Do any additional setup after loading the view.
//    [self configurationTextFieldWithTextField:self.phoneNumberTF];
//    [self configurationTextFieldWithTextField:self.passWordTF];
    
    self.passWordTF.secureTextEntry = YES;
    
    _hud = [[MBProgressHUD alloc]initWithView:self.view];
    
}

- (void)viewWillAppear:(BOOL)animated{

    
    [super viewWillAppear:animated];
    

}

- (IBAction)Login:(UIButton *)sender {
    
    //==============================登录测试-直接跳过登录进入页面==============================//
    
    ((AppDelegate *)[UIApplication sharedApplication].delegate).window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [((AppDelegate *)[UIApplication sharedApplication].delegate).window makeKeyAndVisible];
    
    ((AppDelegate *)[UIApplication sharedApplication].delegate).window.rootViewController = [[SSBindingViewController alloc]init];
    
    return;
    
    //==============================登录测试-直接跳过登录进入页面==============================//
    
    
    
    
    [_hud show:YES];
    _hud.mode = MBProgressHUDModeIndeterminate;
    _hud.labelText = @"";
    
    if ([_phoneNumberTF.text isEqualToString:@""]) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请填写手机号";
        [ _hud hide:YES afterDelay:2];
    }else if([_passWordTF.text isEqualToString:@""]){
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请填写密码";
        [ _hud hide:YES afterDelay:2];
    }else{
    
        [[NNServiceClient sharedClient]GET:@"user/signIn" parameters:@{
                                                                       @"tel":[NSNumber numberWithInteger:[_phoneNumberTF.text integerValue]],
                                                                       @"password":_passWordTF.text
                                                                       } progress:^(NSProgress * _Nonnull downloadProgress) {
                                                                           
                                                                       } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                                                           
                                                                           NSDictionary *dic = (NSDictionary *)responseObject;
                                                                           NSLog(@"%@",responseObject);
                                                                           if ([dic[@"success"] integerValue] == 1) {
                                                                               
                                                                               //登录将用户的个人信息保存到本地数据库通过TOKEN做唯一标识
                                                                               NSString *userId = dic[@"data"][@"uuid"];
                                                                               NSString *account = dic[@"data"][@"account"];
                                                                               NSString *token = dic[@"data"][@"token"];
                                                                               
                                                                               NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                                                                               
                                                                               [userDefaults setObject:userId forKey:kUSERDEFAULT_UUID];
                                                                               [userDefaults setObject:account forKey:kUSERDEFAULT_ACCOUNT];
                                                                               [userDefaults setObject:token forKey:kUSERDEFAULT_ACCCESSTOKEN];
                                                                               
                                                                               [self getUserInfo];
                                                                               
                                                                           }else{
                                                                               [_hud show:YES];
                                                                               _hud.mode = MBProgressHUDModeText;
                                                                               _hud.labelText = dic[@"message"];
                                                                               [ _hud hide:YES afterDelay:2];
                                                                           }
                                                                           
                                                                       } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                                                           [_hud show:YES];
                                                                           _hud.mode = MBProgressHUDModeText;
                                                                           _hud.labelText = @"请求失败";
                                                                           [ _hud hide:YES afterDelay:2];
                                                                       }];

    }

}

- (void)getUserInfo{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    NSString *userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    NSString *account = [userDefaults stringForKey:kUSERDEFAULT_ACCOUNT];
    NSString *token = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
    [[NNServiceClient sharedClient]setAccessToken:token];
    
    [[NNServiceClient sharedClient]GET:@"user/getInfo" parameters:@{@"token":token} progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
       
        if ([dic[@"success"] integerValue] == 1) {
            
            NSDictionary *infoDic = dic[@"data"];
            [userDefaults setObject:infoDic forKey:kUSERDEFAULT_UINFODIC];
            
            NSArray *userInfoArr = [Person MR_findByAttribute:@"userid" withValue:userId];
            
            if (userInfoArr.count != 0) {
                Person *per = userInfoArr.firstObject;
                NSLog(@"%@",per);
            }else{
                //看是否有获取的数据，有的话将数据存到数据库
                Person *per = [Person MR_createEntity];
                per.userid = userId;
                per.name = infoDic[@"real_name"];
                per.sex = [infoDic[@"sex"] integerValue] == 1 ? @"男" : @"女";
                per.nation = @"";
                per.idcard = infoDic[@"id_card"];
                per.phone = account;
                per.othername = @"";
                per.otherphone = infoDic[@"contact"];;
                per.blood = @"";
                per.rh = @"";
                per.wenhua = @"";
                per.zhiye = @"";
                per.hunyin = @"";
                per.zhifu = @"";
                per.fu = @"";
                per.mu = @"";
                per.xiong = @"";
                per.zi = @"";
                per.yichuan = @"";
                per.guomin = @"";
                per.edit = [NSNumber numberWithBool:NO];
            
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
                    NSLog(@"Person save ok");
                }];
            
            }
            
            ((AppDelegate *)[UIApplication sharedApplication].delegate).window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
            [((AppDelegate *)[UIApplication sharedApplication].delegate).window makeKeyAndVisible];
            
            //需要添加标识来判断是否进入绑定仪器界面
            //    ((AppDelegate *)[UIApplication sharedApplication].delegate).window.rootViewController = ((AppDelegate *)[UIApplication sharedApplication].delegate).drawerController;
                                                                                           
            ((AppDelegate *)[UIApplication sharedApplication].delegate).window.rootViewController = [[SSBindingViewController alloc]init];
        }else{
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = @"获取用户信息失败";
            [ _hud hide:YES afterDelay:2];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请求失败";
        [ _hud hide:YES afterDelay:2];
    }];
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
