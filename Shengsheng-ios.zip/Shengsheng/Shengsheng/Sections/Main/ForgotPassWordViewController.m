//
//  ForgotPassWordViewController.m
//  SmartBand
//
//  Created by Juyuan123 on 16/5/23.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import "ForgotPassWordViewController.h"
#import "CoownClass.h"
#import "NNServiceClient.h"
#import <MBProgressHUD/MBProgressHUD.h>
#import "NNUtility.h"
#import "NNConstants.h"
@interface ForgotPassWordViewController ()
{
    MBProgressHUD *_forgotHUD;
    NSInteger _endTime;
}
@property (weak, nonatomic) IBOutlet UIView *phoneView;
@property (weak, nonatomic) IBOutlet UIView *securityCodeView;
@property (weak, nonatomic) IBOutlet UIView *passWordNewView;
@property (weak, nonatomic) IBOutlet UIView *sureNewPassView;

@property (weak, nonatomic) IBOutlet UITextField *phoneNumberTF;
@property (weak, nonatomic) IBOutlet UITextField *securityCodeTF;
@property (weak, nonatomic) IBOutlet UITextField *passWordNewTF;
@property (weak, nonatomic) IBOutlet UITextField *sureNewWordTF;
@property (weak, nonatomic) IBOutlet UIButton *submitButton;

@end

@implementation ForgotPassWordViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self confictionAttribute];
    [self confictionUINavigtionController];
    // Do any additional setup after loading the view.
}
- (void)confictionAttribute {
    self.phoneView.layer.cornerRadius = 5;
    self.phoneView.layer.masksToBounds = YES;
    self.securityCodeView.layer.cornerRadius = 5;
    self.securityCodeView.layer.masksToBounds = YES;
    self.passWordNewView.layer.cornerRadius = 5;
    self.passWordNewView.layer.masksToBounds = YES;
    self.sureNewPassView.layer.cornerRadius = 5;
    self.sureNewPassView.layer.masksToBounds = YES;
    
    [CoownClass configurationTextFieldWithTextField:self.phoneNumberTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.securityCodeTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.passWordNewTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.sureNewWordTF withID:self];
    
    
}

- (void)confictionUINavigtionController {
    self.navigationItem.title = @"忘记密码";
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"return.png"] style:UIBarButtonItemStylePlain target:self action:@selector(returnBlack:)];
    self.navigationItem.leftBarButtonItem = item;
}
- (void)viewDidLayoutSubviews {
    _forgotHUD = [[MBProgressHUD alloc]init];
    [self.view addSubview:_forgotHUD];
}
- (void)returnBlack:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
        // Dispose of any resources that can be recreated.
}
- (IBAction)getSecurityCodeForget:(UIButton *)sender {
    NSLog(@"找回界面获取验证码");
    [_forgotHUD show:YES];
    _forgotHUD.mode = MBProgressHUDModeIndeterminate;
    _forgotHUD.labelText = @"";
    
    if ([NNUtility validateMobile:_phoneNumberTF.text]) {
        [[NNServiceClient sharedClient]GET:@"common/getCode" parameters:@{@"mobile":_phoneNumberTF.text, @"type":@"1" }
        progress:^(NSProgress * _Nonnull downloadProgress) {
                                                                              
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
        if ([dic[@"success"] integerValue] == 1) {
                                                                                  //请求成功
        [_forgotHUD show:YES];
        _forgotHUD.mode = MBProgressHUDModeText;
        _forgotHUD.labelText = dic[@"data"][@"message"];
        [ _forgotHUD hide:YES afterDelay:2];
                                                                                  
        //将限定时间归为60秒，开始下次可发送倒计时
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[[NSDate new] timeIntervalSince1970]];
        [userDefaults setObject:timeSp forKey:CODE_TIME_KEY];
                                                                                  
        _endTime = 60;
        [self codeTimeCountdown];
                                                                                  
                                                                                  
        }else{
            [_forgotHUD show:YES];
        _forgotHUD.mode = MBProgressHUDModeText;
        _forgotHUD.labelText = @"发送失败";
        [ _forgotHUD hide:YES afterDelay:2];
            }
     } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [_forgotHUD show:YES];
        _forgotHUD.mode = MBProgressHUDModeText;
        _forgotHUD.labelText = @"请求失败";
        [ _forgotHUD hide:YES afterDelay:2];
                                                                              
     }];
    }else{
        [_forgotHUD show:YES];
        _forgotHUD.mode = MBProgressHUDModeText;
        _forgotHUD.labelText = @"请输入正确的手机号";
        [ _forgotHUD hide:YES afterDelay:2];
    }
}
//倒计时
-(void)codeTimeCountdown{
    __block NSInteger timeout=_endTime; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _submitButton.enabled=YES;
                [_submitButton setTitle:@"获取验证码" forState:UIControlStateNormal];
            });
        }else{
            int seconds;
            if (timeout==60) {
                seconds=60;
            }else{
                seconds = timeout % 60;
            }
            
            NSString *strTime = [NSString stringWithFormat:@"(%.2d)",seconds];
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _submitButton.enabled=NO;
                [_submitButton setTitle:strTime forState:UIControlStateNormal];
            });
            timeout--;
            
        }
    });
    dispatch_resume(_timer);
}



- (void)popAction {
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)ConfirmPWd:(UIButton *)sender {
    NSLog(@"确认提交");
    __block NSString *url = [[NSString alloc]init];
     if ([self.phoneNumberTF.text isEqualToString:@""]) {
        url = @"请输入手机号";
    }else if ([self.securityCodeTF.text isEqualToString:@""]) {
        url = @"请获取验证码";
    }else if ([self.passWordNewTF.text isEqualToString:@""]){
        url = @"请输入新密码";
    }else if(self.passWordNewTF.text.length < 8) {
        url = @"密码至少8个位";
    }else if(![self.passWordNewTF.text isEqualToString:self.sureNewWordTF.text]) {
        url = @"两次密码输入不一样";
    }else {
        url = nil;
        __weak typeof(self)weakSelf = self;
        [[NNServiceClient sharedClient]GET:@"user/resetPwd" parameters:@{@"tel":self.phoneNumberTF.text, @"code":self.securityCodeTF.text, @"password":self.passWordNewTF.text, @"rpassword":self.sureNewWordTF.text} progress:^(NSProgress * _Nonnull downloadProgress) {
            
        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
            NSLog(@"responseObject = %@ --- message = %@",responseObject,responseObject[@"message"]);
            NSDictionary *dic = (NSDictionary *)responseObject;
            if ([dic[@"success"] integerValue] == 1) {
                url = @"密码修改成功";
                [_forgotHUD show:YES];
                _forgotHUD.mode = MBProgressHUDModeText;
                _forgotHUD.labelText = url;
                [_forgotHUD hide:YES afterDelay:2];
                [weakSelf performSelector:@selector(disAction) withObject:nil afterDelay:2.0f];
                
                
            }
            
        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
            NSLog(@"error = %@",error);
        }];
    }
    [_forgotHUD show:YES];
    _forgotHUD.mode = MBProgressHUDModeText;
    _forgotHUD.labelText = url;
    [_forgotHUD hide:YES afterDelay:2];
}

- (void)disAction{
    [self dismissViewControllerAnimated:YES completion:nil];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
