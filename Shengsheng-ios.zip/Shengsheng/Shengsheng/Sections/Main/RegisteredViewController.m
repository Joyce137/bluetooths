//
//  RegisteredViewController.m
//  SmartBand
//
//  Created by Juyuan123 on 16/5/23.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import "RegisteredViewController.h"
#import "CoownClass.h"

#import "RegisteredSuccessfulViewController.h"

#import "NNServiceClient.h"
#import "NNUtility.h"
#import "NNConstants.h"
#import <MBProgressHUD/MBProgressHUD.h>

#import "Person.h"
#import <MagicalRecord/MagicalRecord.h>


@interface RegisteredViewController ()<UITextFieldDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>{
    MBProgressHUD *_hud;
    NSInteger _endTime;
    UIImage *_headerImage;
}
@property (weak, nonatomic) IBOutlet UIImageView *photoImage;
@property (weak, nonatomic) IBOutlet UITextField *nameTF;
@property (weak, nonatomic) IBOutlet UITextField *phoneTF;
@property (weak, nonatomic) IBOutlet UITextField *SecurityCodeTF;
@property (weak, nonatomic) IBOutlet UITextField *setUpPassWordTF;
@property (weak, nonatomic) IBOutlet UITextField *surePassWordTF;
@property (weak, nonatomic) IBOutlet UITextField *numberIDTF;
@property (weak, nonatomic) IBOutlet UITextField *urgentPhoneTF;
@property (weak, nonatomic) IBOutlet UIImageView *bgImage;

@property (weak, nonatomic) IBOutlet UIImageView *pictureImage;
@property (weak, nonatomic) IBOutlet UIButton *sendButton;


@end

@implementation RegisteredViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self configurationTF];
    [self configurationUINavigtionController];
    
    _hud = [[MBProgressHUD alloc]initWithView:self.view];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithTitle:@""  style:UIBarButtonItemStylePlain target:nil action:nil];
    [self.navigationItem setBackBarButtonItem:item];
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
    
    // Do any additional setup after loading the view.
}

- (void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [_hud removeFromSuperview];
    [self.view addSubview:_hud];
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //修改导航栏
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)])
    {
        //if iOS 5.0 and later
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"TM.jpg"] forBarMetrics:UIBarMetricsDefault];
    }
    else
    {
        UIImageView *imageView = (UIImageView *)[self.navigationController.navigationBar  viewWithTag:10];
        [imageView setBackgroundColor:[UIColor clearColor]];
        if (imageView == nil)
        {
            imageView = [[UIImageView alloc] initWithImage:
                         [UIImage imageNamed:@"TM.jpg"]];
            [imageView setTag:10];
            [self.navigationController.navigationBar  insertSubview:imageView atIndex:0];
        }
    }
    
    [self.navigationController.navigationBar setTranslucent:YES];
    
    if ([self.navigationController.navigationBar respondsToSelector:@selector(shadowImage)])
    {
        [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    }
    
    [self.navigationController.navigationBar setBackgroundColor:[UIColor clearColor]];
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor whiteColor];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *tempTime = [userDefaults stringForKey:CODE_TIME_KEY];
    
    
    NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[[NSDate new] timeIntervalSince1970]];
    if (timeSp) {
        _endTime = 60 - ([timeSp integerValue] - [tempTime integerValue]);
    }
    if (!tempTime ||  _endTime> 60) {
        
        _sendButton.enabled = YES;
        
        _endTime = 0;
    }else{
        _sendButton.enabled = NO;
    }
    
    [self codeTimeCountdown];
    
}

//倒计时
-(void)codeTimeCountdown{
    __block NSInteger timeout=_endTime; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _sendButton.enabled=YES;
                [_sendButton setTitle:@"获取验证码" forState:UIControlStateNormal];
            });
        }else{
            int seconds;
            if (timeout==60) {
                seconds=60;
            }else{
                seconds = timeout % 60;
            }
            
            NSString *strTime = [NSString stringWithFormat:@"获取验证码(%.2d)",seconds];
            dispatch_async(dispatch_get_main_queue(), ^{
                //设置界面的按钮显示 根据自己需求设置
                _sendButton.enabled=NO;
                [_sendButton setTitle:strTime forState:UIControlStateNormal];
            });
            timeout--;
            
        }
    });
    dispatch_resume(_timer);
}


- (void)configurationTF {
    
    self.navigationController.navigationBar.tintColor = [UIColor redColor];
    self.photoImage.layer.cornerRadius = 50;
    self.photoImage.layer.masksToBounds= YES;
    [CoownClass configurationTextFieldWithTextField:self.phoneTF withID:self];
    self.phoneTF.keyboardType = UIKeyboardTypeNumberPad;
    [CoownClass configurationTextFieldWithTextField:self.nameTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.SecurityCodeTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.setUpPassWordTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.surePassWordTF withID:self];
    [CoownClass configurationTextFieldWithTextField:self.numberIDTF withID:self];
    self.numberIDTF.keyboardType = UIKeyboardTypeNumberPad;
    [CoownClass configurationTextFieldWithTextField:self.urgentPhoneTF withID:self];
    self.urgentPhoneTF.keyboardType = UIKeyboardTypeNumberPad;
    
}
- (void)configurationUINavigtionController {
    self.photoImage.layer.cornerRadius = 50;
    self.photoImage.layer.masksToBounds= YES;
    UIBarButtonItem *item = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"return.png"] style:UIBarButtonItemStylePlain target:self action:@selector(reTurnBlack:)];
    
    self.navigationItem.leftBarButtonItem = item;
}

- (void)reTurnBlack:(UIBarButtonItem *)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return YES;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)getSecurityCode:(UIButton *)sender {
    NSLog(@"注册页面获取验证码");
    
    [_hud show:YES];
    _hud.mode = MBProgressHUDModeIndeterminate;
    _hud.labelText = @"";
    
    if ([NNUtility validateMobile:_phoneTF.text]) {
        [[NNServiceClient sharedClient]GET:@"common/getCode" parameters:@{
                                                                          @"mobile":_phoneTF.text,
                                                                          @"type":@"2"
                                                                          } progress:^(NSProgress * _Nonnull downloadProgress) {
                                                                              
                                                                          } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                                                              NSDictionary *dic = (NSDictionary *)responseObject;
                                                                              if ([dic[@"success"] integerValue] == 1) {
                                                                                  //请求成功
                                                                                  [_hud show:YES];
                                                                                  _hud.mode = MBProgressHUDModeText;
                                                                                  _hud.labelText = dic[@"data"][@"message"];
                                                                                  [ _hud hide:YES afterDelay:2];
                                                                                  
                                                                                  //将限定时间归为60秒，开始下次可发送倒计时
                                                                                  NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                                                                                  NSString *timeSp = [NSString stringWithFormat:@"%ld", (long)[[NSDate new] timeIntervalSince1970]];
                                                                                  [userDefaults setObject:timeSp forKey:CODE_TIME_KEY];
                                                                                  
                                                                                  _endTime = 60;
                                                                                  [self codeTimeCountdown];
                                                                                  
                                                                                  
                                                                              }else{
                                                                                  [_hud show:YES];
                                                                                  _hud.mode = MBProgressHUDModeText;
                                                                                  _hud.labelText = @"发送失败";
                                                                                  [ _hud hide:YES afterDelay:2];
                                                                              }
                                                                          } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                                                              [_hud show:YES];
                                                                              _hud.mode = MBProgressHUDModeText;
                                                                              _hud.labelText = @"请求失败";
                                                                              [ _hud hide:YES afterDelay:2];
                                                                              
                                                                          }];
    }else{
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请输入正确的手机号";
        [ _hud hide:YES afterDelay:2];
    }
    
}


- (IBAction)nextButtonAction:(id)sender {
    
    NSString *error = nil;
    
    if ([_nameTF.text isEqualToString:@""]) {
        error = @"请填写真实姓名";
    }else if ([_phoneTF.text isEqualToString:@""]){
        error = @"请填写注册手机号";
    }else if ([_SecurityCodeTF.text isEqualToString:@""]){
        error = @"请填写验证码";
    }else if ([_setUpPassWordTF.text isEqualToString:@""]){
        error = @"请填写注册密码";
    }else if (_setUpPassWordTF.text.length <8){
        error = @"密码至少8个字符";
    }else if ([_surePassWordTF.text isEqualToString:@""]){
        error = @"请填写确认密码";
    }else if (![_surePassWordTF.text isEqualToString:_setUpPassWordTF.text]){
        error = @"确认密码与注册密码不一致";
    }else if ([_numberIDTF.text isEqualToString:@""]){
        error = @"请填写身份证";
    }else if (![NNUtility validateMobile:_phoneTF.text]){
        error = @"注册手机格式不正确";
    }else if (![NNUtility validateIDCard:_numberIDTF.text]){
        error = @"身份证格式不正确";
    }else if ([_urgentPhoneTF.text isEqualToString:@""]){
        error = @"请填写紧急联系电话";
    }else if (![NNUtility validateMobile:_urgentPhoneTF.text]){
        error = @"紧急联系电话格式不正确";
    }else{
        error = nil;
    }
    
    if (error) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = error;
        [ _hud hide:YES afterDelay:2];
    }else{
        NSData *data;
        
        if (_headerImage) {
            data = UIImageJPEGRepresentation(_headerImage, 0.3);
        }
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeIndeterminate;
        _hud.labelText = @"";
        
        [[NNServiceClient sharedClient]POST:@"user/signUp" parameters:@{
                                                                        @"tel":_phoneTF.text,
                                                                        @"password":_setUpPassWordTF.text,
                                                                        @"rpassword":_surePassWordTF.text,
                                                                        @"code":_SecurityCodeTF.text,
                                                                        @"real_name":_nameTF.text,
                                                                        @"id_card":_numberIDTF.text,
                                                                        @"contact":_urgentPhoneTF.text,
                                                                        } constructingBodyWithBlock:^(id<AFMultipartFormData>  _Nonnull formData) {
                                                                            if (data) {
                                                                                [formData appendPartWithFileData:data name:@"avatar" fileName:[[NNUtility GUID] stringByAppendingPathExtension:@"jpg"] mimeType:@"image/jpeg"];
                                                                            }
                                                                            
                                                                        } progress:^(NSProgress * _Nonnull uploadProgress) {
                                                                        } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
                                                                            
                                                                            
                                                                            NSDictionary *dic = (NSDictionary *)responseObject;
                                                                            if ([dic[@"success"] integerValue] == 1) {
                                                                                
                                                                                
                                                                                
                                                                                //登录将用户的个人信息保存到本地数据库通过TOKEN做唯一标识
                                                                                NSString *userId = dic[@"data"][@"uuid"];
                                                                                NSString *account = dic[@"data"][@"account"];
                                                                                NSString *token = dic[@"data"][@"token"];
                                                                                
                                                                                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                                                                                
                                                                                [userDefaults setObject:userId forKey:kUSERDEFAULT_UUID];
                                                                                [userDefaults setObject:account forKey:kUSERDEFAULT_ACCOUNT];
                                                                                [userDefaults setObject:token forKey:kUSERDEFAULT_ACCCESSTOKEN];
                                                                                
                                                                                
                                                                                [self getUserInfo];
                                                                                
                                                                                
                                                                            }else{
                                                                                [_hud show:YES];
                                                                                _hud.mode = MBProgressHUDModeText;
                                                                                _hud.labelText = dic[@"message"];
                                                                                [ _hud hide:YES afterDelay:2];
                                                                            }
                                                                            
                                                                            
                                                                        } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
                                                                            [_hud show:YES];
                                                                            _hud.mode = MBProgressHUDModeText;
                                                                            _hud.labelText = @"请求失败";
                                                                            [ _hud hide:YES afterDelay:2];
                                                                        }];
        
    }
}

- (void)getUserInfo{
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    NSString *userId = [userDefaults stringForKey:kUSERDEFAULT_UUID];
    NSString *account = [userDefaults stringForKey:kUSERDEFAULT_ACCOUNT];
    NSString *token = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
    [[NNServiceClient sharedClient]setAccessToken:token];
    
    [[NNServiceClient sharedClient]GET:@"user/getInfo" parameters:@{@"token":token} progress:^(NSProgress * _Nonnull downloadProgress) {
        
    } success:^(NSURLSessionDataTask * _Nonnull task, id  _Nullable responseObject) {
        NSDictionary *dic = (NSDictionary *)responseObject;
        if ([dic[@"success"] integerValue] == 1) {
            
            NSDictionary *infoDic = dic[@"data"];
            [userDefaults setObject:infoDic forKey:kUSERDEFAULT_UINFODIC];
            
            NSArray *userInfoArr = [Person MR_findByAttribute:@"userid" withValue:userId];
            
            if (userInfoArr.count != 0) {
                Person *per = userInfoArr.firstObject;
                NSLog(@"%@",per);
            }else{
                //看是否有获取的数据，有的话将数据存到数据库
                Person *per = [Person MR_createEntity];
                per.userid = userId;
                per.name = infoDic[@"real_name"];
                per.sex = [infoDic[@"sex"] integerValue] == 1 ? @"男" : @"女";
                per.nation = @"";
                per.idcard = infoDic[@"id_card"];
                per.phone = account;
                per.othername = @"";
                per.otherphone = infoDic[@"contact"];;
                per.blood = @"";
                per.rh = @"";
                per.wenhua = @"";
                per.zhiye = @"";
                per.hunyin = @"";
                per.zhifu = @"";
                per.fu = @"";
                per.mu = @"";
                per.xiong = @"";
                per.zi = @"";
                per.yichuan = @"";
                per.guomin = @"";
                per.edit = [NSNumber numberWithBool:NO];
                
                [[NSManagedObjectContext MR_defaultContext] MR_saveToPersistentStoreWithCompletion:^(BOOL contextDidSave, NSError *error) {
                    NSLog(@"Person save ok");
                    
                }];
                
            }
            //注册成功执行跳转事件
            UIStoryboard *sb = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            RegisteredSuccessfulViewController *vc = [sb instantiateViewControllerWithIdentifier:@"RegisteredSuccessfulViewController"];
            [self.navigationController pushViewController:vc animated:YES];
            return;
            
            
        }else{
            [_hud show:YES];
            _hud.mode = MBProgressHUDModeText;
            _hud.labelText = @"获取用户信息失败";
            [ _hud hide:YES afterDelay:2];
        }
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [_hud show:YES];
        _hud.mode = MBProgressHUDModeText;
        _hud.labelText = @"请求失败";
        [ _hud hide:YES afterDelay:2];
    }];
}


- (IBAction)clickPhoto:(UITapGestureRecognizer *)sender {
    NSLog(@"点击上传头像");
    UIAlertController *alertC = [UIAlertController alertControllerWithTitle:@"选取获取头像途径" message:@"。。。。" preferredStyle:UIAlertControllerStyleActionSheet];
    __weak typeof(self)weakSelf = self;
    UIAlertAction *alertFirst = [UIAlertAction actionWithTitle:@"相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        //判断视图是否可以使用
        if ([UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary]) {
            //1.创建一个图片选择控制器对象（获取图片的一个小领导）
            UIImagePickerController *imagePC = [[UIImagePickerController alloc]init];
            //2.图片获取
            imagePC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            //3.设置代理
            imagePC.delegate = weakSelf;
            //显示图片
            [weakSelf presentViewController:imagePC animated:YES completion:nil];
        }
    }];
    UIAlertAction *alertSecond = [UIAlertAction actionWithTitle:@"相机" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        if ([UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeCamera]) {
            //1.创建一个相机对象
            UIImagePickerController *imageCamera = [[UIImagePickerController alloc]init];
            //2.图片来源
            imageCamera.sourceType = UIImagePickerControllerSourceTypeCamera;
            //3.相机捕捉照片
            imageCamera.cameraFlashMode = UIImagePickerControllerCameraCaptureModePhoto;
            
            //4.设置前后摄像头
            imageCamera.cameraDevice = UIImagePickerControllerCameraDeviceFront;//前置摄像头
            //5.设置代理
            imageCamera.delegate = weakSelf;
            //6.设置取出来的图片是否允许编辑
            imageCamera.allowsEditing = YES;
            //7.推出相机
            [weakSelf presentViewController:imageCamera animated:YES completion:nil];
            
        }
        
    }];
    UIAlertAction *alertThird = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
    [alertC addAction:alertFirst];
    [alertC addAction:alertSecond];
    [alertC addAction:alertThird];
    [self presentViewController:alertC animated:YES completion:nil];
}

//实现协议中的方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
    //    UIImage *image = info[UIImagePickerControllerOriginalImage];
    UIImage *image = [info objectForKeyedSubscript:UIImagePickerControllerOriginalImage];
    self.pictureImage.image = image;
    _headerImage = image;
    //
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
