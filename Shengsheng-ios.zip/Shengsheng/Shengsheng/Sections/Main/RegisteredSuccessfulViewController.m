//
//  RegisteredSuccessfulViewController.m
//  SmartBand
//
//  Created by Juyuan123 on 16/5/23.
//  Copyright © 2016年 Juyuan123. All rights reserved.
//

#import "RegisteredSuccessfulViewController.h"
#import "AppDelegate.h"
#import "SSBindingViewController.h"
#import "RegisteredViewController.h"

@interface RegisteredSuccessfulViewController ()

@end

@implementation RegisteredSuccessfulViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    //修改导航栏
    if ([self.navigationController.navigationBar respondsToSelector:@selector(setBackgroundImage:forBarMetrics:)])
    {
        //if iOS 5.0 and later
        [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"TM.jpg"] forBarMetrics:UIBarMetricsDefault];
    }
    else
    {
        UIImageView *imageView = (UIImageView *)[self.navigationController.navigationBar  viewWithTag:10];
        [imageView setBackgroundColor:[UIColor clearColor]];
        if (imageView == nil)
        {
            imageView = [[UIImageView alloc] initWithImage:
                         [UIImage imageNamed:@"TM.jpg"]];
            [imageView setTag:10];
            [self.navigationController.navigationBar  insertSubview:imageView atIndex:0];
        }
    }
    
    [self.navigationController.navigationBar setTranslucent:YES];
    
    if ([self.navigationController.navigationBar respondsToSelector:@selector(shadowImage)])
    {
        [self.navigationController.navigationBar setShadowImage:[[UIImage alloc] init]];
    }
    
    [self.navigationController.navigationBar setBackgroundColor:[UIColor clearColor]];
    
    [self.navigationController.navigationBar setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor]}];
    self.navigationItem.leftBarButtonItem.tintColor = [UIColor whiteColor];
    
    //注册成功移除注册页面（写法不同，该方法待定）
//    NSMutableArray *viewControllers = self.navigationController.viewControllers.mutableCopy;
//    
//    for (int i = 0; i < viewControllers.count; i++) {
//        if ([viewControllers[i] isKindOfClass:[RegisteredViewController class]]) {
//            [viewControllers removeObjectAtIndex:i];
//            break;
//        }
//    }
//    
//    self.navigationController.viewControllers = viewControllers;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)loginAction:(id)sender {
    ((AppDelegate *)[UIApplication sharedApplication].delegate).window=[[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    [((AppDelegate *)[UIApplication sharedApplication].delegate).window makeKeyAndVisible];
    
    //需要添加标识来判断是否进入绑定仪器界面
    //    ((AppDelegate *)[UIApplication sharedApplication].delegate).window.rootViewController = ((AppDelegate *)[UIApplication sharedApplication].delegate).drawerController;
    
    ((AppDelegate *)[UIApplication sharedApplication].delegate).window.rootViewController = [[SSBindingViewController alloc]init];
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
