//
//  NNServiceClient.h
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <AFNetworking/AFNetworking.h>

@interface NNServiceClient : AFHTTPSessionManager

@property (nonatomic, copy) NSString *accessToken;

+(instancetype)sharedClient;

+(instancetype)sharedJSONClient;

@end
