//
//  NNServiceClient.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNServiceClient.h"
#import "NNConstants.h"
#import "NNUtility.h"

__strong static NNServiceClient *_client = nil;
__strong static NNServiceClient *_JSONClient = nil;

@implementation NNServiceClient

+(instancetype)sharedClient {
    static dispatch_once_t predicate = 0;
    dispatch_once(&predicate, ^{
        
        _client = [[NNServiceClient alloc]initWithBaseURL:[NSURL URLWithString:SERVICE_BASE_URL]];
        _client.responseSerializer.acceptableContentTypes = [_client.responseSerializer.acceptableContentTypes setByAddingObjectsFromArray:@[@"text/html",@"text/plain"]];
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *accessToken = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
        if (!accessToken) {
            accessToken = @"";
        }
        
        //设置HttpHeader
        [_client.requestSerializer setValue:@"iOS" forHTTPHeaderField:@"AppClient"];
        [_client.requestSerializer setValue:[NNUtility getSystemVersion] forHTTPHeaderField:@"OS-Version"];
        [_client.requestSerializer setValue:[NNUtility getAppVersion] forHTTPHeaderField:@"AppVersion"];
        [_client.requestSerializer setValue:accessToken forHTTPHeaderField:@"AccessToken"];
        
    });
    return _client;
}

+(instancetype)sharedJSONClient {
    
    static dispatch_once_t predicate = 0;
    dispatch_once(&predicate, ^{
        
        _JSONClient = [[NNServiceClient alloc]initWithBaseURL:[NSURL URLWithString:SERVICE_BASE_URL]];
        _JSONClient.responseSerializer.acceptableContentTypes = [_JSONClient.responseSerializer.acceptableContentTypes setByAddingObjectsFromArray:@[@"text/html",@"text/plain"]];
        
        NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
        NSString *accessToken = [userDefaults stringForKey:kUSERDEFAULT_ACCCESSTOKEN];
        if (!accessToken) {
            accessToken = @"";
        }
        
        _JSONClient.requestSerializer = [AFJSONRequestSerializer serializer];

        //设置HttpHeader
        [_JSONClient.requestSerializer setValue:@"iOS" forHTTPHeaderField:@"AppClient"];
        [_JSONClient.requestSerializer setValue:[NNUtility getSystemVersion] forHTTPHeaderField:@"OS-Version"];
        [_JSONClient.requestSerializer setValue:[NNUtility getAppVersion] forHTTPHeaderField:@"AppVersion"];
        [_JSONClient.requestSerializer setValue:accessToken forHTTPHeaderField:@"AccessToken"];
        
    });
    return _JSONClient;
}


-(void)setAccessToken:(NSString *)accessToken {
    _accessToken = accessToken;
    
    [_client.requestSerializer setValue:accessToken forHTTPHeaderField:@"AccessToken"];
    if (_JSONClient) {
        [_JSONClient.requestSerializer setValue:accessToken forHTTPHeaderField:@"AccessToken"];
    }
}


@end
