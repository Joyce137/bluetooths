//
//  Person+CoreDataProperties.h
//  Shengsheng
//
//  Created by Ningning on 16/5/31.
//  Copyright © 2016年 Ningning. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Person.h"

NS_ASSUME_NONNULL_BEGIN

@interface Person (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSString *sex;
@property (nullable, nonatomic, retain) NSString *nation;
@property (nullable, nonatomic, retain) NSString *idcard;
@property (nullable, nonatomic, retain) NSString *phone;
@property (nullable, nonatomic, retain) NSString *othername;
@property (nullable, nonatomic, retain) NSString *otherphone;
@property (nullable, nonatomic, retain) NSString *blood;
@property (nullable, nonatomic, retain) NSString *rh;
@property (nullable, nonatomic, retain) NSString *wenhua;
@property (nullable, nonatomic, retain) NSString *zhiye;
@property (nullable, nonatomic, retain) NSString *hunyin;
@property (nullable, nonatomic, retain) NSString *zhifu;
@property (nullable, nonatomic, retain) NSString *guomin;
@property (nullable, nonatomic, retain) NSString *fu;
@property (nullable, nonatomic, retain) NSString *mu;
@property (nullable, nonatomic, retain) NSString *xiong;
@property (nullable, nonatomic, retain) NSString *zi;
@property (nullable, nonatomic, retain) NSString *yichuan;
@property (nullable, nonatomic, retain) NSNumber *edit;
@property (nullable, nonatomic, retain) NSString *userid;

@end

NS_ASSUME_NONNULL_END
