//
//  Taget.m
//  Shengsheng
//
//  Created by Ningning on 16/6/3.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "Taget.h"

@implementation Taget

// Insert code here to add functionality to your managed object subclass

@end
