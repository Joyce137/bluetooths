//
//  Health.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/23.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "Health.h"

@implementation Health

+ (NSDictionary *)JSONKeyPathsByPropertyKey {
    return @{
             @"title" : @"title",
             @"info" : @"info",
             };
}

@end
