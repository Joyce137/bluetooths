//
//  Input.m
//  Shengsheng
//
//  Created by Ningning on 16/6/1.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "Input.h"

@implementation Input

// Insert code here to add functionality to your managed object subclass

@end
