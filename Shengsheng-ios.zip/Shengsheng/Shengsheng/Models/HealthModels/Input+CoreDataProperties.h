//
//  Input+CoreDataProperties.h
//  Shengsheng
//
//  Created by Ningning on 16/6/1.
//  Copyright © 2016年 Ningning. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Input.h"

NS_ASSUME_NONNULL_BEGIN

@interface Input (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *name;
@property (nullable, nonatomic, retain) NSString *info;
@property (nullable, nonatomic, retain) NSString *time;
@property (nullable, nonatomic, retain) NSString *userid;
@property (nullable, nonatomic, retain) NSString *result;
@property (nullable, nonatomic, retain) NSString *unit;

@end

NS_ASSUME_NONNULL_END
