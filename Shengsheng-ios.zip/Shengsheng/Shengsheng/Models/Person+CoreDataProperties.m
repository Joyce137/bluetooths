//
//  Person+CoreDataProperties.m
//  Shengsheng
//
//  Created by Ningning on 16/5/31.
//  Copyright © 2016年 Ningning. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Person+CoreDataProperties.h"

@implementation Person (CoreDataProperties)

@dynamic name;
@dynamic sex;
@dynamic nation;
@dynamic idcard;
@dynamic phone;
@dynamic othername;
@dynamic otherphone;
@dynamic blood;
@dynamic rh;
@dynamic wenhua;
@dynamic zhiye;
@dynamic hunyin;
@dynamic zhifu;
@dynamic guomin;
@dynamic fu;
@dynamic mu;
@dynamic xiong;
@dynamic zi;
@dynamic yichuan;
@dynamic edit;
@dynamic userid;

@end
