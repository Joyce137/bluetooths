//
//  Message.m
//  Shengsheng
//
//  Created by Ningning on 16/6/3.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "Message.h"

@implementation Message

// Insert code here to add functionality to your managed object subclass

@end
