//
//  Taget+CoreDataProperties.h
//  Shengsheng
//
//  Created by Ningning on 16/6/3.
//  Copyright © 2016年 Ningning. All rights reserved.
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Taget.h"

NS_ASSUME_NONNULL_BEGIN

@interface Taget (CoreDataProperties)

@property (nullable, nonatomic, retain) NSString *userid;
@property (nullable, nonatomic, retain) NSString *day;
@property (nullable, nonatomic, retain) NSString *month;
@property (nullable, nonatomic, retain) NSString *week;

@end

NS_ASSUME_NONNULL_END
