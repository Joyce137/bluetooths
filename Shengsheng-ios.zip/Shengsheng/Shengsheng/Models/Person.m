//
//  Person.m
//  Shengsheng
//
//  Created by Ningning on 16/5/31.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "Person.h"

@implementation Person

// Insert code here to add functionality to your managed object subclass

@end
