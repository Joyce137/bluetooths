//
//  NNUtility.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "NNUtility.h"
#import <ifaddrs.h>
#import <arpa/inet.h>

@implementation NNUtility

+(NSString *)getAppVersion {
    return [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleShortVersionString"];
}

+(NSString *)getSystemVersion {
    return [UIDevice currentDevice].systemVersion;
}

//汉字转拼音
+ (NSString *)transform:(NSString *)chinese
{
    NSMutableString *pinyin = [chinese mutableCopy];
    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformMandarinLatin, NO);
    //音标
//    CFStringTransform((__bridge CFMutableStringRef)pinyin, NULL, kCFStringTransformStripCombiningMarks, NO);
    NSLog(@"%@", pinyin);
    return [pinyin uppercaseString];
}

//手机号码验证
+ (BOOL) validateMobile:(NSString *)mobile {
    //手机号以13， 15，18，17开头，八个 \d 数字字符
    NSString *phoneRegex = @"^13[0-9]{1}[0-9]{8}$|14[0-9]{1}[0-9]{8}$|15[0-9]{1}[0-9]{8}$|17[0-9]{1}[0-9]{8}$|18[0-9]{1}[0-9]{8}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",phoneRegex];
    return [phoneTest evaluateWithObject:mobile];
}

//身份证验证
+ (BOOL) validateIDCard:(NSString *)idcard {
    //手机号以13， 15，18，17开头，八个 \d 数字字符
    NSString *idcardRegex = @"^(\\d{14}|\\d{17})(\\d|[xX])$";
    NSPredicate *idcardTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@",idcardRegex];
    return [idcardTest evaluateWithObject:idcard];
}

//邮箱验证
+ (BOOL) validateEmail:(NSString *)email
{
    NSString *emailRegex = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:email];
}

//邮编验证
+ (BOOL) validatePostCode:(NSString *)code {
    NSString *codeRegex = @"^[1-9][0-9]{5}$";
    NSPredicate *codeText = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", codeRegex];
    return [codeText evaluateWithObject:code];
}

//昵称验证
+ (BOOL) validatePostName:(NSString *)name {
    NSString *nameRegex = @"^[a-zA-Z0-9\u4e00-\u9fa5_-]{2,20}$";
    NSPredicate *nameText = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", nameRegex];
    return [nameText evaluateWithObject:name];
}

/** 返回一张纯色图片 */
+ (UIImage *)imageWithColor:(UIColor *)color {
    // 描述矩形
    CGRect rect = CGRectMake(0.0f, 0.0f, 1.0f, 1.0f);
    // 开启位图上下文
    UIGraphicsBeginImageContext(rect.size);
    // 获取位图上下文
    CGContextRef context = UIGraphicsGetCurrentContext();
    // 使用color演示填充上下文
    CGContextSetFillColorWithColor(context, [color CGColor]);
    // 渲染上下文
    CGContextFillRect(context, rect);
    // 从上下文中获取图片
    UIImage *theImage = UIGraphicsGetImageFromCurrentImageContext();
    // 结束上下文
    UIGraphicsEndImageContext();
    return theImage;
}



// 获取某字符串的显示尺寸
+ (CGSize)getSizeForString:(NSString*)string withFont:(UIFont*)font maxWidth:(NSInteger)width
{
    if (width == 0)
    {
        width = [UIScreen mainScreen].bounds.size.width;
    }
    NSDictionary *attribute = @{NSFontAttributeName: font};
    CGSize dateSize = [string boundingRectWithSize:CGSizeMake(width, MAXFLOAT) options: NSStringDrawingTruncatesLastVisibleLine | NSStringDrawingUsesLineFragmentOrigin | NSStringDrawingUsesFontLeading attributes:attribute context:nil].size;
    return dateSize;
}

+ (NSString *) GUID {
    CFUUIDRef guid_ref = CFUUIDCreate(NULL);
    CFStringRef guid_string_ref= CFUUIDCreateString(NULL, guid_ref);
    
    CFRelease(guid_ref);
    NSString *guid = [NSString stringWithString:(__bridge NSString*)guid_string_ref];
    
    CFRelease(guid_string_ref);
    return guid;
}

+ (NSAttributedString *)deletString:(NSString *)str{
    
    NSUInteger length = [str length];
    
    NSMutableAttributedString *attri = [[NSMutableAttributedString alloc] initWithString:str];
    [attri addAttribute:NSStrikethroughStyleAttributeName value:@(NSUnderlinePatternSolid | NSUnderlineStyleSingle) range:NSMakeRange(0, length)];
    //    [attri addAttribute:NSStrikethroughColorAttributeName value:UIColorFromRGB(0x999999, 1) range:NSMakeRange(0, length)];
    return attri;
}
// Get IP Address
+ (NSString *)getIPAddress {
    NSString *address = @"error";
    struct ifaddrs *interfaces = NULL;
    struct ifaddrs *temp_addr = NULL;
    int success = 0;
    // retrieve the current interfaces - returns 0 on success
    success = getifaddrs(&interfaces);
    if (success == 0) {
        // Loop through linked list of interfaces
        temp_addr = interfaces;
        while(temp_addr != NULL) {
            if(temp_addr->ifa_addr->sa_family == AF_INET) {
                // Check if interface is en0 which is the wifi connection on the iPhone
                if([[NSString stringWithUTF8String:temp_addr->ifa_name] isEqualToString:@"en0"]) {
                    // Get NSString from C String
                    address = [NSString stringWithUTF8String:inet_ntoa(((struct sockaddr_in *)temp_addr->ifa_addr)->sin_addr)];
                }
            }
            temp_addr = temp_addr->ifa_next;
        }
    }
    // Free memory
    freeifaddrs(interfaces);
    return address;
}

//根据时间返回年龄
+(NSInteger)ageFromBirthStr:(NSDate *)birth{
    NSInteger age = 0;
    
    NSDate *date = birth;
    
    // 出生日期转换 年月日
    NSDateComponents *components1 = [[NSCalendar currentCalendar] components:kCFCalendarUnitDay | kCFCalendarUnitMonth | kCFCalendarUnitYear fromDate:date];
    NSInteger brithDateYear  = [components1 year];
    NSInteger brithDateDay   = [components1 day];
    NSInteger brithDateMonth = [components1 month];
    
    // 获取系统当前 年月日
    NSDateComponents *components2 = [[NSCalendar currentCalendar] components:kCFCalendarUnitDay | kCFCalendarUnitMonth | kCFCalendarUnitYear fromDate:[NSDate date]];
    NSInteger currentDateYear  = [components2 year];
    NSInteger currentDateDay   = [components2 day];
    NSInteger currentDateMonth = [components2 month];
    
    // 计算年龄
    age = currentDateYear - brithDateYear - 1;
    if ((currentDateMonth > brithDateMonth) || (currentDateMonth == brithDateMonth && currentDateDay >= brithDateDay)) {
        age++;
    }
    
    return age;
}

//获取今天是星期几
+(NSInteger)weekDay{
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDate *now;
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    NSInteger unitFlags =kCFCalendarUnitYear | kCFCalendarUnitMonth |kCFCalendarUnitDay | kCFCalendarUnitWeekday |
    kCFCalendarUnitHour |kCFCalendarUnitMinute | kCFCalendarUnitSecond;
    now=[NSDate date];
    comps = [calendar components:unitFlags fromDate:now];
    
    return [comps weekday]== 0 ? 7 :[comps weekday] - 1 ;
}

@end
