//
//  NNConstants.h
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#ifndef NNConstants_h
#define NNConstants_h



#define SERVICE_BASE_URL @"http://shop.cohcreate.com/api/"

#define MAIN_TINT_COLOR     @"#6EB029"

#define DOCUMENT_FOLDER_PATH    (NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)[0])

#define MAIN_SCREEN_WIDTH   ([UIScreen mainScreen].bounds.size.width)
#define MAIN_SCREEN_HEIGHT  ([UIScreen mainScreen].bounds.size.height)

#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]

#define PLACEHOLDER_IMAGE [UIImage imageNamed:@"imageloading"]
#define USER_PLACEHOLDER_IMAGE [UIImage imageNamed:@"headsculpture"]
#define NO_SEL_IMAGE      [UIImage imageNamed:@"button-nochoice"]
#define SEL_IMAGE         [UIImage imageNamed:@"button-choice"]


#define CODE_TIME_KEY @"CODE_TIME_KEY"

#define kUSERDEFAULT_ACCCESSTOKEN          @"ACCCESS_TOKEN"
#define kUSERDEFAULT_ACCOUNT               @"ACCOUNT"
#define kUSERDEFAULT_UUID                  @"UUID"
#define kUSERDEFAULT_UINFODIC              @"UINFODIC"

#endif /* NNConstants_h */
