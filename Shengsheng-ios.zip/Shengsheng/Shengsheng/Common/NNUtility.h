//
//  NNUtility.h
//  NnBaseProduct
//
//  Created by Ningning on 16/5/11.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface NNUtility : NSObject

+ (NSString *)getAppVersion;
+ (NSString *)getSystemVersion;
+ (BOOL) validateMobile:(NSString *)mobile;
+ (BOOL) validateEmail:(NSString *)email;
+ (BOOL) validatePostCode:(NSString *)code;
+ (BOOL) validatePostName:(NSString *)name;
+ (BOOL) validateIDCard:(NSString *)idcard ;
+ (NSString *) GUID;
+ (NSAttributedString *)deletString:(NSString *)str;
+ (NSString *)getIPAddress;
+ (NSInteger)ageFromBirthStr:(NSDate *)birth;
+ (UIImage *)imageWithColor:(UIColor *)color;
+ (CGSize)getSizeForString:(NSString*)string withFont:(UIFont*)font maxWidth:(NSInteger)width;
+ (NSString *)transform:(NSString *)chinese;
+ (NSInteger)weekDay;
@end
