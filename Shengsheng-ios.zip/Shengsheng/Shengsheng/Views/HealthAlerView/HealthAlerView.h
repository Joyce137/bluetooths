//
//  HealthAlerView.h
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MBProgressHUD/MBProgressHUD.h>

@protocol HealthDelegate <NSObject>
- (void)blackAction:(NSString *)dataStr;
@end

@interface HealthAlerView : UIView<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;
@property (weak, nonatomic) IBOutlet UILabel *dateLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@property (weak, nonatomic) IBOutlet UIView *inputBgView01;
@property (weak, nonatomic) IBOutlet UITextField *itf01;
@property (weak, nonatomic) IBOutlet UILabel *until01;

@property (weak, nonatomic) IBOutlet UIView *inputBgView02;
@property (weak, nonatomic) IBOutlet UITextField *itf11;
@property (weak, nonatomic) IBOutlet UILabel *until11;
@property (weak, nonatomic) IBOutlet UITextField *itf12;
@property (weak, nonatomic) IBOutlet UILabel *until12;


@property (weak, nonatomic) IBOutlet UIView *inputBgView03;
@property (weak, nonatomic) IBOutlet UITextField *itf21;
@property (weak, nonatomic) IBOutlet UILabel *until21;
@property (weak, nonatomic) IBOutlet UITextField *itf22;
@property (weak, nonatomic) IBOutlet UILabel *until22;
@property (weak, nonatomic) IBOutlet UITextField *itf23;
@property (weak, nonatomic) IBOutlet UILabel *until23;
@property (weak, nonatomic) IBOutlet UITextField *itf24;
@property (weak, nonatomic) IBOutlet UILabel *until24;




- (id)init;
- (id)initWithFrame:(CGRect)frame;

@property (assign,nonatomic,readwrite)id <HealthDelegate>delegate;

@property (nonatomic)MBProgressHUD *hud;
@property (nonatomic)BOOL isHaveDian;

@end
