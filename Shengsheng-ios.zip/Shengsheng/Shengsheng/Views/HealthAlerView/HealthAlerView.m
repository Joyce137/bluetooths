//
//  HealthAlerView.m
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "HealthAlerView.h"
#import "UIColor+NN.h"
#import "NNConstants.h"

#define AlerViewH 372
#define AlerViewW 280

@implementation HealthAlerView

- (id)init
{
    self = [super init];
    if (self) {
        
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:[NSString stringWithUTF8String:object_getClassName(self)] owner:self options:nil];
        
        // 如果路径不存在，return nil
        if (arrayOfViews.count < 1)
        {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        CGRect frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        
        self.frame = frame ;
        self.userInteractionEnabled = YES;
        
        _cancelButton.layer.borderWidth = 1.0;
        _cancelButton.layer.borderColor = [UIColor colorWithHexString:@"#666666"].CGColor;
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        
        _hud = [[MBProgressHUD alloc]initWithView:self];
        [self addSubview:_hud];
        
        for (UIView * view in self.subviews) {
            if (view.tag >= 100) {
                for (id tf in view.subviews) {
                    if ([tf isKindOfClass:[UITextField class]]) {
                        ((UITextField *)tf).text = @"";
                        ((UITextField *)tf).layer.cornerRadius = 4.0;
                        ((UITextField *)tf).keyboardType = UIKeyboardTypeDecimalPad;
                        ((UITextField *)tf).delegate = self;
                    }
                }
            }
        }
    
    }
    
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}
- (IBAction)cancelButtonAction:(id)sender {
    [_delegate blackAction:nil];
}
- (IBAction)sureButtonAction:(id)sender {
    
    NSMutableString *tempStr = [[NSMutableString alloc]init];
    
    for (UIView * view in self.subviews) {
        if (view.tag >= 100 && view.hidden == NO) {
            for (id tf in view.subviews) {
                if ([tf isKindOfClass:[UITextField class]]) {
                    if ([((UITextField *)tf).text isEqualToString:@""]) {
                        [_hud show:YES];
                        _hud.mode = MBProgressHUDModeText;
                        
                        _hud.labelText = [((UITextField *)tf).placeholder stringByReplacingOccurrencesOfString:@"点击" withString:@"请"];
                        [_hud hide:YES afterDelay:2];
                        return;
                    }else{
                        [tempStr appendFormat:@"/%@",((UITextField *)tf).text];
                    }
                }
            }
        }
    }

    [_delegate blackAction:tempStr];
}

///键盘显示事件
- (void) keyboardWillShow:(NSNotification *)notification {
    
    CGFloat kbHeight = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    
    self.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT - kbHeight - AlerViewH - 12, AlerViewW, AlerViewH);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
}

///键盘消失事件
- (void) keyboardWillHide:(NSNotification *)notify {
    
    self.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
}


#pragma mark - UITextField delegate
//textField.text 输入之前的值 string 输入的字符
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if ([textField.text rangeOfString:@"."].location == NSNotFound) {
        _isHaveDian = NO;
    }
    if ([string length] > 0) {
        
        unichar single = [string characterAtIndex:0];//当前输入的字符
        if ((single >= '0' && single <= '9') || single == '.') {//数据格式正确
            
            //首字母不能为0和小数点
            if([textField.text length] == 0){
                if(single == '.') {
                    [textField.text stringByReplacingCharactersInRange:range withString:@""];
                    return NO;
                }
                if (single == '0') {
                    [textField.text stringByReplacingCharactersInRange:range withString:@""];
                    return NO;
                }
            }
            
            //输入的字符是否是小数点
            if (single == '.') {
                if(!_isHaveDian)//text中还没有小数点
                {
                    _isHaveDian = YES;
                    return YES;
                    
                }else{
                    [textField.text stringByReplacingCharactersInRange:range withString:@""];
                    return NO;
                }
            }else{
                if (_isHaveDian) {//存在小数点
                    
                    //判断小数点的位数
                    NSRange ran = [textField.text rangeOfString:@"."];
                    if (range.location - ran.location <= 2) {
                        return YES;
                    }else{
                        return NO;
                    }
                }else{
                    return YES;
                }
            }
        }else{//输入的数据格式不正确
            [textField.text stringByReplacingCharactersInRange:range withString:@""];
            return NO;
        }
    }
    else
    {
        return YES;
    }
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
