//
//  SSAlerView.h
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol SSAlerViewDelegate <NSObject>
- (void)blackAction:(BOOL)Key;
@end

@interface SSAlerView : UIView

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;

- (id)init;
- (id)initWithFrame:(CGRect)frame;
@property (assign,nonatomic,readwrite)id <SSAlerViewDelegate>delegate;

@end
