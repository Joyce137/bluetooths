//
//  SSAlerView.m
//  Shengsheng
//
//  Created by Ningning on 16/5/30.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SSAlerView.h"

#import "UIColor+NN.h"
#import "NNConstants.h"

#define AlerViewH 140
#define AlerViewW 280

@implementation SSAlerView

- (id)init
{
    self = [super init];
    if (self) {
        
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:[NSString stringWithUTF8String:object_getClassName(self)] owner:self options:nil];
        
        // 如果路径不存在，return nil
        if (arrayOfViews.count < 1)
        {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        CGRect frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        
        self.frame = frame ;
        self.userInteractionEnabled = YES;
        
        _cancelButton.layer.borderWidth = 1.0;
        _cancelButton.layer.borderColor = [UIColor colorWithHexString:@"#666666"].CGColor;
        
        
    }
    
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (IBAction)cancelButtonAction:(id)sender {
    [_delegate blackAction:NO];
}
- (IBAction)sureButtonAction:(id)sender {
    [_delegate blackAction:YES];
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
