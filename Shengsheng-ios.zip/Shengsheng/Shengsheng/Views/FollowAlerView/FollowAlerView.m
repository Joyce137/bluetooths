//
//  FollowAlerView.m
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "FollowAlerView.h"
#import "UIColor+NN.h"
#import "NNConstants.h"

#define AlerViewH 140
#define AlerViewW 280

@implementation FollowAlerView

- (id)init
{
    self = [super init];
    if (self) {
        
        NSArray *arrayOfViews = [[NSBundle mainBundle] loadNibNamed:[NSString stringWithUTF8String:object_getClassName(self)] owner:self options:nil];
        
        // 如果路径不存在，return nil
        if (arrayOfViews.count < 1)
        {
            return nil;
        }
        
        self = [arrayOfViews objectAtIndex:0];
        
        CGRect frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
        
        self.frame = frame ;
        self.userInteractionEnabled = YES;
        
        _inputTextField.delegate = self;
        _inputTextField.layer.borderWidth = 1.0;
        _inputTextField.layer.borderColor = [UIColor colorWithHexString:@"#EEF1DE"].CGColor;
        
        _cancelButton.layer.borderWidth = 1.0;
        _cancelButton.layer.borderColor = [UIColor colorWithHexString:@"#666666"].CGColor;
        
        
        _hud = [[MBProgressHUD alloc]initWithView:self];
        [self addSubview:_hud];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShow:) name:UIKeyboardWillShowNotification object:nil];
        
        
    }
    
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (IBAction)cancelButtonAction:(id)sender {
    [_delegate blackAction:nil];
}
- (IBAction)sureButtonAction:(id)sender {
    [_delegate blackAction:_inputTextField.text];
}


///键盘显示事件
- (void) keyboardWillShow:(NSNotification *)notification {
    
    CGFloat kbHeight = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size.height;
    
    self.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, MAIN_SCREEN_HEIGHT - kbHeight - AlerViewH - 12, AlerViewW, AlerViewH);
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHide:) name:UIKeyboardWillHideNotification object:nil];
    
}

///键盘消失事件
- (void) keyboardWillHide:(NSNotification *)notify {

    self.frame = CGRectMake((MAIN_SCREEN_WIDTH - AlerViewW)/2, (MAIN_SCREEN_HEIGHT - AlerViewH)/2, AlerViewW, AlerViewH);
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
