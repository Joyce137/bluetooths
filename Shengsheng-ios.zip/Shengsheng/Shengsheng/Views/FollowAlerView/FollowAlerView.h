//
//  FollowAlerView.h
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <MBProgressHUD/MBProgressHUD.h>

@protocol FollowDelegate <NSObject>
- (void)blackAction:(NSString *)inputKey;
@end

@interface FollowAlerView : UIView<UITextFieldDelegate>{
    
}
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;
@property (weak, nonatomic) IBOutlet UIButton *cancelButton;
@property (weak, nonatomic) IBOutlet UIButton *sureButton;

- (id)init;
- (id)initWithFrame:(CGRect)frame;

@property (nonatomic)MBProgressHUD *hud;
@property (assign,nonatomic,readwrite)id <FollowDelegate>delegate;

@end
