//
//  GoalAlertView.h
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GoalDelegate <NSObject>
- (void)blackAction;
@end

@interface GoalAlertView : UIView<UIPickerViewDelegate,UIPickerViewDataSource>

- (id)init;
- (id)initWithFrame:(CGRect)frame;

@property (nonatomic)NSArray *dataArray;

@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UIPickerView *pickerView;

@property (assign,nonatomic,readwrite)id <GoalDelegate>delegate;

@end
