//
//  PersonInfoSelTableViewCell.h
//  Shengsheng
//
//  Created by Ningning on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonInfoSelTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *selImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;

@end
