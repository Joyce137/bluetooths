//
//  PersonHeaderTableViewCell.m
//  Shengsheng
//
//  Created by Ningning on 16/5/24.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "PersonHeaderTableViewCell.h"

#import "NNConstants.h"
#import "UIColor+NN.h"

@implementation PersonHeaderTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    _headerImageView.layer.masksToBounds = YES;
    _headerImageView.layer.borderWidth = 2.0;
    _headerImageView.layer.cornerRadius = _headerImageView.bounds.size.width/2;
    _headerImageView.layer.borderColor = [UIColor colorWithHexString:@"#86AA22"].CGColor;
    
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

@end
