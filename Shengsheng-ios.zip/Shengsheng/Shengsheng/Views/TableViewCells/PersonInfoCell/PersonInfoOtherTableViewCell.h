//
//  PersonInfoOtherTableViewCell.h
//  Shengsheng
//
//  Created by Ningning on 16/5/26.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonInfoOtherTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *selImageView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UITextField *inputTextField;

@end
