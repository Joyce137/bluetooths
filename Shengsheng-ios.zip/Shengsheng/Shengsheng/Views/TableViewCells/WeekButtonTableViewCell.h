//
//  WeekButtonTableViewCell.h
//  Shengsheng
//
//  Created by Ningning on 16/6/7.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WeekButtonTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *weekLabel;

@end
