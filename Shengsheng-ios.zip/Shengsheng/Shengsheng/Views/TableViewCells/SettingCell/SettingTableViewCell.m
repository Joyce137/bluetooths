//
//  SettingTableViewCell.m
//  Shengsheng
//
//  Created by Ningning on 16/5/27.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "SettingTableViewCell.h"

@implementation SettingTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
    
    [_sButton setImage:[UIImage imageNamed:@"on"] forState:UIControlStateSelected];
    [_sButton setImage:[UIImage imageNamed:@"off"] forState:UIControlStateNormal];
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
