//
//  SettingTableViewCell.h
//  Shengsheng
//
//  Created by Ningning on 16/5/27.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SettingTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *infoLabel;
@property (weak, nonatomic) IBOutlet UIButton *sButton;
@property (weak, nonatomic) IBOutlet UIImageView *lockImageView;


@end
