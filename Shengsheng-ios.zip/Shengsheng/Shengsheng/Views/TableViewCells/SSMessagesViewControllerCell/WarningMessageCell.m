//
//  WarningMessageCell.m
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "WarningMessageCell.h"

@interface WarningMessageCell ()

@end


@implementation WarningMessageCell

- (void)awakeFromNib {
    // Initialization code
}
- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    
    self.contentLabel.numberOfLines = 2;
    
    return self;
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
