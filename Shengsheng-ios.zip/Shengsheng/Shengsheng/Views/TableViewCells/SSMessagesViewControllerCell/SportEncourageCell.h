//
//  SportEncourageCell.h
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SportEncourageCell : UITableViewCell


@property (weak, nonatomic) IBOutlet UILabel *contentCell;
@property (weak, nonatomic) IBOutlet UILabel *timeCell;

@end
