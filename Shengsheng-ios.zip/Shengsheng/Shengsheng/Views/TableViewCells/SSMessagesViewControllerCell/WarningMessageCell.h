//
//  WarningMessageCell.h
//  Shengsheng
//
//  Created by Juyuan123 on 16/5/25.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WarningMessageCell : UITableViewCell



@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

@end
