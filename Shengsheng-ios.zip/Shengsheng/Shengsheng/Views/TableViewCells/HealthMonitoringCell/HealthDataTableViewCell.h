//
//  HealthDataTableViewCell.h
//  Shengsheng
//
//  Created by Ningning on 16/5/26.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HealthDataTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *label01;
@property (weak, nonatomic) IBOutlet UILabel *label02;
@property (weak, nonatomic) IBOutlet UILabel *label03;

@end
