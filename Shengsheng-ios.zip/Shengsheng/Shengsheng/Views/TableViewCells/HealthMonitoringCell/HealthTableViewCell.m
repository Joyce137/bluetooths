//
//  HealthTableViewCell.m
//  NnBaseProduct
//
//  Created by Ningning on 16/5/23.
//  Copyright © 2016年 Ningning. All rights reserved.
//

#import "HealthTableViewCell.h"

@implementation HealthTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
