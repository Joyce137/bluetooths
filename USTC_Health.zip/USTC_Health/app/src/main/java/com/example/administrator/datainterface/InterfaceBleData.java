package com.example.administrator.datainterface;

/**
 * Created by HBL on 2015/12/25.
 */
public class InterfaceBleData {
}
