package com.example.administrator.viewfrag;

import android.support.v4.app.Fragment;

/**
 * Created by HBL on 2016/3/8.
 */
public class WeekAmountFragActivity extends Fragment{
}
