package com.example.administrator.view;

public interface OnProgressListener {

    public void onProgress(int progress); 
    
    public void onComplete(int progress); 

}
