package com.health.app.util;


public class Preferences {
	public static final Boolean DEBUG = true;

	public static class BROADCAST_ACTION {

		public static final String SELECTCITY = "lohas.city.select";
		public static final String SELECTCITYFROM = "lohas.city.select.from";
		public static final String SELECTCITYTO = "lohas.city.select.to";
		public static final String SELECTTIME = "lohas.city.select.time";
		public static final String USERSIGNUP = "lohas.user.signup";
		public static final String USER_UPDATE = "lohas.user.info.update";
		public static final String VIEW_UPDATE = "lohas.view.info.update";
		public static final String SELECTTIME2 = "lohas.city.select.time2";
		public static final String USERSIGNIN = "lohas.city.USERSIGNIN";
		public static final String SIAD_ADD = "lohas.city.SIAD_ADD";
		public static final String ADD_STROKE = "lohas.city.ADD_STROKE";
		public static final String STROKE_ERFRESH = "lohas.city.STROKE_ERFRESH";
		public static final String OPEN = "lohas.city.OPEN";
		public static final String SAID_DEL = "lohas.city.SAID_DEL";
		public static final String BLACK = "lohas.city.BLACK";
		public static final String NUM_UPDATE ="lohas.city.NUM_UPDATE";
		public static final String REFRESH = "lohas.city.REFRESH";
	}

	public static class INTENT_EXTRA {

		public static final String TOKEN = "intent.lohas.extra.push.token";
		public static final String MAP_LAT = "intent.lohas.map.lat";
		public static final String MAP_LNG = "intent.lohas.map.lng";
		public static final String MAP_ZOOM = "intent.lohas.map.zoom";
		public static final String MAP_MARKER_TIP = "intent.lohas.map.tip";
	}

	public static class REQUEST_CODE {
	}

	public static class LOCAL {
		public static final String TOKEN = "local.lohas.token";
		public static final String PHONE = "local.lohas.phone";
		public static final String URL = "local.lohas.url";
		public static final String IMEI = "local.lohas.imei";
		public static final String CITYID = "local.lohas.city";
		public static final String CITYNAME = "local.lohas.cityname";
		public static final String CITYNAME2 = "local.lohas.cityname2";
		public static final String CITYID2 = "local.lohas.city2";
		public static final String LAT = "local.lohas.lat";
		public static final String LNG = "local.lohas.lng";
		public static final String USERID = "local.lohas.USERID";
	}

	public static class FILE {
	}

}
