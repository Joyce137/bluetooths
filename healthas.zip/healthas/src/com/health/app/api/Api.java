package com.health.app.api;

import java.util.Iterator;

import org.json.JSONException;
import org.json.JSONObject;

import android.text.TextUtils;

import com.health.app.MainApplication;
import com.loopj.android.http.RequestParams;
import com.mslibs.api.BaseApi;
import com.mslibs.api.CallBack;
import com.mslibs.api.ResponseException;

public class Api extends BaseApi {
	protected String TAG = "Api";
	private MainApplication mApp;

	boolean hastoken = false;
	private RequestParams params = new RequestParams();

	public Api() {
		super();
	}

	public Api(CallBack callback, MainApplication mainApp) {
		super(callback);
		
		setLog(true);
		
		if (mainApp != null) {
			mApp = mainApp;
			String token = mApp.getToken();
			if (!TextUtils.isEmpty(token)) {
				hastoken = true;
				params.put("token", token);
			}
		}	
	}

	// public Api(CallBack callback) {
	// super(callback);
	// }

	public boolean checkLogin() {
		if (hastoken == false) {
			if (mCallBack != null) {
				// mCallBack.onFailure("请先登录");
			}
		}
		return !hastoken;
	}

	public String parse(String response) throws ResponseException,
			JSONException {
		JSONObject json = new JSONObject(response);
		Iterator<String> it = (Iterator<String>) json.keys();
		String data = null;
		String error = "";
		int code = 0;
		while (it.hasNext()) {
			String key = (String) it.next();
			if (key.equals("code")) {
				code = json.getInt(key);
				code = json.getInt(key);
				if (code > 0 && mCallBack != null) {
					mCallBack.setCode(code);
				}
			} else if (key.equals("message")) {
				error = json.getString(key);
			} else if (key.equals("data")) {
				data = json.getString(key);
			}
		}
		if (code == 100) {
			return data;
		} else {
			/*
			 * if (code == 400) { Intent intent = new
			 * Intent().setAction("action.finish");
			 * mApp.getApplicationContext().sendBroadcast(intent); }
			 */
			throw new ResponseException(error);
		}
	}

	public void test(String response) {
		// handler.onSuccess(response);
	}

	public void test() {
		String response = "{\"success\":1,\"data\":[" + "{\"title\":\"标题1\"},"
				+ "{\"title\":\"标题2\"}," + "{\"title\":\"标题3\"},"
				+ "{\"title\":\"标题4\"}," + "{\"title\":\"标题5\"},"
				+ "{\"title\":\"标题6\"}," + "{\"title\":\"标题7\"},"
				+ "{\"title\":\"标题8\"}," + "{\"title\":\"标题9\"},"
				+ "{\"title\":\"标题10\"}," + "{\"title\":\"标题11\"}]}";
		// handler.onSuccess(response);
	}

	public void version() {
		Client.get("api/app/check_version", params, handler);
	}

	// 获取开通城市
	public void get_city(double lat, double lng, String keyword) {
		params.put("lat", lat);
		params.put("lng", lng);
		params.put("keyword", keyword);
		Client.get("api/app/get_city", params, handler);
	}

	public void search(String lat, String lng, String keyword, String city_id,
			String type, String city) {
		params.put("lat", lat);
		params.put("lng", lng);
		params.put("keyword", keyword);
		params.put("city_id", city_id);
		params.put("type", type);
		params.put("city", city);
		Client.get("api/app/search", params, handler);
	}

	
	@Override
	public void onStart() {

	}

	@Override
	public void onSuccess() {

	}

	@Override
	public void onFailure(String message, int type) {

	}

	@Override
	public void start() {

	}

	@Override
	public void retry() {

	}

}
