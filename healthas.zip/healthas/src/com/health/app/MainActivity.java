package com.health.app;

import android.app.Activity;
import android.app.TabActivity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.widget.FrameLayout;
import android.widget.TabHost;

import com.health.app.tab.TabHomeActivity;
import com.health.app.util.TableOperate;

public class MainActivity extends TabActivity {
	private TabHost mTabHost;
	public Activity mActivity;
	MainApplication mainApp;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mActivity = this;
		if (mTabHost != null) {
			throw new IllegalStateException(
					"Trying to intialize already initializd TabHost");
		}
		mTabHost = getTabHost();
		mainApp = (MainApplication) getApplication();
		initTabHost();
	}
	private void initTabHost() {

//		TableOperate.addTab(mTabHost, "首页", R.drawable.tab_selector_home,
//				"home", new Intent(this, TabHomeActivity.class));
//		TableOperate.addTab(mTabHost, "附近", R.drawable.tab_selector_near,
//				"near", new Intent(this, TabNearActivity.class));
//		TableOperate.addTab(mTabHost, "动态", R.drawable.tab_selector_dynamic,
//				"dynamic", new Intent(this, TabDynamicActivity.class));
//		TableOperate.addTab(mTabHost, "发现", R.drawable.tab_selector_find,
//				"find", new Intent(this, TabFindActivity.class));
//		TableOperate.addTab(mTabHost, "我的", R.drawable.tab_selector_user, "my",
//				new Intent(this, TabMyActivity.class));

		// Fix layout for 1.5.
		if (new Integer(Build.VERSION.SDK).intValue() < 4) {
			FrameLayout flTabContent = (FrameLayout) findViewById(android.R.id.tabcontent);
			flTabContent.setPadding(0, 0, 0, 0);
		}
	}
	public void selectTabHost(String tabId) {
		mTabHost.setCurrentTabByTag(tabId);

	}
	public void setHome() {
		selectTabHost("home");
	}
}
