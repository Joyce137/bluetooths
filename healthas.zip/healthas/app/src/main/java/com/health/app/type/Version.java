package com.health.app.type;

public class Version {
	// "id": "2",
	//
	// "version": "2.0",
	//
	// "url": "www.baidu.com",
	//
	// "create_time": "1409726233",
	//
	// "intro": "aaaaaaaaaaaaaaaaaaa"
	public int id;
	public String version;
	public String url;
	public int force;
}
