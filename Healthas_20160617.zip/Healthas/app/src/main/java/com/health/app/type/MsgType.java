package com.health.app.type;

import android.graphics.Bitmap;

public class MsgType {
	public String message;
	public String photo;
	public Bitmap bitmap;
}	
