package com.health.app.statics;

/**
 * Created by CaoRuijuan on 6/12/16.
 */
public class BleInfo {
    public static String mDeviceName;
    public static String mDeviceAddress;
}
