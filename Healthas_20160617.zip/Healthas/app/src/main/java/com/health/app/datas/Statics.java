package com.health.app.datas;

/**
 * Created by CaoRuijuan on 5/19/16.
 */
public class Statics {
    public static int dateLength = 20;


}
