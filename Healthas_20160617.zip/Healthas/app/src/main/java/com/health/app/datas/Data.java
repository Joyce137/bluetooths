package com.health.app.datas;

/**
 * Created by CaoRuijuan on 5/23/16.
 */
public class Data {
    public byte[] header = new byte[2];
    public byte type;
    public byte length;
}
