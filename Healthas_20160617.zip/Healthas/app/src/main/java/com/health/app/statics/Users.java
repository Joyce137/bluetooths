package com.health.app.statics;

/**
 * Created by CaoRuijuan on 6/9/16.
 */
public class Users {
    public static String sLoginUsername = "";
}
